"""Build the ACM acmsmall (single-column) version from the same Markdown source as Revision 5.1 (formatting only)."""
import re, subprocess, pathlib
D = pathlib.Path(__file__).parent
src = (D/'manuscript_rev5_2_1_src.md').read_text()
body, _ = src.split('## References')
keys_of = lambda m: re.findall(r'@(\w+)', m.group(0))
tex_src = re.sub(r'\[@([^\]]+)\]', lambda m: '`\\cite{' + ','.join(keys_of(m)) + '}`{=latex}', body)
tex_src = re.sub(r'^(#+) \d+(\.\d+)*\.? ', r'\1 ', tex_src, flags=re.M)
front, rest = tex_src.split('\n## Abstract', 1)
abstract, main = rest.split('\n## Introduction', 1)
main = '## Introduction' + main
abs_text, kw = abstract.split('**Keywords:**')
(D/'_abs.md').write_text(abs_text.strip()); (D/'_main.md').write_text(main)
def pd(f, extra=()):
    return subprocess.run(['pandoc', str(D/f), '-f', 'markdown', '-t', 'latex', *extra], capture_output=True, text=True, check=True).stdout
abs_tex = pd('_abs.md').strip()
main_tex = pd('_main.md', ['--shift-heading-level-by=-1', '--lua-filter', str(D/'filter_acm.lua')]).replace('\\tightlist', '').replace('\\pandocbounded{', '{')
kw_tex = kw.strip().replace(';', ',')
def uni(s):
    return (s.replace('τ', '$\\tau$').replace('×', '$\\times$').replace('£', '\\pounds{}').replace('−', '$-$'))
tpl = r'''%% ACM acmsmall (single-column) version of Revision 5.2 (condensed).
\PassOptionsToPackage{expansion=false}{microtype}
\documentclass[acmsmall]{acmart}
\usepackage{lmodern}
\usepackage{booktabs,array}
\providecommand{\tightlist}{}
\setlength{\tabcolsep}{3pt}
\settopmatter{printacmref=false}
\setcopyright{none}
\renewcommand\footnotetextcopyrightpermission[1]{}
\renewcommand{\topfraction}{0.9}\renewcommand{\bottomfraction}{0.9}\renewcommand{\textfraction}{0.1}\renewcommand{\floatpagefraction}{0.75}
\begin{document}
\fancypagestyle{firstpagestyle}{\fancyhf{}\renewcommand{\headrulewidth}{0pt}}
\pagestyle{fancy}\fancyhf{}\fancyfoot[C]{\small\thepage}\renewcommand{\headrulewidth}{0pt}
\title{Designing Verification Checkpoints to Mitigate Silent Errors in Agentic AI Pipelines}
\author{Jahanvi Mishra}
\authornote{Guide: Prof. Sonali Agarwal.}
\affiliation{%
  \institution{Indian Institute of Information Technology Allahabad (IIIT Allahabad)}
  \city{Prayagraj}
  \country{India}}
\begin{abstract}
ABSTRACT
\end{abstract}
\ccsdesc[500]{Software and its engineering~Software verification and validation}
\keywords{KEYWORDS}
\maketitle
MAIN
\bibliographystyle{ACM-Reference-Format-citeorder}
\bibliography{refs}
\end{document}
'''
(D/'manuscript_rev5_2_1.tex').write_text(uni(tpl.replace('ABSTRACT', abs_tex).replace('KEYWORDS', kw_tex).replace('MAIN', main_tex)))
print('ok')
