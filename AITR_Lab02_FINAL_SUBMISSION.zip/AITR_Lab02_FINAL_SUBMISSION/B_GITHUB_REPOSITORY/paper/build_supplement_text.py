"""Build supplementary_text.pdf from supplementary_text.md (same ACM class, bst and refs.bib as the main paper). Formatting only."""
import re, subprocess, pathlib
D = pathlib.Path(__file__).parent
src = (D/'supplementary_text.md').read_text(encoding='utf-8')
head, rest = src.split('\n## S1.', 1)
rest = '## S1.' + rest
rest = re.sub(r'\[@([^\]]+)\]', lambda m: '`\\cite{' + ','.join(re.findall(r'@(\w+)', m.group(0))) + '}`{=latex}', rest)
fig = re.compile(r'!\[Figure S3\]\(([^)]+)\)\n\n\*\*Figure S3\.\*\* (.*)')
rest = fig.sub(lambda m: '```{=latex}\n\\begin{figure}[h]\\centering\\includegraphics[width=0.8\\textwidth]{' + m.group(1) + '}\\caption*{\\textbf{Figure S3.} ' + m.group(2).replace('_','\\_').replace('%','\\%') + '}\\end{figure}\n```', rest)
(D/'_supp_main.md').write_text(rest, encoding='utf-8')
tex = subprocess.run(['pandoc', str(D/'_supp_main.md'), '-f', 'markdown', '-t', 'latex', '--shift-heading-level-by=-1'], capture_output=True, text=True, check=True).stdout
tex = tex.replace('\\tightlist', '').replace('\\pandocbounded{', '{')
uni = lambda t: t.replace('τ', '$\\tau$').replace('×', '$\\times$').replace('£', '\\pounds{}').replace('−', '$-$')
tpl = r'''\PassOptionsToPackage{expansion=false}{microtype}
\documentclass[acmsmall]{acmart}
\usepackage{lmodern}
\usepackage{booktabs,array,caption}
\providecommand{\tightlist}{}
\settopmatter{printacmref=false}
\setcopyright{none}
\renewcommand\footnotetextcopyrightpermission[1]{}
\begin{document}
\fancypagestyle{firstpagestyle}{\fancyhf{}\renewcommand{\headrulewidth}{0pt}}
\pagestyle{fancy}\fancyhf{}\fancyfoot[C]{\small\thepage}\renewcommand{\headrulewidth}{0pt}
\title{Supplementary Text: Designing Verification Checkpoints to Mitigate Silent Errors in Agentic AI Pipelines}
\author{Jahanvi Mishra}
\authornote{Guide: Prof. Sonali Agarwal.}
\affiliation{\institution{IIIT Allahabad}\city{Prayagraj}\country{India}}
\begin{abstract}
Methodology detail and extended discussion supporting the 10-page main paper (Manuscript Rev 5.2.2). No number of the main paper is changed here.
\end{abstract}
\maketitle
BODY
\bibliographystyle{ACM-Reference-Format-citeorder}
\bibliography{refs}
\end{document}
'''
(D/'supplementary_text.tex').write_text(uni(tpl.replace('BODY', tex)), encoding='utf-8')
print('ok')
