"""Reproducible random-seed control.

Design (matches Prompt 07, v0.1, provisional):
  * one master seed in configs/seeds.json
  * one independent sub-seed per purpose = master + fixed offset
      split (+1), faults (+2), missed_case_review (+3), bootstrap (+4)
  * every purpose gets its own numpy Generator, so drawing more numbers for
    one purpose (e.g. more faults) never changes another (e.g. the split).

Nothing in this study uses a global random state except as a safety net.
"""

from __future__ import annotations

import json
import os
import random
from pathlib import Path
from typing import Dict, Optional

import numpy as np

DEFAULT_MASTER_SEED = 20261029
DEFAULT_OFFSETS = {"split": 1, "faults": 2, "missed_case_review": 3, "bootstrap": 4}
_MAX_SEED = 2**32 - 1  # keeps seeds valid for every numpy/random API


def _check_seed(seed: int) -> int:
    if isinstance(seed, bool) or not isinstance(seed, int):
        raise TypeError(f"seed must be an int, got {type(seed).__name__}")
    if not 0 <= seed <= _MAX_SEED:
        raise ValueError(f"seed must be in [0, {_MAX_SEED}], got {seed}")
    return seed


def load_seed_config(path: Optional[Path] = None) -> dict:
    """Read configs/seeds.json (or defaults if no path is given)."""
    if path is None:
        return {"master_seed": DEFAULT_MASTER_SEED, "offsets": dict(DEFAULT_OFFSETS)}
    path = Path(path)
    try:
        cfg = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise FileNotFoundError(f"Seed config not found: {path}") from exc
    except json.JSONDecodeError as exc:
        raise ValueError(f"Seed config is not valid JSON: {path} ({exc})") from exc
    for key in ("master_seed", "offsets"):
        if key not in cfg:
            raise KeyError(f"Seed config {path} is missing key '{key}'")
    _check_seed(cfg["master_seed"])
    return cfg


def derive_seeds(master_seed: int, offsets: Optional[Dict[str, int]] = None) -> Dict[str, int]:
    """Return {purpose: sub_seed}. Offsets must be distinct so streams differ."""
    _check_seed(master_seed)
    offsets = dict(DEFAULT_OFFSETS if offsets is None else offsets)
    if len(set(offsets.values())) != len(offsets):
        raise ValueError("Seed offsets must be distinct")
    return {name: _check_seed(master_seed + off) for name, off in offsets.items()}


def make_rng(seed: int) -> np.random.Generator:
    """One independent numpy Generator (PCG64) for a given seed."""
    return np.random.default_rng(_check_seed(seed))


def make_all_rngs(master_seed: int, offsets: Optional[Dict[str, int]] = None) -> Dict[str, np.random.Generator]:
    """One Generator per purpose, derived from the master seed."""
    return {name: make_rng(s) for name, s in derive_seeds(master_seed, offsets).items()}


def seed_globals(master_seed: int) -> None:
    """Safety net: also seed Python's `random` and numpy's legacy global state."""
    _check_seed(master_seed)
    random.seed(master_seed)
    np.random.seed(master_seed)


def hashseed_status() -> str:
    """PYTHONHASHSEED can only be set BEFORE Python starts, so we only report it.

    The study code must therefore not depend on set/dict-of-set iteration order
    (sort before iterating). This is a coding rule, not something a function can fix.
    """
    value = os.environ.get("PYTHONHASHSEED")
    return f"PYTHONHASHSEED={value}" if value is not None else "PYTHONHASHSEED not set (hash order may vary between runs)"
