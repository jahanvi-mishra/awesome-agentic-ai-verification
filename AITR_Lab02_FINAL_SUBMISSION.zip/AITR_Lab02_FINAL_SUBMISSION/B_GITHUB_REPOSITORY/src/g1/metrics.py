"""Metrics M1-M11 and result tables R1-R9 (Prompt 07 Parts 6-8), computed from saved files only.

Inputs  : manifest rows, run logs (B0/F/I per case) and oracle labels. Nothing is re-run here.
Outputs : lists of rows (dicts) that scripts/score_results.py writes as CSV files.

Conventions (from the protocol)
  * harmful faulty case = oracle label 'harmful' (B0 record differs from the reference); the SAME set is used for F and I.
  * 'reached the commit' = outcome COMMITTED; 'halted' = outcome HALTED; crashes are neither (they are logged and excluded).
  * single proportions (one case per invoice): Wilson 95% interval.
  * differences and rates pooled across fault types: invoice-level percentile bootstrap, 2,000 resamples, seed master+4,
    one resample of invoices carries all of an invoice's faulty cases.
  * clean cases exist for evaluation invoices only; T4 top-up invoices carry a single T4 case and no clean case.
"""

from __future__ import annotations

import math
from collections import Counter
from typing import Any, Dict, List, Optional, Sequence, Tuple

import numpy as np

from g1 import seeding
from g1.faults import FAULT_TYPES

Z = 1.96
RESAMPLES = 2000
CONDS = ("B0", "F", "I")
CHECKPOINTS = ("CP1", "CP2", "CP3", "FINAL")


# ------------------------------------------------------------------ statistics helpers
def wilson(k: int, n: int) -> Tuple[Optional[float], Optional[float]]:
    if n == 0:
        return None, None
    p = k / n
    d = 1 + Z * Z / n
    centre = (p + Z * Z / (2 * n)) / d
    half = Z * math.sqrt(p * (1 - p) / n + Z * Z / (4 * n * n)) / d
    return max(0.0, centre - half), min(1.0, centre + half)


def rate(k: int, n: int) -> Optional[float]:
    return None if n == 0 else k / n


def _pct(x: np.ndarray) -> Tuple[Optional[float], Optional[float]]:
    return (None, None) if x.size == 0 else (float(np.percentile(x, 2.5)), float(np.percentile(x, 97.5)))


# ------------------------------------------------------------------ join
def join_cases(manifest: Sequence[Dict[str, Any]], logs: Sequence[Dict[str, Any]], labels: Sequence[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """One record per run case (clean or injected fault) with its three conditions and its oracle label."""
    runs = {(l["case_id"], l["condition"]): l for l in logs}
    lab = {l["case_id"]: l["label"] for l in labels}
    out = []
    for r in manifest:
        if r["status"] not in ("clean", "inject"):
            continue
        c = {"case_id": r["case_id"], "invoice_no": r["invoice_no"], "fault_type": r["fault_type"],
             "source": r.get("source", "evaluation"), "label": lab[r["case_id"]]}
        for cond in CONDS:
            log = runs[(r["case_id"], cond)]
            c[f"out_{cond}"], c[f"cp_{cond}"], c[f"rule_{cond}"] = log["outcome"], log["halt_checkpoint"], log["halt_rule"]
            c[f"apps_{cond}"], c[f"detail_{cond}"] = log["rule_applications"], log["halt_detail"]
        out.append(c)
    return out


def _committed(c, cond): return c[f"out_{cond}"] == "COMMITTED"
def _halted(c, cond): return c[f"out_{cond}"] == "HALTED"


# ------------------------------------------------------------------ pooled bootstrap
def _bootstrap(faulty: List[Dict[str, Any]], seed: int, resamples: int) -> Dict[str, Any]:
    """Per-invoice counts -> resampled pooled rates. Returns a function-like dict of CI helpers."""
    invs = sorted({c["invoice_no"] for c in faulty})
    pos = {n: i for i, n in enumerate(invs)}
    keys = ("h", "rF", "rI", "hF", "hI", "s", "sF", "sI", "only_I", "both", "only_F")
    arr = {k: np.zeros(len(invs)) for k in keys}
    for c in faulty:
        i = pos[c["invoice_no"]]
        harmful, scored = c["label"] == "harmful", c["label"] in ("harmful", "benign")
        arr["s"][i] += scored
        arr["sF"][i] += scored and _halted(c, "F")
        arr["sI"][i] += scored and _halted(c, "I")
        if harmful:
            arr["h"][i] += 1
            arr["rF"][i] += _committed(c, "F")
            arr["rI"][i] += _committed(c, "I")
            arr["hF"][i] += _halted(c, "F")
            arr["hI"][i] += _halted(c, "I")
            arr["only_I"][i] += _committed(c, "F") and _halted(c, "I")
            arr["both"][i] += _committed(c, "F") and _committed(c, "I")
            arr["only_F"][i] += _halted(c, "F") and _committed(c, "I")
    if not invs:
        return {"n_inv": 0}
    idx = seeding.make_rng(seed).integers(0, len(invs), size=(resamples, len(invs)))
    sums = {k: v[idx].sum(axis=1) for k, v in arr.items()}
    return {"n_inv": len(invs), "sums": sums}


def _ratio_ci(boot: Dict[str, Any], num: str, den: str, scale: float = 1.0):
    if boot["n_inv"] == 0:
        return None, None
    d = boot["sums"][den]
    ok = d > 0
    return _pct(boot["sums"][num][ok] / d[ok] * scale)


def _diff_ci(boot: Dict[str, Any]):
    if boot["n_inv"] == 0:
        return None, None
    d = boot["sums"]["h"]
    ok = d > 0
    return _pct((boot["sums"]["rF"][ok] - boot["sums"]["rI"][ok]) / d[ok] * 100.0)


# ------------------------------------------------------------------ main computation
def compute(manifest: Sequence[Dict[str, Any]], logs: Sequence[Dict[str, Any]], labels: Sequence[Dict[str, Any]],
            seeds: Dict[str, int], predictions: Optional[Dict[str, bool]] = None, resamples: int = RESAMPLES) -> Dict[str, List[Dict[str, Any]]]:
    cases = join_cases(manifest, logs, labels)
    clean = [c for c in cases if c["fault_type"] == "CLEAN"]
    faulty = [c for c in cases if c["fault_type"] != "CLEAN"]
    harmful = [c for c in faulty if c["label"] == "harmful"]
    scored = [c for c in faulty if c["label"] in ("harmful", "benign")]
    boot = _bootstrap(faulty, seeds["bootstrap"], resamples)
    T: Dict[str, List[Dict[str, Any]]] = {}

    N = len(harmful)
    reach = {c_: sum(_committed(c, c_) for c in harmful) for c_ in ("F", "I")}
    halt_h = {c_: sum(_halted(c, c_) for c in harmful) for c_ in ("F", "I")}
    only_i = sum(_committed(c, "F") and _halted(c, "I") for c in harmful)
    both = sum(_committed(c, "F") and _committed(c, "I") for c in harmful)
    only_f = sum(_halted(c, "F") and _committed(c, "I") for c in harmful)

    S: List[Dict[str, Any]] = []
    def add(metric, name, scope, num, den, val, lo=None, hi=None, method="", note=""):
        S.append({"metric": metric, "name": name, "scope": scope, "numerator": num, "denominator": den,
                  "value": val, "ci_low": lo, "ci_high": hi, "ci_method": method, "note": note})

    BOOT = "invoice-level bootstrap"
    for c_, key in (("F", "rF"), ("I", "rI")):                                            # M1
        lo, hi = _ratio_ci(boot, key, "h")
        add("M1", "harmful faulty cases that reached the commit", c_, reach[c_], N, rate(reach[c_], N), lo, hi, BOOT)
    diff = None if N == 0 else (reach["F"] - reach["I"]) / N * 100
    dlo, dhi = _diff_ci(boot)
    add("M1d", "M1(F) minus M1(I), percentage points", "F-I", None, None, diff, dlo, dhi, BOOT, "higher = bigger benefit of I")
    for c_, key in (("F", "hF"), ("I", "hI")):                                            # M2
        lo, hi = _ratio_ci(boot, key, "h")
        add("M2", "containment rate (harmful faulty cases halted)", c_, halt_h[c_], N, rate(halt_h[c_], N), lo, hi, BOOT,
            "equals 1 - M1 unless some harmful cases crashed in that condition")
    for c_, key in (("F", "sF"), ("I", "sI")):                                            # M3
        k = sum(_halted(c, c_) for c in scored)
        lo, hi = _ratio_ci(boot, key, "s")
        add("M3", "detection recall (faulty cases halted; crashes and skipped excluded)", c_, k, len(scored), rate(k, len(scored)), lo, hi, BOOT)
    for c_ in ("F", "I"):                                                                 # M4
        k = sum(_halted(c, c_) for c in clean)
        lo, hi = wilson(k, len(clean))
        add("M4", "false-positive rate (clean cases halted)", c_, k, len(clean), rate(k, len(clean)), lo, hi, "Wilson")
    runs = {c_: len(cases) for c_ in CONDS}
    apps = {c_: sum(c[f"apps_{c_}"] for c in cases) for c_ in CONDS}
    add("M5", "total rule applications", "F", apps["F"], runs["F"], rate(apps["F"], runs["F"]), note="per run")
    add("M5", "total rule applications", "I", apps["I"], runs["I"], rate(apps["I"], runs["I"]), note="per run")
    add("M5", "extra rule applications, I minus F", "I-F", apps["I"] - apps["F"], None, None)
    add("M5", "ratio of rule applications, I to F", "I/F", apps["I"], apps["F"], rate(apps["I"], apps["F"]))
    for t in FAULT_TYPES:                                                                 # M6
        ht = [c for c in harmful if c["fault_type"] == t]
        for c_ in ("F", "I"):
            k = sum(_committed(c, c_) for c in ht)
            lo, hi = wilson(k, len(ht))
            add("M6", "per-type reach-commit rate", f"{t}/{c_}", k, len(ht), rate(k, len(ht)), lo, hi, "Wilson")
    for m, name, k, key in (("M7", "caught only by I", only_i, "only_I"), ("M8", "missed by both", both, "both"),
                            ("M9", "caught only by F (must be 0)", only_f, "only_F")):   # M7-M9
        lo, hi = _ratio_ci(boot, key, "h")
        add(m, name, "all", k, N, rate(k, N), lo, hi, BOOT, "validity check: any value above 0 is an implementation defect" if m == "M9" else "")
    for c_ in ("F", "I"):                                                                 # M10
        halted = [c for c in scored if _halted(c, c_)]
        cnt = Counter(c[f"cp_{c_}"] for c in halted)
        for cp in CHECKPOINTS:
            add("M10", "halting attribution (share of halted faulty cases)", f"{c_}/{cp}", cnt.get(cp, 0), len(halted), rate(cnt.get(cp, 0), len(halted)))
    benign = sum(c["label"] == "benign" for c in faulty)                                  # M11
    add("M11", "benign share (B0 record equals reference)", "all", benign, len(scored), rate(benign, len(scored)))
    T["metrics_summary"] = S

    # ---------------- R1
    m1 = {r["scope"]: r for r in S if r["metric"] == "M1"}
    T["R1_primary"] = [{"condition": c_, "harmful_N": N, "reached_commit_n": reach[c_], "M1_rate": m1[c_]["value"],
                        "ci_low": m1[c_]["ci_low"], "ci_high": m1[c_]["ci_high"]} for c_ in ("F", "I")] + \
                      [{"condition": "F minus I (M1d, points)", "harmful_N": N, "reached_commit_n": None, "M1_rate": diff, "ci_low": dlo, "ci_high": dhi}]
    # ---------------- R2, R4
    R2, R4, R4b = [], [], []
    for t in FAULT_TYPES:
        rows_t = [r for r in manifest if r["fault_type"] == t]
        ft = [c for c in faulty if c["fault_type"] == t]
        ht = [c for c in harmful if c["fault_type"] == t]
        rf = sum(_committed(c, "F") for c in ht); ri = sum(_committed(c, "I") for c in ht)
        R2.append({"type": t, "injected": sum(r["status"] == "inject" for r in rows_t),
                   "skipped": sum(r["status"] == "skipped" for r in rows_t), "crashed": sum(c["label"] == "crash" for c in ft),
                   "harmful": len(ht), "benign": sum(c["label"] == "benign" for c in ft),
                   "F_reached_n": rf, "F_reached_pct": None if not ht else 100 * rf / len(ht),
                   "I_reached_n": ri, "I_reached_pct": None if not ht else 100 * ri / len(ht),
                   "caught_only_by_I": sum(_committed(c, "F") and _halted(c, "I") for c in ht),
                   "missed_by_both": sum(_committed(c, "F") and _committed(c, "I") for c in ht)})
        halted = [c for c in ft if c["label"] in ("harmful", "benign") and _halted(c, "I")]
        cnt = Counter(c["cp_I"] for c in halted)
        R4.append({"type": t, **{cp: cnt.get(cp, 0) for cp in CHECKPOINTS}, "total_halted": len(halted)})
        for (cp, rule), n in sorted(Counter((c["cp_I"], c["rule_I"]) for c in halted).items()):
            R4b.append({"type": t, "checkpoint": cp, "rule_id": rule, "count": n})
    T["R2_per_type"], T["R4_halting_attribution"], T["R4b_halting_by_rule"] = R2, R4, R4b
    # ---------------- R3
    T["R3_outcome_overlap"] = [
        {"row": "F halted", "I_halted": sum(_halted(c, "F") and _halted(c, "I") for c in harmful), "I_committed": only_f},
        {"row": "F committed", "I_halted": only_i, "I_committed": both}]
    # ---------------- R5, R6
    T["R5_clean_false_alarms"] = [{"condition": c_, "clean_cases": len(clean), "halted": sum(_halted(c, c_) for c in clean),
                                   "M4_rate": rate(sum(_halted(c, c_) for c in clean), len(clean)),
                                   "ci_low": wilson(sum(_halted(c, c_) for c in clean), len(clean))[0],
                                   "ci_high": wilson(sum(_halted(c, c_) for c in clean), len(clean))[1]} for c_ in ("F", "I")]
    T["R5b_false_alarm_cases"] = [{"case_id": c["case_id"], "condition": c_, "rule_id": c[f"rule_{c_}"], "checkpoint": c[f"cp_{c_}"],
                                   "values": c[f"detail_{c_}"], "classification": ""}
                                  for c in clean for c_ in ("F", "I") if _halted(c, c_)]
    T["R6_cost"] = [{"condition": c_, "runs": runs[c_], "total_rule_applications": apps[c_], "mean_per_run": rate(apps[c_], runs[c_]),
                     "ratio_to_F": rate(apps[c_], apps["F"])} for c_ in CONDS]
    # ---------------- R7
    missed = [c for c in harmful if _committed(c, "F") and _committed(c, "I")]
    if len(missed) > 50:
        pick = sorted(seeding.make_rng(seeds["missed_case_review"]).choice(len(missed), size=50, replace=False).tolist())
        missed = [missed[i] for i in pick]
    T["R7_missed_by_both_review"] = [{"case_id": c["case_id"], "fault_type": c["fault_type"], "category": "", "note": ""} for c in missed]
    # ---------------- R8
    R8: List[Dict[str, Any]] = []
    for (t, reason), n in sorted(Counter((r["fault_type"], r["skip_reason"]) for r in manifest if r["status"] == "skipped").items()):
        R8.append({"item": f"{t} skipped", "count": n, "description": reason})
    R8.append({"item": "T4 cases drawn from the T4-capable reserve", "count": sum(r.get("source") == "t4_reserve" and r["status"] == "inject" for r in manifest), "description": "outside all subsets; one T4 case, no clean case"})
    for c_ in CONDS:
        R8.append({"item": f"crashed cases under {c_}", "count": sum(c[f"out_{c_}"] == "CRASHED" for c in cases), "description": "loud failure, excluded"})
    R8.append({"item": "faulty cases labelled crash by B0", "count": sum(c["label"] == "crash" for c in faulty), "description": "excluded from M3 and M11"})
    R8.append({"item": "faulty cases with implementation_defect label", "count": sum(c["label"] == "implementation_defect" for c in faulty), "description": "B0 neither committed nor crashed"})
    R8.append({"item": "clean cases whose B0 record differs from the oracle reference", "count": sum(c["label"] == "reference_mismatch" for c in clean), "description": "must be 0"})
    R8.append({"item": "B0 runs that applied any rule", "count": sum(c["apps_B0"] > 0 for c in cases), "description": "must be 0"})
    R8.append({"item": "M9 violations (harmful: halted by F, committed by I)", "count": only_f, "description": "must be 0"})
    zero = [t for t in FAULT_TYPES if not any(c["fault_type"] == t and c["label"] == "harmful" for c in faulty)]
    R8.append({"item": "fault types with no harmful case", "count": len(zero), "description": ", ".join(zero)})
    for t in FAULT_TYPES:
        R8.append({"item": f"{t} benign cases", "count": sum(c["fault_type"] == t and c["label"] == "benign" for c in faulty), "description": "B0 record equals reference"})
    T["R8_exclusions_anomalies"] = R8
    # ---------------- R9
    fprI, fprF = rate(sum(_halted(c, "I") for c in clean), len(clean)), rate(sum(_halted(c, "F") for c in clean), len(clean))
    rq1_met = diff is not None and dlo is not None and diff >= 10 and dlo > 0
    rq3_met = fprI is not None and fprF is not None and fprI <= 0.02 and fprI <= fprF + 0.02
    if predictions is None:
        rq2_obs, rq2_met = "NOT EVALUATED: results/predictions.json (dated predictions for T1-T5) not found", ""
    else:
        correct = 0
        for t in FAULT_TYPES:
            ht = [c for c in harmful if c["fault_type"] == t]
            escapes = bool(ht) and sum(_committed(c, "F") for c in ht) / len(ht) >= 0.10
            correct += bool(predictions[t]) == escapes
        rq2_obs, rq2_met = f"{correct} of 5 predictions correct", correct >= 4
    T["R9_decision_rules"] = [
        {"rule": "RQ1", "threshold": "M1d at least 10 points and 95% interval excludes 0", "observed": f"{diff} (CI {dlo}, {dhi})" if diff is not None else "no harmful cases", "met": rq1_met},
        {"rule": "RQ2", "threshold": "at least 4 of 5 predictions correct (escapes F = at least 10% of the type's harmful cases)", "observed": rq2_obs, "met": rq2_met},
        {"rule": "RQ3", "threshold": "FPR(I) at most 2% and at most FPR(F) + 2 points", "observed": f"FPR(I)={fprI}, FPR(F)={fprF}", "met": rq3_met}]
    # ---------------- per-case table for traceability
    T["cases_joined"] = [{k: v for k, v in c.items() if not k.startswith("detail_")} for c in cases]
    return T
