"""Verification rules: CP1, CP2, CP3 and the final validation (ids as in Prompt 07 Part 5).

Independence rule: each function receives ONLY the data available at its own point in the pipeline
plus the calibration constants. No function here knows about faults, the manifest, the oracle or B0.
Rules run in order and stop at the first failure. Nothing is repaired.
One 'application' = one rule applied to one line or to one record (used for the cost metric M5).
"""

from __future__ import annotations

import re
from dataclasses import dataclass
from typing import Any, Dict, FrozenSet, List, Optional

from g1.money import line_amount

FIVE_DIGITS = re.compile(r"\d{5}")
COMMIT_FIELDS = {"invoice_no": str, "customer_id": str, "country": str, "n_lines": int,
                 "invoice_total": int, "decision": str}


@dataclass(frozen=True)
class RuleConstants:
    q_max: int
    p_max_pence: int
    t_max_pence: int
    countries: FrozenSet[str]
    l_pence: int

    def to_json(self) -> Dict[str, Any]:
        return {"q_max": self.q_max, "p_max_pence": self.p_max_pence, "t_max_pence": self.t_max_pence,
                "countries": sorted(self.countries), "l_pence": self.l_pence}

    @staticmethod
    def from_json(d: Dict[str, Any]) -> "RuleConstants":
        return RuleConstants(int(d["q_max"]), int(d["p_max_pence"]), int(d["t_max_pence"]),
                             frozenset(d["countries"]), int(d["l_pence"]))


@dataclass
class CheckResult:
    passed: bool
    checkpoint: str
    applications: int
    rule_id: Optional[str] = None
    detail: str = ""


def _is_int(v: Any) -> bool:
    return isinstance(v, int) and not isinstance(v, bool)


def _is_number(v: Any) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool)


def _fail(cp: str, apps: int, rule: str, detail: str) -> CheckResult:
    return CheckResult(False, cp, apps, rule, detail)


def _lines(request: Dict[str, Any]) -> List[Dict[str, Any]]:
    lines = request.get("lines")
    return lines if isinstance(lines, list) else []


# ------------------------------------------------------------------ CP1: S1 output (the request)
def cp1(request: Dict[str, Any], c: RuleConstants) -> CheckResult:
    apps = 1                                                              # R1.1: one record
    cid = request.get("customer_id")
    if not (isinstance(cid, str) and FIVE_DIGITS.fullmatch(cid)):
        return _fail("CP1", apps, "R1.1", f"customer_id={cid!r} is not present and 5 digits")
    lines = _lines(request)
    for i, ln in enumerate(lines):                                        # R1.2: one application per line
        apps += 1
        for key in ("stock_code", "quantity", "unit_price"):
            if ln.get(key) is None:
                return _fail("CP1", apps, "R1.2", f"line {i}: {key} is missing")
    for i, ln in enumerate(lines):                                        # R1.3
        apps += 1
        if not _is_int(ln["quantity"]) or not _is_number(ln["unit_price"]):
            return _fail("CP1", apps, "R1.3", f"line {i}: quantity={ln['quantity']!r} unit_price={ln['unit_price']!r}")
    for i, ln in enumerate(lines):                                        # R1.4
        apps += 1
        if not (1 <= ln["quantity"] <= c.q_max and 0 < ln["unit_price"] <= c.p_max_pence):
            return _fail("CP1", apps, "R1.4", f"line {i}: quantity={ln['quantity']} unit_price={ln['unit_price']}")
    return CheckResult(True, "CP1", apps)


# ------------------------------------------------------------------ CP2: S2 output (line amounts)
def cp2(request: Dict[str, Any], amounts: List[Any]) -> CheckResult:
    lines, apps = _lines(request), 0
    if len(amounts) != len(lines):
        return _fail("CP2", 1, "R2.1", f"{len(amounts)} amounts for {len(lines)} lines")
    for i, (ln, amt) in enumerate(zip(lines, amounts)):                   # R2.1: exact pence recomputation
        apps += 1
        q, p = ln.get("quantity"), ln.get("unit_price")
        if not (_is_int(q) and _is_int(p)):
            return _fail("CP2", apps, "R2.1", f"line {i}: cannot recompute from quantity={q!r} unit_price={p!r}")
        if amt != line_amount(q, p):
            return _fail("CP2", apps, "R2.1", f"line {i}: amount {amt!r} != {q} x {p}")
    for i, amt in enumerate(amounts):                                     # R2.2
        apps += 1
        if not _is_number(amt) or amt < 0:
            return _fail("CP2", apps, "R2.2", f"line {i}: amount {amt!r} is negative or not a number")
    return CheckResult(True, "CP2", apps)


# ------------------------------------------------------------------ CP3: S3 output (the state)
def cp3(request: Dict[str, Any], amounts: List[Any], state: Dict[str, Any]) -> CheckResult:
    apps = 1                                                              # R3.1: one record
    for key in ("invoice_no", "customer_id", "country"):
        if state.get(key) != request.get(key):
            return _fail("CP3", apps, "R3.1", f"{key}: state {state.get(key)!r} != request {request.get(key)!r}")
    apps += 1                                                             # R3.2
    if state.get("n_lines") != len(_lines(request)):
        return _fail("CP3", apps, "R3.2", f"n_lines {state.get('n_lines')!r} != {len(_lines(request))}")
    apps += 1                                                             # R3.3
    if state.get("invoice_total") != sum(amounts):
        return _fail("CP3", apps, "R3.3", f"invoice_total {state.get('invoice_total')!r} != sum of amounts {sum(amounts)}")
    return CheckResult(True, "CP3", apps)


# ------------------------------------------------------------------ Final validation: commit record only
def final_validation(record: Dict[str, Any], c: RuleConstants) -> CheckResult:
    apps = 1                                                              # RF.1
    for key, typ in COMMIT_FIELDS.items():
        v = record.get(key)
        if not isinstance(v, typ) or isinstance(v, bool):
            return _fail("FINAL", apps, "RF.1", f"field {key}={v!r} is missing or not {typ.__name__}")
    apps += 1                                                             # RF.2
    if not FIVE_DIGITS.fullmatch(record["customer_id"]):
        return _fail("FINAL", apps, "RF.2", f"customer_id={record['customer_id']!r}")
    apps += 1                                                             # RF.3
    if record["country"] not in c.countries:
        return _fail("FINAL", apps, "RF.3", f"country={record['country']!r} not in the allowed set")
    apps += 1                                                             # RF.4
    if not (0 < record["invoice_total"] <= c.t_max_pence):
        return _fail("FINAL", apps, "RF.4", f"invoice_total={record['invoice_total']} outside (0, {c.t_max_pence}]")
    apps += 1                                                             # RF.5
    if record["n_lines"] < 1:
        return _fail("FINAL", apps, "RF.5", f"n_lines={record['n_lines']}")
    apps += 1                                                             # RF.6
    expected = "POST" if record["invoice_total"] <= c.l_pence else "HOLD"
    if record["decision"] != expected:
        return _fail("FINAL", apps, "RF.6", f"decision {record['decision']!r} != {expected!r} for total {record['invoice_total']}")
    return CheckResult(True, "FINAL", apps)
