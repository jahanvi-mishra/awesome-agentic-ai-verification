"""Fault injection (T1-T5) driven by a manifest built once, deterministically, before any condition runs.

Manifest = a list of rows, one per case (clean or faulty). Injection only APPLIES a manifest row; it never
decides anything. The pipeline and the checkpoints never see the manifest (see pipeline.run_pipeline hook).

Draw order (documented, fixed): invoices sorted by InvoiceNo; for each invoice the fault types T1..T5 in
order; each type ALWAYS consumes a fixed number of draws (T1: 2, T2: 1, T3: 2, T4: 2, T5: 2), even when the
fault is skipped, so skipping one case never shifts the random choices of other cases.
Each draw is an integer in [0, 2**31-1) taken from one numpy Generator (the fault seed).

T1 S1 output  remove CustomerID, or one line's UnitPrice
T2 S1 output  one Quantity becomes its digits + " pcs"
T3 S1 output  one Quantity becomes negative, or 10 x Q_max
T4 S2 output  one line amount uses the UnitPrice of a different line with a different price (else skipped)
T5 S3 output  invoice_total or CustomerID replaced by another invoice's value (equal values -> skipped)
"""

from __future__ import annotations

import hashlib
import json
from typing import Any, Callable, Dict, List

import numpy as np

from g1.data_prep import BaseInvoice
from g1.money import line_amount
from g1.rules import RuleConstants

FAULT_TYPES = ("T1", "T2", "T3", "T4", "T5")
DRAWS = {"T1": 2, "T2": 1, "T3": 2, "T4": 2, "T5": 2}
STAGE = {"T1": "S1", "T2": "S1", "T3": "S1", "T4": "S2", "T5": "S3"}


class InjectionError(RuntimeError):
    """The data at the injection point did not match the manifest (an injection defect, not a pipeline fault)."""


def _total(inv: BaseInvoice) -> int:
    return sum(line_amount(l.quantity, l.unit_price_pence) for l in inv.lines)


def _row(inv: BaseInvoice, ftype: str, status: str, **kw: Any) -> Dict[str, Any]:
    base = {"case_id": f"{inv.invoice_no}-{ftype}", "invoice_no": inv.invoice_no, "fault_type": ftype,
            "status": status, "stage": STAGE.get(ftype), "skip_reason": None, "params": {},
            "original_value": None, "faulty_value": None}
    base.update(kw)
    return base


def _t4_row(inv: BaseInvoice, u: List[int]) -> Dict[str, Any]:
    """T4 row for one invoice from two draws: injected if the invoice has >= 2 distinct unit prices, else skipped."""
    usable = [k for k, a in enumerate(inv.lines) if any(b.unit_price_pence != a.unit_price_pence for b in inv.lines)]
    if not usable:
        return _row(inv, "T4", "skipped", skip_reason="all unit prices equal")
    k = usable[u[0] % len(usable)]
    others = [j for j, b in enumerate(inv.lines) if b.unit_price_pence != inv.lines[k].unit_price_pence]
    j = others[u[1] % len(others)]
    return _row(inv, "T4", "inject", params={"line_index": k, "other_line_index": j},
                original_value=line_amount(inv.lines[k].quantity, inv.lines[k].unit_price_pence),
                faulty_value=line_amount(inv.lines[k].quantity, inv.lines[j].unit_price_pence))


def build_t4_topup(reserve: List[BaseInvoice], needed: int, rng: np.random.Generator) -> List[Dict[str, Any]]:
    """Extra T4 cases so that T4 reaches the full count while being drawn ONLY from T4-capable invoices.

    `reserve` = invoices outside calibration, pilot and evaluation, in a fixed order (see split.reserve_after_split).
    Walk the reserve in order, skip invoices that are not T4-capable, and take capable ones until `needed` T4 cases
    exist. Each taken invoice uses 2 draws from the SAME fault generator, continuing after the main manifest.
    Top-up rows carry source='t4_reserve'. Other fault types are untouched and cover all evaluation invoices.
    """
    rows: List[Dict[str, Any]] = []
    for inv in reserve:
        if len(rows) >= needed:
            break
        if len({l.unit_price_pence for l in inv.lines}) < 2:
            continue
        u = [int(x) for x in rng.integers(0, 2**31 - 1, size=DRAWS["T4"])]
        row = _t4_row(inv, u)
        row["source"] = "t4_reserve"
        rows.append(row)
    if len(rows) < needed:
        raise ValueError(f"Reserve has only {len(rows)} T4-capable invoices but {needed} are needed")
    return rows


def build_manifest(invoices: List[BaseInvoice], constants: RuleConstants, rng: np.random.Generator) -> List[Dict[str, Any]]:
    """One CLEAN row and five fault rows per invoice, in fixed order."""
    pool = sorted(invoices, key=lambda i: i.invoice_no)
    rows: List[Dict[str, Any]] = []
    draw = lambda n: [int(x) for x in rng.integers(0, 2**31 - 1, size=n)]
    for inv in pool:
        n = len(inv.lines)
        rows.append(_row(inv, "CLEAN", "clean"))

        u = draw(DRAWS["T1"])                                              # T1
        if u[0] % 2 == 0:
            rows.append(_row(inv, "T1", "inject", params={"target": "customer_id"},
                             original_value=inv.customer_id, faulty_value=None))
        else:
            k = u[1] % n
            rows.append(_row(inv, "T1", "inject", params={"target": "unit_price", "line_index": k},
                             original_value=inv.lines[k].unit_price_pence, faulty_value=None))

        u = draw(DRAWS["T2"])                                              # T2
        k = u[0] % n
        q = inv.lines[k].quantity
        rows.append(_row(inv, "T2", "inject", params={"line_index": k}, original_value=q, faulty_value=f"{q} pcs"))

        u = draw(DRAWS["T3"])                                              # T3
        k, q = u[1] % n, inv.lines[u[1] % n].quantity
        if u[0] % 2 == 0:
            rows.append(_row(inv, "T3", "inject", params={"variant": "negative", "line_index": k},
                             original_value=q, faulty_value=-q))
        else:
            rows.append(_row(inv, "T3", "inject", params={"variant": "ten_times_q_max", "line_index": k},
                             original_value=q, faulty_value=10 * constants.q_max))

        u = draw(DRAWS["T4"])                                              # T4
        rows.append(_t4_row(inv, u))

        u = draw(DRAWS["T5"])                                              # T5
        partners = [p for p in pool if p.invoice_no != inv.invoice_no]
        if not partners:
            rows.append(_row(inv, "T5", "skipped", skip_reason="no other invoice in the subset"))
            continue
        partner = partners[u[1] % len(partners)]
        if u[0] % 2 == 0:
            target, own, other = "invoice_total", _total(inv), _total(partner)
        else:
            target, own, other = "customer_id", inv.customer_id, partner.customer_id
        if own == other:
            rows.append(_row(inv, "T5", "skipped", skip_reason=f"{target} values are equal",
                             params={"target": target, "partner": partner.invoice_no}))
        else:
            rows.append(_row(inv, "T5", "inject", params={"target": target, "partner": partner.invoice_no},
                             original_value=own, faulty_value=other))
    return rows


def manifest_hash(rows: List[Dict[str, Any]]) -> str:
    return hashlib.sha256(json.dumps(rows, sort_keys=True).encode("utf-8")).hexdigest()


def make_hook(row: Dict[str, Any]) -> Callable[[str, Any], Any]:
    """Hook for one case: applies the manifest row at its stage and leaves every other stage untouched."""
    def hook(stage: str, data: Any) -> Any:
        if row["status"] != "inject" or stage != row["stage"]:
            return data
        ftype, p, orig, new = row["fault_type"], row["params"], row["original_value"], row["faulty_value"]
        if ftype == "T1" and p["target"] == "customer_id":
            _expect(data["customer_id"], orig, row); data["customer_id"] = new
        elif ftype == "T1":
            _expect(data["lines"][p["line_index"]]["unit_price"], orig, row); data["lines"][p["line_index"]]["unit_price"] = new
        elif ftype in ("T2", "T3"):
            _expect(data["lines"][p["line_index"]]["quantity"], orig, row)
            data["lines"][p["line_index"]]["quantity"] = new
        elif ftype == "T4":
            _expect(data[p["line_index"]], orig, row); data[p["line_index"]] = new
        elif ftype == "T5":
            _expect(data[p["target"]], orig, row); data[p["target"]] = new
        return data
    return hook


def _expect(actual: Any, original: Any, row: Dict[str, Any]) -> None:
    if actual != original:
        raise InjectionError(f"case {row['case_id']}: expected original {original!r} but found {actual!r}")
