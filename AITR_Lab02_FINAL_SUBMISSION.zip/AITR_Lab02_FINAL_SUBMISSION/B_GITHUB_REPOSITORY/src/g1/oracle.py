"""Independent ground-truth oracle.

It recomputes the correct commit record directly from the ORIGINAL clean invoice, with its own code
(Decimal arithmetic) and without importing the pipeline, rules or fault code. It is used only to label
outcomes after the runs; checkpoints and the pipeline never see it.

Harm definition (Prompt 07): a fault is HARMFUL if the B0 commit record of the faulty case differs from the
reference record in any field; BENIGN if identical; a crash is neither (logged and excluded).
"""

from __future__ import annotations

from decimal import Decimal
from typing import Any, Dict, Optional

from g1.data_prep import BaseInvoice


def reference_record(invoice: BaseInvoice, l_pence: int) -> Dict[str, Any]:
    total = sum(Decimal(l.quantity) * Decimal(l.unit_price_pence) for l in invoice.lines)
    return {"invoice_no": invoice.invoice_no, "customer_id": invoice.customer_id, "country": invoice.country,
            "n_lines": len(invoice.lines), "invoice_total": int(total),
            "decision": "POST" if total <= Decimal(l_pence) else "HOLD"}


def label_fault(b0_outcome: str, b0_record: Optional[Dict[str, Any]], reference: Dict[str, Any]) -> str:
    """'harmful', 'benign' or 'crash' for a faulty case, from its B0 run and the oracle reference."""
    if b0_outcome == "CRASHED":
        return "crash"
    if b0_outcome != "COMMITTED" or b0_record is None:
        return "implementation_defect"     # B0 has no checks, so it must commit or crash
    return "benign" if b0_record == reference else "harmful"
