"""Run cases under B0, F and I and write structured logs (JSON lines).

Identical cases, identical order and a fresh ledger for every run. Run logs contain the case id and the
pipeline outcome only: fault types live in the manifest and are joined later by case id.
"""

from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence

from g1 import faults, oracle, pipeline
from g1.data_prep import BaseInvoice
from g1.rules import RuleConstants


@dataclass(frozen=True)
class Case:
    case_id: str
    invoice: BaseInvoice
    fault_row: Dict[str, Any]


def build_cases(invoices: Sequence[BaseInvoice], manifest: List[Dict[str, Any]]) -> List[Case]:
    """Cases in manifest order; skipped faults are left out (they stay listed in the manifest)."""
    by_no = {i.invoice_no: i for i in invoices}
    return [Case(r["case_id"], by_no[r["invoice_no"]], r) for r in manifest if r["status"] in ("clean", "inject")]


def run_cases(cases: Sequence[Case], constants: RuleConstants, conditions: Sequence[str] = pipeline.CONDITIONS) -> List[Dict[str, Any]]:
    logs: List[Dict[str, Any]] = []
    for case in cases:
        for cond in conditions:
            hook = faults.make_hook(case.fault_row)
            logs.append(pipeline.run_pipeline(case.case_id, case.invoice, cond, constants, hook).to_log())
    return logs


def label_cases(cases: Sequence[Case], b0_logs: Sequence[Dict[str, Any]], constants: RuleConstants) -> List[Dict[str, Any]]:
    """Oracle labels from the B0 logs: faulty -> harmful/benign/crash; clean -> whether B0 equals the reference."""
    b0 = {l["case_id"]: l for l in b0_logs if l["condition"] == "B0"}
    out = []
    for case in cases:
        ref = oracle.reference_record(case.invoice, constants.l_pence)
        log = b0[case.case_id]
        if case.fault_row["status"] == "clean":
            label = "reference_match" if log["commit_record"] == ref else "reference_mismatch"
        else:
            label = oracle.label_fault(log["outcome"], log["commit_record"], ref)
        out.append({"case_id": case.case_id, "fault_type": case.fault_row["fault_type"], "label": label})
    return out


def write_jsonl(path: Path, rows: Sequence[Dict[str, Any]]) -> str:
    """Write once (never overwrite). Returns the SHA-256 of the file."""
    text = "".join(json.dumps(r, sort_keys=True) + "\n" for r in rows)
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "x", encoding="utf-8") as fh:
        fh.write(text)
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def logs_hash(logs: Sequence[Dict[str, Any]]) -> str:
    return hashlib.sha256("".join(json.dumps(r, sort_keys=True) + "\n" for r in logs).encode()).hexdigest()
