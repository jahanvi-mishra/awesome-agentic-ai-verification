"""The deterministic four-stage pipeline (a simulation of an agentic workflow, NOT an LLM agent).

  S1 Intake       invoice -> request (parsed values only, no defaults)
  S2 Transform    request -> one line amount per line, integer pence
  S3 State update request + amounts -> state (n_lines, invoice_total)
  S4 Decide       state -> commit record with POST/HOLD by limit L, then the final validation, then the ledger

Conditions: B0 no checks | F final validation only | I CP1, CP2, CP3, then the same final validation.
Later stages read a missing or unreadable value as a SILENT default (0 for numbers, "UNKNOWN" for text),
so injected faults travel downstream instead of crashing. Nothing is repaired, retried or rolled back.

This module imports no fault, manifest or oracle code. A `hook(stage, data)` callable (supplied by the
runner) is the only place where a fault can enter, right after a stage and before its checkpoint.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional

from g1 import rules
from g1.data_prep import BaseInvoice
from g1.money import line_amount

CONDITIONS = ("B0", "F", "I")
Hook = Callable[[str, Any], Any]


def _no_hook(stage: str, data: Any) -> Any:
    return data


class Ledger:
    """Append-only simulated ledger. A new one is created for every run."""

    def __init__(self) -> None:
        self._records: List[Dict[str, Any]] = []

    def append(self, record: Dict[str, Any]) -> None:
        self._records.append(dict(record))

    def __len__(self) -> int:
        return len(self._records)

    @property
    def records(self) -> List[Dict[str, Any]]:
        return [dict(r) for r in self._records]


@dataclass
class RunResult:
    case_id: str
    condition: str
    outcome: str                                   # COMMITTED | HALTED | CRASHED
    commit_record: Optional[Dict[str, Any]] = None
    halt_checkpoint: Optional[str] = None
    halt_rule: Optional[str] = None
    halt_detail: Optional[str] = None
    applications: Dict[str, int] = field(default_factory=dict)
    error: Optional[str] = None

    def to_log(self) -> Dict[str, Any]:
        return {"case_id": self.case_id, "condition": self.condition, "outcome": self.outcome,
                "halt_checkpoint": self.halt_checkpoint, "halt_rule": self.halt_rule, "halt_detail": self.halt_detail,
                "rule_applications": sum(self.applications.values()), "applications_by_checkpoint": dict(self.applications),
                "commit_record": self.commit_record, "error": self.error}


# ------------------------------------------------------------------ stages
def s1_intake(invoice: BaseInvoice) -> Dict[str, Any]:
    return {"invoice_no": invoice.invoice_no, "customer_id": invoice.customer_id, "country": invoice.country,
            "lines": [{"stock_code": l.stock_code, "quantity": l.quantity, "unit_price": l.unit_price_pence}
                      for l in invoice.lines]}


def _read_number(v: Any) -> int:
    """Silent default: ints pass; digit-only text is converted; anything else (None, '6 pcs', float) becomes 0."""
    if isinstance(v, bool):
        return 0
    if isinstance(v, int):
        return v
    if isinstance(v, str) and re.fullmatch(r"-?\d+", v.strip()):
        return int(v)
    return 0


def s2_transform(request: Dict[str, Any]) -> List[int]:
    return [line_amount(_read_number(l.get("quantity")), _read_number(l.get("unit_price"))) for l in request["lines"]]


def _read_text(v: Any) -> str:
    return "UNKNOWN" if v is None else v


def s3_state_update(request: Dict[str, Any], amounts: List[int]) -> Dict[str, Any]:
    return {"invoice_no": request["invoice_no"], "customer_id": _read_text(request.get("customer_id")),
            "country": _read_text(request.get("country")), "n_lines": len(request["lines"]),
            "invoice_total": sum(amounts)}


def s4_commit_record(state: Dict[str, Any], l_pence: int) -> Dict[str, Any]:
    return {"invoice_no": state["invoice_no"], "customer_id": state["customer_id"], "country": state["country"],
            "n_lines": state["n_lines"], "invoice_total": state["invoice_total"],
            "decision": "POST" if state["invoice_total"] <= l_pence else "HOLD"}


# ------------------------------------------------------------------ one run
def run_pipeline(case_id: str, invoice: BaseInvoice, condition: str, constants: rules.RuleConstants,
                 hook: Hook = _no_hook) -> RunResult:
    """Run one case under one condition with a fresh ledger. Halts at the first failed rule."""
    if condition not in CONDITIONS:
        raise ValueError(f"Unknown condition {condition!r}; expected one of {CONDITIONS}")
    apps: Dict[str, int] = {}
    ledger = Ledger()

    def halted(chk: rules.CheckResult) -> RunResult:
        apps[chk.checkpoint] = chk.applications
        return RunResult(case_id, condition, "HALTED", None, chk.checkpoint, chk.rule_id, chk.detail, apps)

    try:
        request = hook("S1", s1_intake(invoice))
        if condition == "I":
            chk = rules.cp1(request, constants)
            if not chk.passed:
                return halted(chk)
            apps["CP1"] = chk.applications
        amounts = hook("S2", s2_transform(request))
        if condition == "I":
            chk = rules.cp2(request, amounts)
            if not chk.passed:
                return halted(chk)
            apps["CP2"] = chk.applications
        state = hook("S3", s3_state_update(request, amounts))
        if condition == "I":
            chk = rules.cp3(request, amounts, state)
            if not chk.passed:
                return halted(chk)
            apps["CP3"] = chk.applications
        record = s4_commit_record(state, constants.l_pence)
        if condition in ("F", "I"):
            chk = rules.final_validation(record, constants)
            if not chk.passed:
                return halted(chk)
            apps["FINAL"] = chk.applications
        ledger.append(record)
        return RunResult(case_id, condition, "COMMITTED", ledger.records[0], None, None, None, apps)
    except Exception as exc:  # noqa: BLE001 - a crash is a loud failure: logged, never repaired or retried
        return RunResult(case_id, condition, "CRASHED", None, None, None, None, apps, f"{type(exc).__name__}: {exc}")
