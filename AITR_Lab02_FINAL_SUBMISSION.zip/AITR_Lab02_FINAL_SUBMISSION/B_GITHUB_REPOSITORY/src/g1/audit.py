"""Read-only audit of the Online Retail table. No cleaning, no dropping, no fixing.

The frame is read with dtype=object so wrong types stay visible (a number stored as text, a date stored
as a string, ...). Nothing here changes the DataFrame; every function returns facts (plain dicts).

Important: statistics computed here describe the WHOLE file for quality checking only. Rule constants
(Q_max, P_max, T_max, L, Country set) must come from the calibration subset, not from these numbers.
"""

from __future__ import annotations

import math
from typing import Any, Dict, List

import pandas as pd

EXPECTED_COLUMNS = ["InvoiceNo", "StockCode", "Description", "Quantity", "InvoiceDate",
                    "UnitPrice", "CustomerID", "Country"]
RE_NORMAL = r"^\d{6}$"       # usual invoice number: 6 digits
RE_CANCEL = r"^C\d{6}$"      # cancellation: 'C' + 6 digits (UCI documentation)


# ------------------------------------------------------------------ small helpers
def _f(x: Any):
    """float -> JSON-safe (NaN/inf become None)."""
    x = float(x)
    return None if math.isnan(x) or math.isinf(x) else x


def _txt(series: pd.Series) -> pd.Series:
    """Text view of a column: None for missing, str(value) otherwise."""
    return series.map(lambda v: None if pd.isna(v) else str(v))


def _num(series: pd.Series) -> pd.Series:
    return pd.to_numeric(series, errors="coerce")


def type_counts(series: pd.Series) -> Dict[str, int]:
    return {k: int(v) for k, v in series.map(lambda v: type(v).__name__).value_counts().items()}


def numeric_summary(num: pd.Series) -> Dict[str, Any]:
    s = num.dropna()
    if s.empty:
        return {"count": 0}
    q = s.quantile([0.01, 0.25, 0.5, 0.75, 0.99])
    return {"count": int(s.size), "min": _f(s.min()), "p01": _f(q[0.01]), "p25": _f(q[0.25]),
            "median": _f(q[0.5]), "p75": _f(q[0.75]), "p99": _f(q[0.99]), "max": _f(s.max()),
            "mean": _f(s.mean()), "std": _f(s.std())}


def _examples(df: pd.DataFrame, mask: pd.Series, cols: List[str], n: int = 5) -> List[Dict[str, str]]:
    return df.loc[mask, cols].head(n).astype(str).to_dict("records")


# ------------------------------------------------------------------ audit sections
def audit_structure(df: pd.DataFrame) -> Dict[str, Any]:
    cols = list(df.columns)
    return {"rows": int(len(df)), "columns": int(len(cols)), "column_names": [str(c) for c in cols],
            "expected_columns_missing": [c for c in EXPECTED_COLUMNS if c not in cols],
            "unexpected_columns": [str(c) for c in cols if c not in EXPECTED_COLUMNS],
            "value_types_per_column": {str(c): type_counts(df[c]) for c in cols}}


def audit_missing(df: pd.DataFrame) -> Dict[str, Any]:
    out = {}
    for c in df.columns:
        miss = int(df[c].isna().sum())
        blank = int(df[c].map(lambda v: isinstance(v, str) and v.strip() == "").sum())
        out[str(c)] = {"missing": miss, "missing_pct": _f(100.0 * miss / max(len(df), 1)),
                       "blank_or_whitespace_text": blank}
    return out


def audit_duplicates(df: pd.DataFrame) -> Dict[str, Any]:
    return {"extra_copies_of_full_rows": int(df.duplicated().sum()),
            "rows_in_any_duplicate_group": int(df.duplicated(keep=False).sum())}


def audit_invoice_no(df: pd.DataFrame) -> Dict[str, Any]:
    inv = _txt(df["InvoiceNo"])
    normal = inv.str.match(RE_NORMAL, na=False)
    cancel = inv.str.match(RE_CANCEL, na=False)
    missing = inv.isna()
    other = ~(normal | cancel | missing)
    qty = _num(df["Quantity"])
    lines = inv.dropna().groupby(inv.dropna()).size()
    return {
        "unique_invoice_numbers": int(inv.nunique()),
        "rows_pattern_6_digits": int(normal.sum()),
        "rows_pattern_C_plus_6_digits_cancellation": int(cancel.sum()),
        "rows_missing": int(missing.sum()),
        "rows_other_pattern": int(other.sum()),
        "other_pattern_examples": sorted(inv[other].unique().tolist())[:10],
        "cancelled_unique_invoices": int(inv[cancel].nunique()),
        "cancelled_rows_with_negative_quantity": int((cancel & (qty < 0)).sum()),
        "cancelled_rows_with_non_negative_quantity": int((cancel & (qty >= 0)).sum()),
        "non_cancelled_rows_with_negative_quantity": int(((normal | other) & (qty < 0)).sum()),
        "lines_per_invoice": numeric_summary(lines.astype(float)),
    }


def audit_quantity(df: pd.DataFrame) -> Dict[str, Any]:
    raw, num = df["Quantity"], _num(df["Quantity"])
    return {"non_numeric_values": int((raw.notna() & num.isna()).sum()),
            "zero": int((num == 0).sum()), "negative": int((num < 0).sum()),
            "non_integer": int((num.notna() & (num % 1 != 0)).sum()),
            "summary": numeric_summary(num)}


def audit_unit_price(df: pd.DataFrame) -> Dict[str, Any]:
    raw, num = df["UnitPrice"], _num(df["UnitPrice"])
    return {"non_numeric_values": int((raw.notna() & num.isna()).sum()),
            "zero": int((num == 0).sum()), "negative": int((num < 0).sum()),
            "negative_examples": _examples(df, num < 0, ["InvoiceNo", "StockCode", "Description", "Quantity", "UnitPrice"]),
            "summary": numeric_summary(num)}


def audit_customer_id(df: pd.DataFrame) -> Dict[str, Any]:
    raw, num = df["CustomerID"], _num(df["CustomerID"])
    inv = _txt(df["InvoiceNo"])
    has = raw.notna()
    per_inv_missing = (~has).groupby(inv).any()
    per_inv_all_missing = (~has).groupby(inv).all()
    return {"missing_rows": int((~has).sum()),
            "non_numeric_values": int((has & num.isna()).sum()),
            "non_integer_values": int((num.notna() & (num % 1 != 0)).sum()),
            "unique_customers": int(num.nunique()),
            "invoices_with_any_missing_customer": int(per_inv_missing.sum()),
            "invoices_with_all_customer_missing": int(per_inv_all_missing.sum()),
            "min": _f(num.min()), "max": _f(num.max())}


def audit_country(df: pd.DataFrame) -> Dict[str, Any]:
    raw = df["Country"]
    txt = _txt(raw)
    counts = txt.value_counts()
    norm = txt.dropna().str.strip().str.casefold()
    variants = txt.dropna().groupby(norm).nunique()
    return {"missing_rows": int(raw.isna().sum()),
            "non_text_values": int((raw.notna() & ~raw.map(lambda v: isinstance(v, str))).sum()),
            "unique_values": int(txt.nunique()),
            "values_with_edge_whitespace": int((txt.dropna() != txt.dropna().str.strip()).sum()),
            "spelling_or_case_variants_of_same_name": sorted(variants[variants > 1].index.tolist()),
            "unspecified_rows": int((norm == "unspecified").sum()),
            "counts": {str(k): int(v) for k, v in counts.items()}}


def audit_dates(df: pd.DataFrame) -> Dict[str, Any]:
    parsed = pd.to_datetime(df["InvoiceDate"], errors="coerce")
    return {"missing": int(df["InvoiceDate"].isna().sum()),
            "unparseable_non_missing": int((df["InvoiceDate"].notna() & parsed.isna()).sum()),
            "earliest": None if parsed.dropna().empty else str(parsed.min()),
            "latest": None if parsed.dropna().empty else str(parsed.max())}


def audit_invoice_consistency(df: pd.DataFrame) -> Dict[str, Any]:
    """Case = one invoice, so one invoice should have ONE date, customer and country."""
    inv = _txt(df["InvoiceNo"])
    sub = pd.DataFrame({"inv": inv, "date": df["InvoiceDate"], "cust": df["CustomerID"], "country": df["Country"]})
    g = sub.dropna(subset=["inv"]).groupby("inv")[["date", "cust", "country"]].nunique(dropna=False)
    return {"invoices_with_more_than_one_date": int((g["date"] > 1).sum()),
            "invoices_with_more_than_one_customer_value": int((g["cust"] > 1).sum()),
            "invoices_with_more_than_one_country": int((g["country"] > 1).sum())}


def audit_candidate_pool(df: pd.DataFrame) -> Dict[str, Any]:
    """INFORMATIONAL: invoices with no obvious defect. NOT an approved case filter."""
    inv = _txt(df["InvoiceNo"])
    row_ok = (inv.str.match(RE_NORMAL, na=False) & (_num(df["Quantity"]) > 0) & (_num(df["UnitPrice"]) > 0)
              & pd.to_datetime(df["InvoiceDate"], errors="coerce").notna()
              & df["Country"].notna() & df["StockCode"].notna())
    ok = row_ok.groupby(inv).all()
    ok_cust = (row_ok & df["CustomerID"].notna()).groupby(inv).all()
    return {"note": "informational only; the real eligibility rule must be written and approved before use",
            "invoices_total": int(inv.nunique()),
            "invoices_with_no_row_level_defect": int(ok.sum()),
            "invoices_with_no_defect_and_customer_present": int(ok_cust.sum()),
            "needed_for_subsets_1000_calibration_50_pilot_500_evaluation": 1550}


def run_audit(df: pd.DataFrame) -> Dict[str, Any]:
    """Run every section. Raises ValueError if required columns are absent."""
    missing = [c for c in EXPECTED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Required columns missing from the file: {missing}. Columns found: {list(df.columns)}")
    return {
        "structure": audit_structure(df), "missing": audit_missing(df), "duplicates": audit_duplicates(df),
        "invoice_no": audit_invoice_no(df), "quantity": audit_quantity(df), "unit_price": audit_unit_price(df),
        "customer_id": audit_customer_id(df), "country": audit_country(df), "dates": audit_dates(df),
        "invoice_consistency": audit_invoice_consistency(df), "candidate_pool": audit_candidate_pool(df),
    }


# ------------------------------------------------------------------ report text
def _kv(d: Dict[str, Any]) -> str:
    return "\n".join(f"- {k}: {v}" for k, v in d.items())


def render_markdown(facts: Dict[str, Any], manifest: Dict[str, Any], meta: Dict[str, Any]) -> str:
    s, a = facts["structure"], facts
    L: List[str] = ["# Dataset audit report - UCI Online Retail (ID 352)", ""]
    L += [f"**Audit run (UTC):** {meta['run_utc']}", f"**Scope:** {meta['scope']}", ""]
    L += ["## 1. Source and file record", _kv({k: manifest.get(k) for k in (
        "official_page", "acquisition_mode", "requested_url", "final_url", "downloaded_utc", "registered_utc",
        "local_zip_filename", "url_filename", "zip_size_bytes", "zip_sha256", "xlsx_filename",
        "xlsx_size_bytes", "xlsx_sha256", "dataset_version", "licence_note")}), ""]
    L += ["Zip members:", "```", *[f"{m['name']}  {m['size_bytes']} bytes  crc32={m['crc32']}" for m in manifest["zip_members"]], "```", ""]
    L += ["## 2. Raw-file integrity", _kv(meta["integrity"]), ""]
    L += ["## 3. Structure", _kv({"sheets_in_workbook": meta["sheet_names"], "sheet_read": meta["sheet_read"],
                                   "rows": s["rows"], "columns": s["columns"], "column_names": s["column_names"],
                                   "expected_columns_missing": s["expected_columns_missing"],
                                   "unexpected_columns": s["unexpected_columns"]}), ""]
    L += ["Value types found per column (type name: count):", "```",
          *[f"{c}: {t}" for c, t in s["value_types_per_column"].items()], "```", ""]
    L += ["## 4. Missing values", "```", *[f"{c:12s} missing={m['missing']:>8d} ({m['missing_pct']:.2f}%)  blank_text={m['blank_or_whitespace_text']}"
                                           for c, m in a["missing"].items()], "```", ""]
    L += ["## 5. Duplicate rows", _kv(a["duplicates"]), ""]
    inv = dict(a["invoice_no"]); lines = inv.pop("lines_per_invoice")
    L += ["## 6. InvoiceNo and cancelled invoices", _kv(inv), f"- lines_per_invoice: {lines}", ""]
    L += ["## 7. Invoice consistency (one invoice should have one date, customer, country)", _kv(a["invoice_consistency"]), ""]
    for title, key in (("8. Quantity", "quantity"), ("9. UnitPrice", "unit_price")):
        d = dict(a[key]); summ = d.pop("summary"); ex = d.pop("negative_examples", None)
        L += [f"## {title}", _kv(d), f"- numeric summary: {summ}"]
        if ex is not None:
            L += ["- negative-price examples (first 5):", "```", *[str(r) for r in ex], "```"]
        L += [""]
    L += ["## 10. CustomerID", _kv(a["customer_id"]), ""]
    c = dict(a["country"]); counts = c.pop("counts")
    L += ["## 11. Country", _kv(c), "Counts:", "```", *[f"{k}: {v}" for k, v in counts.items()], "```", ""]
    L += ["## 12. InvoiceDate", _kv(a["dates"]), ""]
    L += ["## 13. Candidate invoice pool (informational, NOT an approved filter)", _kv(a["candidate_pool"]), ""]
    L += ["## 14. How to read this report",
          "- Nothing was modified, dropped or corrected; counts describe the file as received.",
          "- Whole-file statistics are for quality checking only. Do NOT set Q_max, P_max, T_max, L or the Country set from them; "
          "derive those from the calibration subset after the split (Prompt 07 protocol).",
          "- Invoice-total percentiles were deliberately not computed, so the 90th-percentile constant L cannot be set from all data by accident.",
          "- Whether this dataset is accepted by the teacher, and the eligibility rule for cases, remain UNKNOWN / unapproved.", ""]
    return "\n".join(L)
