"""G1 study: verification checkpoints for silent errors in a simulated agentic pipeline."""

__version__ = "0.1.0"
