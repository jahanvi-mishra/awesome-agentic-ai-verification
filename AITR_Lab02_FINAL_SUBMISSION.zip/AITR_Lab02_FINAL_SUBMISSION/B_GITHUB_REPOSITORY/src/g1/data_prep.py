"""Turn the raw Online Retail table into the base invoices used by the experiment (Scenario D).

Rules (Prompt 07 final decisions, v1.0), applied in this order, reusing g1.eligibility:
  1. not cancelled; every line valid (all fields present, Quantity > 0, UnitPrice > 0); at least 2 lines
  2. six-digit InvoiceNo; exact 2-decimal prices; five-digit CustomerID; integer Quantity;
     exactly one InvoiceDate value
  3. exclude any invoice with a zero-pence line (cannot occur after 2-decimal prices; counted anyway)
  4. remove invoices with duplicate content (full signature), keeping the first by sorted InvoiceNo
Repeated exact rows inside one invoice are KEPT. The raw table is never modified.
"""

from __future__ import annotations

import csv
import hashlib
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, List, Tuple

import pandas as pd

from g1 import eligibility as el

CSV_COLUMNS = ["invoice_no", "line_no", "stock_code", "quantity", "unit_price_pence", "customer_id", "country"]


@dataclass(frozen=True)
class BaseLine:
    stock_code: str
    quantity: int
    unit_price_pence: int


@dataclass(frozen=True)
class BaseInvoice:
    invoice_no: str
    customer_id: str
    country: str
    lines: Tuple[BaseLine, ...]


def select_pool(df: pd.DataFrame) -> Tuple[List[BaseInvoice], Dict[str, int]]:
    """Apply the frozen eligibility rules. Returns (invoices sorted by InvoiceNo, removal counts)."""
    r = el.prepare_rows(df)
    t = el.invoice_table(r)
    s1 = t[t["s1"]]
    c = s1[s1["pattern6"] & s1["type_strict"] & s1["single_date"]]
    zero_pence = set(r.loc[r["pence"].eq(0), "inv"].dropna())
    c_nz = c[~c.index.isin(zero_pence)]
    ids = c_nz.index.tolist()
    sigs = el.invoice_signatures(r, ids)
    keep = el.keep_first_ids(ids, sigs, "full")

    rows = r[r["inv"].isin(set(keep))]
    lines: Dict[str, List[BaseLine]] = {}
    for inv, stock, qty, pence in zip(rows["inv"], rows["stock"], rows["qty"], rows["pence"]):
        lines.setdefault(inv, []).append(BaseLine(stock, int(qty), int(pence)))   # original row order kept
    invoices = [BaseInvoice(inv, str(t.at[inv, "customer"]), str(t.at[inv, "country"]), tuple(lines[inv]))
                for inv in sorted(keep)]
    counts = {"S1_invoices": int(len(s1)), "after_pattern_type_date_filters": int(len(c)),
              "excluded_zero_pence": int(len(c) - len(c_nz)), "duplicate_content_removed": int(len(ids) - len(keep)),
              "pool_invoices": len(invoices),
              "t4_capable_invoices": int(t.loc[keep, "t4_capable"].sum()) if keep else 0}
    return invoices, counts


def invoices_to_csv_text(invoices: List[BaseInvoice]) -> str:
    import io
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(CSV_COLUMNS)
    for inv in invoices:
        for i, ln in enumerate(inv.lines):
            w.writerow([inv.invoice_no, i, ln.stock_code, ln.quantity, ln.unit_price_pence, inv.customer_id, inv.country])
    return buf.getvalue()


def write_base_lines(invoices: List[BaseInvoice], path: Path) -> str:
    """Write the CSV once. If the file exists it must be byte-identical; it is never overwritten."""
    text = invoices_to_csv_text(invoices)
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    path = Path(path)
    if path.exists():
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise FileExistsError(f"{path} exists and differs from the newly computed base table; not overwriting.")
        return digest
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "x", encoding="utf-8", newline="") as fh:
        fh.write(text)
    return digest


def read_base_lines(path: Path) -> List[BaseInvoice]:
    """Read the CSV strictly (CustomerID and codes stay text; quantity and pence must be integers)."""
    groups: Dict[str, dict] = {}
    with open(path, encoding="utf-8", newline="") as fh:
        reader = csv.DictReader(fh)
        if reader.fieldnames != CSV_COLUMNS:
            raise ValueError(f"Unexpected columns in {path}: {reader.fieldnames}")
        for row in reader:
            g = groups.setdefault(row["invoice_no"], {"cust": row["customer_id"], "country": row["country"], "lines": []})
            if (g["cust"], g["country"]) != (row["customer_id"], row["country"]):
                raise ValueError(f"Invoice {row['invoice_no']} has inconsistent customer/country in {path}")
            g["lines"].append(BaseLine(row["stock_code"], int(row["quantity"]), int(row["unit_price_pence"])))
    return [BaseInvoice(k, g["cust"], g["country"], tuple(g["lines"])) for k, g in sorted(groups.items())]
