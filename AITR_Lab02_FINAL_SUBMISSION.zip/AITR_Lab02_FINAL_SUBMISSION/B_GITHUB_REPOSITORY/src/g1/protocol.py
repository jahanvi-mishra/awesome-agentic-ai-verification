"""Load the frozen protocol settings (configs/protocol_v1_0.json) and the seed configuration."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict

from g1 import seeding

REQUIRED_KEYS = ("protocol_version", "pool", "sizes", "conditions", "fault_types", "t4_policy", "limit_L", "seed_config")
T4_POLICIES = ("capable_only",)   # the pool is never restricted; T4 cases come only from T4-capable invoices (see faults.build_t4_topup)


def load_protocol(root: Path) -> Dict[str, Any]:
    path = Path(root) / "configs" / "protocol_v1_0.json"
    try:
        cfg = json.loads(path.read_text(encoding="utf-8"))
    except FileNotFoundError as exc:
        raise FileNotFoundError(f"Protocol file not found: {path}") from exc
    missing = [k for k in REQUIRED_KEYS if k not in cfg]
    if missing:
        raise KeyError(f"Protocol file {path} is missing keys {missing}")
    if cfg["t4_policy"] not in T4_POLICIES:
        raise ValueError(f"t4_policy must be one of {T4_POLICIES}")
    seed_cfg = seeding.load_seed_config(Path(root) / cfg["seed_config"])
    cfg["seeds"] = seeding.derive_seeds(seed_cfg["master_seed"], seed_cfg["offsets"])
    cfg["master_seed"] = seed_cfg["master_seed"]
    return cfg
