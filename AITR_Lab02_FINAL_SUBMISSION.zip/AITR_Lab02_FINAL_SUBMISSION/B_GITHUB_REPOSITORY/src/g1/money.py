"""Exact money handling. Prices live as integer pence; float arithmetic is never used for money.

Decimal is used for the one risky step (turning a displayed price such as 2.55 into pence).
After that, quantity x pence is plain integer arithmetic, which is exact.
"""

from __future__ import annotations

from decimal import Decimal
from typing import Union

Number = Union[int, float, str, Decimal]


def price_to_pence(value: Number) -> int:
    """Convert a price to integer pence. Raises ValueError unless the price has at most 2 decimals."""
    d = Decimal(repr(value)) if isinstance(value, float) else Decimal(str(value))
    scaled = d * 100
    if scaled != scaled.to_integral_value():
        raise ValueError(f"price {value!r} is not exact in two decimals")
    return int(scaled)


def line_amount(quantity: int, unit_price_pence: int) -> int:
    """Line amount in pence. Both inputs must be ints (bool is rejected)."""
    for name, v in (("quantity", quantity), ("unit_price_pence", unit_price_pence)):
        if isinstance(v, bool) or not isinstance(v, int):
            raise TypeError(f"{name} must be int, got {type(v).__name__}")
    return quantity * unit_price_pence


def format_pence(pence: int) -> str:
    sign = "-" if pence < 0 else ""
    return f"{sign}{abs(pence) // 100}.{abs(pence) % 100:02d}"
