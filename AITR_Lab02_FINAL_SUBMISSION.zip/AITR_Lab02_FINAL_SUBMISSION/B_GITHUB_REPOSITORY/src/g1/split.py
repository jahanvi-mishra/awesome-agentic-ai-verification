"""Deterministic split by InvoiceNo and calibration constants.

Split rule (my specification of Prompt 07 Part 4; flagged in the implementation report):
  1. take the pool InvoiceNos sorted as text
  2. draw ONE permutation with the split generator (master seed + 1)
  3. first 1,000 permuted -> calibration, next 50 -> pilot, next 500 -> evaluation (each list then sorted)
  4. the remaining invoices stay unused
An invoice appears in at most one subset. Nothing is trained, so there is no ML train/test split.
"""

from __future__ import annotations

import hashlib
import json
from typing import Dict, List, Sequence

import numpy as np

from g1 import seeding
from g1.data_prep import BaseInvoice
from g1.money import line_amount
from g1.rules import RuleConstants

SUBSETS = ("calibration", "pilot", "evaluation")


def split_invoices(invoice_nos: Sequence[str], split_seed: int, sizes: Dict[str, int]) -> Dict[str, List[str]]:
    ids = sorted(set(invoice_nos))
    if len(ids) != len(list(invoice_nos)):
        raise ValueError("Duplicate InvoiceNo in the pool")
    need = sum(sizes[s] for s in SUBSETS)
    if len(ids) < need:
        raise ValueError(f"Pool has {len(ids)} invoices but {need} are needed")
    order = seeding.make_rng(split_seed).permutation(len(ids))
    chosen = [ids[i] for i in order[:need]]
    out, start = {}, 0
    for name in SUBSETS:
        out[name] = sorted(chosen[start:start + sizes[name]])
        start += sizes[name]
    return out


def reserve_after_split(invoice_nos: Sequence[str], split_seed: int, sizes: Dict[str, int]) -> List[str]:
    """Pool invoices NOT assigned to any subset, in the order of the same single permutation used by split_invoices.

    The split itself is unchanged: the first sum(sizes) permuted invoices form the subsets and these come next.
    Used only to top up T4 cases from T4-capable invoices; no new random draw and no new seed.
    """
    ids = sorted(set(invoice_nos))
    need = sum(sizes[s] for s in SUBSETS)
    order = seeding.make_rng(split_seed).permutation(len(ids))
    return [ids[i] for i in order[need:]]


def split_hash(split: Dict[str, List[str]]) -> str:
    return hashlib.sha256(json.dumps(split, sort_keys=True).encode()).hexdigest()


def invoice_total(inv: BaseInvoice) -> int:
    return sum(line_amount(l.quantity, l.unit_price_pence) for l in inv.lines)


def calibration_constants(calibration: Sequence[BaseInvoice], percentile_method: str = "higher") -> RuleConstants:
    """Q_max, P_max, T_max, Country set and L, from the calibration invoices ONLY."""
    if not calibration:
        raise ValueError("Calibration subset is empty")
    totals = [invoice_total(i) for i in calibration]
    return RuleConstants(
        q_max=max(l.quantity for i in calibration for l in i.lines),
        p_max_pence=max(l.unit_price_pence for i in calibration for l in i.lines),
        t_max_pence=max(totals),
        countries=frozenset(i.country for i in calibration),
        l_pence=int(np.percentile(totals, 90, method=percentile_method)))
