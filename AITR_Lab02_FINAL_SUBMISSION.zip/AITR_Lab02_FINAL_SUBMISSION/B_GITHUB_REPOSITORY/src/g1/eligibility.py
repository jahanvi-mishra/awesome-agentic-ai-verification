"""Eligibility and fault-feasibility counts for the Online Retail table (read-only, deterministic).

Follows the preprocessing steps in Prompt 07 v0.1 (Part 2) and counts what each step does. It does NOT
split, sample, remove or repair anything. "Scenarios" are only counts of how many invoices would
remain under a rule set; the data is never changed.

Vocabulary
  row valid   : InvoiceNo, StockCode, CustomerID, Country, Quantity, UnitPrice all present,
                Quantity > 0 and UnitPrice > 0. 'Unspecified' is a country value, NOT a missing value.
  S1 (rule set from Prompt 07, steps 1-3): not cancelled, EVERY line of the invoice is valid, >= 2 lines.
  pence       : UnitPrice as integer pence, rounded HALF-UP from the shortest decimal text of the float
                (this is a proposal; the rounding rule needs your approval).
"""

from __future__ import annotations

import math
from collections import Counter
from decimal import ROUND_HALF_UP, Decimal
from typing import Any, Dict, List

import numpy as np
import pandas as pd

REQUIRED_COLUMNS = ["InvoiceNo", "StockCode", "Description", "Quantity", "InvoiceDate",
                    "UnitPrice", "CustomerID", "Country"]
NEEDED_INVOICES = 1000 + 50 + 500      # calibration + pilot + evaluation (Prompt 07 v0.1, APPROVE item)
NEEDED_FOR_T4 = 500                    # every evaluation invoice receives one T4 case


# ---------------------------------------------------------------- price / pence arithmetic
def price_info(x: float) -> Dict[str, Any]:
    """Decimal facts about one price, using its shortest decimal text (what Excel/Python display)."""
    d = Decimal(repr(float(x)))
    decimals = max(0, -d.normalize().as_tuple().exponent)
    scaled = d * 100
    half_up = int(scaled.quantize(Decimal(1), rounding=ROUND_HALF_UP))
    return {"decimals": decimals,
            "pence_half_up": half_up,
            "is_tie": (scaled - scaled.to_integral_value(rounding="ROUND_FLOOR")) == Decimal("0.5"),
            "naive_round": int(round(float(x) * 100)),   # Python round(): ties go to even
            "naive_truncate": int(float(x) * 100)}       # cuts toward zero: 2.55 may become 254


def _id_text(v: Any):
    """Identifier as text: None if missing/blank, '17850.0' -> '17850'."""
    if v is None or (not isinstance(v, str) and pd.isna(v)):
        return None
    if isinstance(v, float) and v.is_integer():
        return str(int(v))
    s = str(v).strip()
    return s or None


# ---------------------------------------------------------------- row table
def prepare_rows(df: pd.DataFrame) -> pd.DataFrame:
    """Row-level helper columns. Works on a new frame; df itself is never modified."""
    missing = [c for c in REQUIRED_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns {missing}; found {list(df.columns)}")
    r = pd.DataFrame(index=df.index)
    r["inv"] = df["InvoiceNo"].map(_id_text)
    r["stock"] = df["StockCode"].map(_id_text)
    r["country"] = df["Country"].map(_id_text)
    r["cust"] = df["CustomerID"].map(_id_text)
    r["qty"] = pd.to_numeric(df["Quantity"], errors="coerce")
    r["price"] = pd.to_numeric(df["UnitPrice"], errors="coerce")
    r["date"] = pd.to_datetime(df["InvoiceDate"], errors="coerce")

    r["cancelled"] = r["inv"].str.startswith(("C", "c"), na=False)
    r["pattern6"] = r["inv"].str.fullmatch(r"\d{6}", na=False)
    cust_num = pd.to_numeric(r["cust"], errors="coerce")
    r["cust5"] = cust_num.notna() & (cust_num % 1 == 0) & (cust_num >= 10000) & (cust_num <= 99999)
    r["qty_int"] = r["qty"].notna() & (r["qty"] % 1 == 0)
    r["row_valid"] = (r["inv"].notna() & r["stock"].notna() & r["country"].notna() & r["cust"].notna()
                      & r["qty"].notna() & r["price"].notna() & (r["qty"] > 0) & (r["price"] > 0))

    info = {p: price_info(p) for p in r.loc[r["price"].notna(), "price"].unique()}   # a few thousand distinct prices
    for key, col in (("decimals", "dec"), ("pence_half_up", "pence")):
        r[col] = r["price"].map({p: v[key] for p, v in info.items()})
    r["price_2dp"] = r["dec"].le(2)
    r["line_pence"] = np.where(r["qty_int"] & r["pence"].notna(), r["qty"] * r["pence"], np.nan)

    r["exact_dup"] = df.duplicated(keep=False)   # all 8 original columns identical
    r["pipe_dup"] = r[["inv", "stock", "qty", "pence", "cust", "country"]].duplicated(keep=False)
    r.attrs["price_info"] = info
    return r


# ---------------------------------------------------------------- invoice table
def invoice_table(r: pd.DataFrame) -> pd.DataFrame:
    """One row per InvoiceNo (rows with missing InvoiceNo cannot belong to any invoice)."""
    g = r[r["inv"].notna()].groupby("inv", sort=True)
    t = pd.DataFrame({
        "n_lines": g.size(), "n_valid": g["row_valid"].sum(),
        "cancelled": g["cancelled"].first(), "pattern6": g["pattern6"].first(),
        "n_dates": g["date"].nunique(), "n_cust": g["cust"].nunique(), "n_country": g["country"].nunique(),
        "has_exact_dup": g["exact_dup"].any(), "has_pipe_dup": g["pipe_dup"].any(),
        "all_price_2dp": g["price_2dp"].all(), "all_qty_int": g["qty_int"].all(), "all_cust5": g["cust5"].all(),
        "n_prices_pence": g["pence"].nunique(), "n_prices_exact": g["price"].nunique(),
        "total_pence": g["line_pence"].sum(), "customer": g["cust"].first(), "country": g["country"].first(),
        "date_span_min": (g["date"].max() - g["date"].min()).dt.total_seconds() / 60.0,
    })
    t["all_valid"] = t["n_valid"] == t["n_lines"]
    t["s1"] = ~t["cancelled"] & t["all_valid"] & (t["n_lines"] >= 2)
    t["type_strict"] = t["all_price_2dp"] & t["all_qty_int"] & t["all_cust5"]
    t["single_date"] = t["n_dates"] <= 1
    t["t4_capable"] = t["n_prices_pence"] >= 2
    return t


# ---------------------------------------------------------------- signatures and duplicates
def invoice_signatures(r: pd.DataFrame, ids: List[str]) -> Dict[str, Dict[str, Any]]:
    """Canonical content signature per invoice (only for the given ids).

    lines_sig : sorted tuple of (StockCode, Quantity, UnitPrice in pence), one entry per line.
    full_sig  : (CustomerID, Country, lines_sig).
    InvoiceNo, InvoiceDate and Description are NOT part of either signature: the pipeline does not use
    the date or the description, and two invoices that differ only there carry identical content.
    """
    sub = r[r["inv"].isin(set(ids))]
    lines: Dict[str, List[tuple]] = {}
    for inv, stock, qty, pence in zip(sub["inv"], sub["stock"], sub["qty"], sub["pence"]):
        lines.setdefault(inv, []).append((stock, float(qty), int(pence)))
    cust = sub.groupby("inv")["cust"].first()
    country = sub.groupby("inv")["country"].first()
    out = {}
    for inv, ln in lines.items():
        ls = tuple(sorted(ln))
        out[inv] = {"lines": ls, "full": (cust[inv], country[inv], ls)}
    return out


def duplicate_summary(sigs: Dict[str, Dict[str, Any]], kind: str) -> Dict[str, Any]:
    counts = Counter(s[kind] for s in sigs.values())
    sizes = [c for c in counts.values() if c > 1]
    return {"invoices_checked": len(sigs), "duplicate_groups": len(sizes),
            "invoices_in_duplicate_groups": int(sum(sizes)),
            "extra_invoices_if_one_kept_per_group": int(sum(c - 1 for c in sizes)),
            "largest_group_size": int(max(sizes)) if sizes else 1}


def keep_first_ids(ids: List[str], sigs: Dict[str, Dict[str, Any]], kind: str = "full") -> List[str]:
    """Counting aid only: first invoice (sorted InvoiceNo text) per signature. Nothing is deleted anywhere."""
    seen, keep = set(), []
    for inv in sorted(ids):
        s = sigs[inv][kind]
        if s not in seen:
            seen.add(s)
            keep.append(inv)
    return keep


# ---------------------------------------------------------------- precision, T4, T5
def precision_report(rows: pd.DataFrame, info: Dict[float, Dict[str, Any]]) -> Dict[str, Any]:
    p = rows.loc[rows["price"].notna() & (rows["price"] > 0), "price"]
    if p.empty:
        return {"rows": 0}
    facts = p.map(info)
    dec = facts.map(lambda f: f["decimals"])
    half_up = facts.map(lambda f: f["pence_half_up"])
    two = dec <= 2
    over = sorted({float(x) for x in p[dec > 2].unique()})
    return {
        "rows": int(len(p)), "distinct_prices": int(p.nunique()),
        "rows_exact_in_2_decimals": int(two.sum()), "rows_more_than_2_decimals": int((~two).sum()),
        "rows_3_or_4_decimals": int(((dec >= 3) & (dec <= 4)).sum()), "rows_5_plus_decimals": int((dec >= 5).sum()),
        "max_decimals": int(dec.max()),
        "distinct_prices_more_than_2_decimals": int(len(over)), "examples_more_than_2_decimals": over[:10],
        "rows_exact_tie_at_half_penny": int(facts.map(lambda f: f["is_tie"]).sum()),
        "rows_python_round_differs_from_half_up": int((facts.map(lambda f: f["naive_round"]) != half_up).sum()),
        "rows_2dp_where_int_of_price_x100_is_wrong": int((two & (facts.map(lambda f: f["naive_truncate"]) != half_up)).sum()),
        "rows_positive_price_but_zero_pence": int((half_up == 0).sum()),
    }


def t4_report(pool: pd.DataFrame) -> Dict[str, Any]:
    n = len(pool)
    cap = int(pool["t4_capable"].sum())
    return {"pool_invoices": n, "invoices_with_2plus_distinct_prices_in_pence": cap,
            "invoices_with_2plus_distinct_prices_exact": int((pool["n_prices_exact"] >= 2).sum()),
            "share_t4_capable": None if n == 0 else cap / n,
            "expected_t4_incapable_in_random_500": None if n == 0 else 500 * (1 - cap / n),
            "enough_for_500_all_t4_capable": cap >= NEEDED_FOR_T4}


def t5_report(pool: pd.DataFrame) -> Dict[str, Any]:
    """T5 swaps invoice_total or CustomerID with another invoice's. It needs partners that differ."""
    n = len(pool)
    if n < 2:
        return {"pool_invoices": n, "note": "fewer than 2 invoices"}
    c, t = pool["customer"], pool["total_pence"]
    c_cnt, t_cnt = c.map(c.value_counts()), t.map(t.value_counts())
    both_cnt = pd.Series(list(zip(c, t)), index=pool.index).map(Counter(zip(c, t)))
    other_diff_c = n - c_cnt
    other_diff_t = n - t_cnt
    other_diff_both = n - (c_cnt + t_cnt - both_cnt)
    return {"pool_invoices": n, "distinct_customers": int(c.nunique()), "distinct_invoice_totals": int(t.nunique()),
            "largest_customer_invoice_count": int(c_cnt.max()), "largest_customer_share": float(c_cnt.max() / n),
            "invoices_with_no_other_invoice_of_different_customer": int((other_diff_c == 0).sum()),
            "invoices_with_no_other_invoice_of_different_total": int((other_diff_t == 0).sum()),
            "invoices_with_no_other_invoice_differing_in_both": int((other_diff_both == 0).sum()),
            "min_partners_different_customer": int(other_diff_c.min()),
            "min_partners_different_total": int(other_diff_t.min()),
            "invoices_in_pool_with_more_than_one_customer_value": int((pool["n_cust"] > 1).sum())}


# ---------------------------------------------------------------- whole report
def build_report(df: pd.DataFrame) -> Dict[str, Any]:
    r = prepare_rows(df)
    info = r.attrs["price_info"]
    t = invoice_table(r)
    nc = t[~t["cancelled"]]
    s1 = t[t["s1"]]
    s1_ids = list(s1.index)
    sigs = invoice_signatures(r, s1_ids)

    # --- row level (rows of non-cancelled invoices; cancelled rows reported separately)
    row_level = {
        "rows_total": int(len(r)), "rows_missing_invoice_no": int(r["inv"].isna().sum()),
        "rows_cancelled_invoice": int(r["cancelled"].sum()),
        "rows_cancel_prefix_uppercase_C": int(r["inv"].str.startswith("C", na=False).sum()),
        "rows_cancel_prefix_lowercase_c": int(r["inv"].str.startswith("c", na=False).sum()),
        "rows_missing_or_blank": {k: int(r[k].isna().sum()) for k in ("stock", "country", "cust")},
        "rows_quantity_missing_or_non_numeric": int(r["qty"].isna().sum()),
        "rows_unitprice_missing_or_non_numeric": int(r["price"].isna().sum()),
        "rows_quantity_le_0": int((r["qty"] <= 0).sum()), "rows_unitprice_le_0": int((r["price"] <= 0).sum()),
        "rows_country_Unspecified_kept_as_present": int((r["country"].str.casefold() == "unspecified").sum()),
        "rows_valid_in_non_cancelled_invoices": int((r["row_valid"] & ~r["cancelled"]).sum()),
    }

    # --- invoice level
    partial = nc[(nc["n_valid"] > 0) & ~nc["all_valid"]]
    inv_level = {
        "1_invoices_after_excluding_cancelled": int(len(nc)),
        "invoices_cancelled_excluded": int(t["cancelled"].sum()),
        "2_invoices_all_rows_valid_any_line_count": int(nc["all_valid"].sum()),
        "invoices_with_some_but_not_all_rows_valid_excluded": int(len(partial)),
        "invoices_with_no_valid_row": int((nc["n_valid"] == 0).sum()),
        "all_rows_valid_but_only_one_line": int((nc["all_valid"] & (nc["n_lines"] == 1)).sum()),
        "3_S1_all_rows_valid_and_2plus_lines": int(len(s1)),
        "non_cancelled_invoices_not_6_digit_pattern": int((~nc["pattern6"]).sum()),
        "non_6_digit_examples": sorted(nc.index[~nc["pattern6"]].tolist())[:10],
        "S1_invoices_not_6_digit_pattern": int((~s1["pattern6"]).sum()),
        "S1_non_6_digit_examples": sorted(s1.index[~s1["pattern6"]].tolist())[:10],
        "lines_per_invoice_in_S1": {k: float(v) for k, v in s1["n_lines"].describe()[["min", "50%", "max", "mean"]].items()} if len(s1) else {},
    }

    # --- dates and repeated rows
    multi_date = nc[nc["n_dates"] > 1]
    dates = {
        "4_non_cancelled_invoices_with_multiple_InvoiceDate": int(len(multi_date)),
        "S1_invoices_with_multiple_InvoiceDate": int((s1["n_dates"] > 1).sum()),
        "max_span_minutes_among_multi_date_invoices": None if multi_date.empty else float(multi_date["date_span_min"].max()),
        "median_span_minutes_among_multi_date_invoices": None if multi_date.empty else float(multi_date["date_span_min"].median()),
        "multi_date_invoices_spanning_more_than_one_day": int((multi_date["date_span_min"] > 1440).sum()),
        "rows_with_missing_or_unparseable_date": int(r["date"].isna().sum()),
    }
    repeats = {
        "5_non_cancelled_invoices_with_repeated_exact_rows(all 8 columns)": int(nc["has_exact_dup"].sum()),
        "S1_invoices_with_repeated_exact_rows": int(s1["has_exact_dup"].sum()),
        "non_cancelled_invoices_with_repeated_pipeline_rows(stock,qty,pence,customer,country)": int(nc["has_pipe_dup"].sum()),
        "S1_invoices_with_repeated_pipeline_rows": int(s1["has_pipe_dup"].sum()),
        "S1_invoices_with_more_than_one_CustomerID_value": int((s1["n_cust"] > 1).sum()),
        "S1_invoices_with_more_than_one_Country_value": int((s1["n_country"] > 1).sum()),
    }
    dup = {"6_signature_definition": "lines_sig = sorted (StockCode, Quantity, price in pence) per line; full_sig = (CustomerID, Country, lines_sig); "
                                      "InvoiceNo, InvoiceDate and Description are not part of either signature",
           "lines_signature": duplicate_summary(sigs, "lines"), "full_signature": duplicate_summary(sigs, "full")}

    # --- scenarios (nested filters applied to S1; counts only)
    def count(mask): return int(mask.sum())
    A = s1
    B_keep = keep_first_ids(A.index.tolist(), sigs)
    C = A[A["pattern6"] & A["type_strict"] & A["single_date"]]
    D_keep = keep_first_ids(C.index.tolist(), sigs)
    D = C.loc[D_keep]
    E = D[D["t4_capable"]]
    scenarios = {
        "A_S1_prompt07_steps_1_to_3_no_dedupe": len(A),
        "B_A_minus_duplicate_content_invoices(full_sig, keep first)": len(B_keep),
        "C_A_and_6digit_InvoiceNo_and_exact_2dp_prices_5digit_CustomerID_integer_Quantity_and_single_InvoiceDate": len(C),
        "D_C_minus_duplicate_content_invoices(full_sig, keep first)": len(D),
        "E_D_and_at_least_2_distinct_prices(T4_capable)": len(E),
    }
    marginal = {name: {"removed_from_S1": len(A) - count(mask), "remaining": count(mask)} for name, mask in {
        "only_6digit_InvoiceNo": A["pattern6"], "only_exact_2dp_prices": A["all_price_2dp"],
        "only_5digit_CustomerID": A["all_cust5"], "only_integer_Quantity": A["all_qty_int"],
        "only_single_InvoiceDate": A["single_date"], "only_T4_capable": A["t4_capable"]}.items()}
    feasibility = {k: {"invoices": v, "needed_1550": NEEDED_INVOICES, "enough": v >= NEEDED_INVOICES} for k, v in scenarios.items()}

    prec_all = precision_report(r[~r["cancelled"]], info)
    prec_s1 = precision_report(r[r["inv"].isin(set(s1_ids))], info)
    price_inv = {"S1_invoices_with_any_price_over_2_decimals": int((~s1["all_price_2dp"]).sum()),
                 "S1_invoices_with_any_zero_pence_line": int(r[r["inv"].isin(set(s1_ids)) & r["pence"].eq(0)]["inv"].nunique())}

    # --- cross-check with the Prompt 06 audit definition (6-digit, all rows valid, date parsable, any line count)
    ok_row = r["pattern6"] & r["row_valid"] & r["date"].notna()
    cross = int(ok_row.groupby(r["inv"]).all().sum())
    return {
        "row_level": row_level, "invoice_level": inv_level, "dates": dates, "repeated_rows": repeats,
        "duplicate_invoice_contents": dup, "scenarios": scenarios, "scenario_marginal_effect_on_S1": marginal,
        "feasibility_1000_50_500": feasibility,
        "t4_feasibility": {"on_S1": t4_report(A), "on_scenario_D": t4_report(D)},
        "t5_feasibility": {"on_S1": t5_report(A), "on_scenario_D": t5_report(D)},
        "price_precision": {"all_rows_of_non_cancelled_invoices": prec_all, "rows_of_S1_invoices": prec_s1, "S1_invoice_effects": price_inv},
        "cross_check_prompt06_definition": {"description": "non-cancelled 6-digit invoices, every row valid incl. CustomerID, parsable date, ANY line count",
                                           "count_here": cross},
    }
