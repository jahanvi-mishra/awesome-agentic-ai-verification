"""Read-only inspection of a finished pilot (or evaluation) run: the pilot checks of Prompt 07 plus integrity checks.

Each check returns PASS, WARN or FAIL. It reads saved files only; it re-runs nothing except the in-memory determinism
check, and it writes nothing. Findings are for bug fixing: pilot detection results must never be used to tune rules.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, List

from g1 import experiment, faults, split

EXPECTED_CP = {"T1": "CP1", "T2": "CP1", "T3": "CP1", "T4": "CP2", "T5": "CP3"}
FILES = ("manifest.json", "manifest.sha256", "runs.jsonl", "labels.jsonl", "summary.json")
LEAK_WORDS = ("fault_type", "faulty_value", "original_value", "harmful", "benign", "skip_reason")


def _jsonl(path: Path) -> List[Dict[str, Any]]:
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]


def inspect(root: Path, proto: Dict[str, Any], subset: str = "pilot") -> Dict[str, Any]:
    root, src = Path(root), Path(root) / "results" / subset
    res: List[Dict[str, str]] = []

    def add(name: str, status: str, detail: str) -> None:
        res.append({"check": name, "status": status, "detail": detail})

    missing = [f for f in FILES if not (src / f).is_file()]
    if missing:
        add("files_present", "FAIL", f"missing in {src}: {missing}")
        return {"subset": subset, "overall": "FAIL", "checks": res}
    add("files_present", "PASS", ", ".join(FILES))

    manifest = json.loads((src / "manifest.json").read_text(encoding="utf-8"))
    logs, labels = _jsonl(src / "runs.jsonl"), _jsonl(src / "labels.jsonl")
    summary = json.loads((src / "summary.json").read_text(encoding="utf-8"))
    ok = faults.manifest_hash(manifest) == (src / "manifest.sha256").read_text().strip()
    add("manifest_hash_matches_file", "PASS" if ok else "FAIL", "manifest.json vs manifest.sha256")

    # --- splits and sizes
    try:
        sp = json.loads((root / "results" / "splits.json").read_text(encoding="utf-8"))
        subs = sp["subsets"]
        sizes_ok = {k: len(v) for k, v in subs.items()} == proto["sizes"]
        disjoint = len(set().union(*map(set, subs.values()))) == sum(len(v) for v in subs.values())
        hash_ok = split.split_hash(subs) == sp["sha256"] and sp["seed"] == proto["seeds"]["split"]
        add("splits_sizes_disjoint_hash_seed", "PASS" if sizes_ok and disjoint and hash_ok else "FAIL",
            f"sizes_ok={sizes_ok} disjoint={disjoint} hash_and_seed_ok={hash_ok}")
        in_subset = {r["invoice_no"] for r in manifest}
        add("manifest_invoices_belong_to_subset", "PASS" if in_subset <= set(subs[subset]) else "FAIL",
            f"{len(in_subset)} invoices in manifest, subset has {len(subs[subset])}")
    except (OSError, KeyError, ValueError) as exc:
        add("splits_sizes_disjoint_hash_seed", "FAIL", f"{type(exc).__name__}: {exc}")

    # --- run structure
    runnable = [r["case_id"] for r in manifest if r["status"] in ("clean", "inject")]
    expected_order = [(c, k) for c in runnable for k in ("B0", "F", "I")]
    got_order = [(l["case_id"], l["condition"]) for l in logs]
    add("runs_cover_every_case_with_B0_F_I_in_manifest_order", "PASS" if got_order == expected_order else "FAIL",
        f"{len(logs)} runs, expected {len(expected_order)}")
    leak = [w for w in LEAK_WORDS if w in (src / "runs.jsonl").read_text(encoding="utf-8")]
    add("run_logs_contain_no_fault_information", "PASS" if not leak else "FAIL", f"found words: {leak}" if leak else "none")
    add("no_t4_reserve_rows_in_pilot", "PASS" if subset != "pilot" or not any(r.get("source") for r in manifest) else "FAIL",
        "pilot manifests must be the plain builder's output")

    lab = {l["case_id"]: l["label"] for l in labels}
    out = {(l["case_id"], l["condition"]): l for l in logs}
    typ = {r["case_id"]: r["fault_type"] for r in manifest}
    clean = [c for c in runnable if typ[c] == "CLEAN"]
    faulty = [c for c in runnable if typ[c] != "CLEAN"]
    harmful = [c for c in faulty if lab.get(c) == "harmful"]

    b0_bad = [l["case_id"] for l in logs if l["condition"] == "B0" and (l["outcome"] == "HALTED" or l["rule_applications"] > 0)]
    add("B0_never_halts_and_applies_no_rules", "PASS" if not b0_bad else "FAIL", f"violations: {b0_bad[:5]}" if b0_bad else "none")
    mism = [c for c in clean if lab.get(c) != "reference_match"]
    add("clean_B0_record_equals_oracle_reference", "PASS" if not mism else "FAIL", f"mismatches: {mism[:5]}" if mism else f"{len(clean)} clean cases")
    defects = [c for c in faulty if lab.get(c) == "implementation_defect"]
    add("no_implementation_defect_labels", "PASS" if not defects else "FAIL", f"{len(defects)} cases: {defects[:5]}" if defects else "none")

    crashes = {k: sum(1 for l in logs if l["condition"] == k and l["outcome"] == "CRASHED") for k in ("B0", "F", "I")}
    share = max(crashes.values()) / len(faulty) if faulty else 0.0
    add("crashes_at_most_2_percent_of_faulty_cases", "PASS" if not any(crashes.values()) else ("WARN" if share <= 0.02 else "FAIL"),
        f"crashes by condition {crashes}; worst share of faulty cases {share:.3f}")

    f_alarm = [c for c in clean if out[(c, "F")]["outcome"] == "HALTED"]
    i_alarm = [c for c in clean if out[(c, "I")]["outcome"] == "HALTED"]
    add("no_false_alarms_on_clean_cases", "PASS" if not (f_alarm or i_alarm) else "WARN",
        f"F: {len(f_alarm)}, I: {len(i_alarm)} of {len(clean)}; first: " + str([(c, out[(c, 'I')]['halt_rule']) for c in i_alarm[:3]] + [(c, out[(c, 'F')]['halt_rule']) for c in f_alarm[:3]])
        + ("  (a clean case beyond a calibration limit or with an unseen country is a design limitation; report, do not tune)" if (f_alarm or i_alarm) else ""))

    m9 = [c for c in harmful if out[(c, "F")]["outcome"] == "HALTED" and out[(c, "I")]["outcome"] == "COMMITTED"]
    add("M9_zero_no_harmful_case_caught_only_by_F", "PASS" if not m9 else "FAIL", f"{len(m9)}: {m9[:5]}" if m9 else "0")

    per_type = []
    for t in faults.FAULT_TYPES:
        rows = [r for r in manifest if r["fault_type"] == t]
        h = sum(lab.get(r["case_id"]) == "harmful" for r in rows if r["status"] == "inject")
        per_type.append(f"{t}: injected {sum(r['status'] == 'inject' for r in rows)}, skipped {sum(r['status'] == 'skipped' for r in rows)}, harmful {h}")
    none_harmful = [t for t in faults.FAULT_TYPES if not any(lab.get(r["case_id"]) == "harmful" for r in manifest if r["fault_type"] == t)]
    add("every_fault_type_has_a_harmful_case_in_pilot", "PASS" if not none_harmful else "WARN", "; ".join(per_type))

    dev = [(c, typ[c], out[(c, "I")]["halt_checkpoint"]) for c in faulty
           if lab.get(c) in ("harmful", "benign") and out[(c, "I")]["outcome"] == "HALTED" and out[(c, "I")]["halt_checkpoint"] != EXPECTED_CP[typ[c]]]
    missed_i = [(c, typ[c]) for c in harmful if out[(c, "I")]["outcome"] == "COMMITTED"]
    add("I_halts_at_the_design_checkpoint (T1-T3 CP1, T4 CP2, T5 CP3)", "PASS" if not dev else "WARN", f"{len(dev)} deviations: {dev[:5]}" if dev else "all halts as designed")
    add("harmful_faults_committed_under_I", "PASS" if not missed_i else "WARN",
        f"{len(missed_i)}: {missed_i[:5]}. A rule gap or constant issue is a finding to report, not something to tune." if missed_i else "0")

    try:
        again = experiment.verify_rerun(root, proto, subset)
        add("deterministic_rerun_identical", "PASS" if again["identical"] else "FAIL", str(again))
    except (OSError, KeyError, ValueError) as exc:
        add("deterministic_rerun_identical", "FAIL", f"{type(exc).__name__}: {exc}")

    add("summary_counts_agree_with_files", "PASS" if summary.get("cases_run") == len(runnable) and summary.get("manifest_sha256") == (src / "manifest.sha256").read_text().strip() else "FAIL",
        f"summary cases_run={summary.get('cases_run')}, runnable cases={len(runnable)}")
    overall = "FAIL" if any(r["status"] == "FAIL" for r in res) else "WARN" if any(r["status"] == "WARN" for r in res) else "PASS"
    return {"subset": subset, "overall": overall, "checks": res}
