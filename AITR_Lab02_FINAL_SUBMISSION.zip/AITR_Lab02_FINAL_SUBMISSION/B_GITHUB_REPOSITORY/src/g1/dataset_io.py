"""Acquire and protect the raw UCI Online Retail files (dataset ID 352).

Rules enforced here
  * Download ONLY from the official host archive.ics.uci.edu over https (also after redirects).
  * Raw files are written once (exclusive-create mode) and never overwritten, edited or deleted by this code.
  * Raw files are marked read-only, and their SHA-256 hashes are stored in data/raw/SOURCE_MANIFEST.json.
  * Every later use re-hashes the files and compares with the manifest, so silent change is detected.

Nothing here cleans or transforms data.
"""

from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import shutil
import stat
import urllib.error
import urllib.parse
import urllib.request
import zipfile
from pathlib import Path
from typing import Dict, Union

OFFICIAL_HOST = "archive.ics.uci.edu"
OFFICIAL_PAGE = "https://archive.ics.uci.edu/dataset/352/online+retail"
# Usual direct link behind the page's Download button. UNVERIFIED by the author: if it fails,
# use the manual route (see register_manual_zip) and compare with the link shown on OFFICIAL_PAGE.
OFFICIAL_ZIP_URL = "https://archive.ics.uci.edu/static/public/352/online+retail.zip"
LOCAL_ZIP_NAME = "online_retail.zip"
MANIFEST_NAME = "SOURCE_MANIFEST.json"
MAX_ZIP_BYTES = 200 * 1024 * 1024          # sanity limit for the download (real size is about 23 MB)
MAX_MEMBER_BYTES = 1024 * 1024 * 1024      # sanity limit for the extracted xlsx (zip-bomb guard)
CHUNK = 1 << 20

PathLike = Union[str, Path]


class DatasetError(RuntimeError):
    """Any problem acquiring or verifying the raw dataset (message is meant to be read by the user)."""


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")


def sha256_file(path: PathLike) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as fh:
        for chunk in iter(lambda: fh.read(CHUNK), b""):
            h.update(chunk)
    return h.hexdigest()


def check_official_url(url: str) -> None:
    parts = urllib.parse.urlparse(url)
    if parts.scheme != "https" or parts.hostname != OFFICIAL_HOST:
        raise DatasetError(f"Refusing URL {url!r}: only https://{OFFICIAL_HOST}/... is allowed as the data source.")


def _make_read_only(path: Path) -> None:
    os.chmod(path, stat.S_IREAD | stat.S_IRGRP | stat.S_IROTH)


def download_zip(url: str, raw_dir: Path, timeout: int = 60) -> Dict:
    """Stream the zip from UCI into raw_dir/online_retail.zip. Never overwrites an existing file."""
    check_official_url(url)
    raw_dir.mkdir(parents=True, exist_ok=True)
    final = raw_dir / LOCAL_ZIP_NAME
    if final.exists():
        raise DatasetError(f"{final} already exists; refusing to overwrite raw data.")
    part = raw_dir / (LOCAL_ZIP_NAME + ".part")
    part.unlink(missing_ok=True)  # our own unfinished temp file from an earlier failed attempt, not raw data

    request = urllib.request.Request(url, headers={"User-Agent": "g1-dataset-audit/0.2 (academic research)"})
    digest, size = hashlib.sha256(), 0
    try:
        with urllib.request.urlopen(request, timeout=timeout) as resp, open(part, "xb") as out:
            final_url = resp.geturl()
            check_official_url(final_url)  # a redirect must not leave the official host
            headers = {k: resp.headers.get(k) for k in
                       ("Content-Type", "Content-Length", "Last-Modified", "ETag", "Content-Disposition")}
            while True:
                chunk = resp.read(CHUNK)
                if not chunk:
                    break
                size += len(chunk)
                if size > MAX_ZIP_BYTES:
                    raise DatasetError(f"Download exceeded {MAX_ZIP_BYTES} bytes; aborted.")
                out.write(chunk)
                digest.update(chunk)
    except DatasetError:
        part.unlink(missing_ok=True)
        raise
    except (urllib.error.URLError, TimeoutError, OSError) as exc:
        part.unlink(missing_ok=True)
        raise DatasetError(
            f"Download failed: {type(exc).__name__}: {exc}\n"
            f"Fallback: open {OFFICIAL_PAGE} in your browser, click Download, then run the 'register' command "
            f"with the zip you saved.") from exc

    part.rename(final)
    if sha256_file(final) != digest.hexdigest():
        raise DatasetError("Hash of the saved file differs from the hash of the streamed bytes; do not use this file.")
    return {"acquisition_mode": "download", "requested_url": url, "final_url": final_url,
            "url_filename": Path(urllib.parse.urlparse(url).path).name, "http_headers": headers}


def ingest_zip(zip_path: Path, raw_dir: Path, source: Dict) -> Dict:
    """Validate the zip in raw_dir, extract its single .xlsx once, and write the manifest once."""
    manifest_path = raw_dir / MANIFEST_NAME
    if manifest_path.exists():
        raise DatasetError(f"{manifest_path} already exists; raw data was already registered.")
    if not zipfile.is_zipfile(zip_path):
        raise DatasetError(f"{zip_path.name} is not a valid zip file (wrong download or an error page was saved).")

    with zipfile.ZipFile(zip_path) as zf:
        bad = zf.testzip()
        if bad:
            raise DatasetError(f"Zip is corrupt: member {bad!r} failed its CRC check.")
        files = [i for i in zf.infolist() if not i.is_dir()]
        members = [{"name": i.filename, "size_bytes": i.file_size, "crc32": f"{i.CRC:08x}"} for i in files]
        xlsx = [i for i in files if i.filename.lower().endswith(".xlsx")]
        if len(xlsx) != 1:
            raise DatasetError(f"Expected exactly one .xlsx in the zip, found {len(xlsx)}: {[m['name'] for m in members]}")
        member = xlsx[0]
        if member.file_size > MAX_MEMBER_BYTES:
            raise DatasetError(f"Member {member.filename!r} is implausibly large ({member.file_size} bytes).")
        out_name = Path(member.filename).name  # keeps only the file name: blocks '../' path tricks
        if not out_name or out_name.startswith("."):
            raise DatasetError(f"Unsafe member name {member.filename!r}.")
        out_path = raw_dir / out_name
        if out_path.exists():
            raise DatasetError(f"{out_path} already exists; refusing to overwrite raw data.")
        digest = hashlib.sha256()
        with zf.open(member) as src, open(out_path, "xb") as dst:
            for chunk in iter(lambda: src.read(CHUNK), b""):
                dst.write(chunk)
                digest.update(chunk)

    manifest = {
        "manifest_schema": 1,
        "dataset_name": "Online Retail",
        "dataset_id": 352,
        "official_page": OFFICIAL_PAGE,
        "licence_note": "CC BY 4.0 as stated on the UCI page when last checked in Prompt 06; NOT verified by this script. Confirm on the page.",
        "dataset_version": "UNKNOWN: no version field is supplied by the file or this script; copy the page's date information here by hand.",
        "registered_utc": utc_now(),
        "local_zip_filename": zip_path.name,
        "zip_size_bytes": zip_path.stat().st_size,
        "zip_sha256": sha256_file(zip_path),
        "zip_members": members,
        "xlsx_filename": out_name,
        "xlsx_size_bytes": out_path.stat().st_size,
        "xlsx_sha256": digest.hexdigest(),
    }
    manifest.update(source)
    with open(manifest_path, "x", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2)
    for path in (zip_path, out_path, manifest_path):
        _make_read_only(path)
    return manifest


def verify_manifest(raw_dir: Path) -> Dict:
    """Re-hash the raw files and compare with the manifest. Raises DatasetError on any difference."""
    manifest_path = raw_dir / MANIFEST_NAME
    if not manifest_path.is_file():
        raise DatasetError(f"{manifest_path} not found. Run the 'download' (or 'register') command first.")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    for name_key, hash_key in (("local_zip_filename", "zip_sha256"), ("xlsx_filename", "xlsx_sha256")):
        path = raw_dir / manifest[name_key]
        if not path.is_file():
            raise DatasetError(f"Raw file missing: {path}")
        actual = sha256_file(path)
        if actual != manifest[hash_key]:
            raise DatasetError(f"HASH MISMATCH for {path.name}: manifest {manifest[hash_key]}, actual {actual}. "
                               "The raw file changed. Do not use it; re-acquire from the official source.")
    return manifest


def fetch_from_uci(raw_dir: Path, url: str = OFFICIAL_ZIP_URL) -> Dict:
    """Download (if not already done), extract and register. Safe to call again: it only verifies."""
    if (raw_dir / MANIFEST_NAME).exists():
        return verify_manifest(raw_dir)
    if (raw_dir / LOCAL_ZIP_NAME).exists():
        raise DatasetError(f"{raw_dir / LOCAL_ZIP_NAME} exists without a manifest (interrupted earlier run). "
                           "Inspect it; if it is not valid, delete that one file by hand and run again.")
    source = download_zip(url, raw_dir)
    source["downloaded_utc"] = utc_now()
    return ingest_zip(raw_dir / LOCAL_ZIP_NAME, raw_dir, source)


def register_manual_zip(src_zip: PathLike, raw_dir: Path) -> Dict:
    """Fallback: you downloaded the zip yourself from the official page. Copy (never move) it into raw_dir."""
    src_zip = Path(src_zip)
    if not src_zip.is_file():
        raise DatasetError(f"{src_zip} not found.")
    if (raw_dir / MANIFEST_NAME).exists():
        return verify_manifest(raw_dir)
    raw_dir.mkdir(parents=True, exist_ok=True)
    dest = raw_dir / LOCAL_ZIP_NAME
    if dest.exists():
        raise DatasetError(f"{dest} already exists without a manifest; inspect it first.")
    with open(src_zip, "rb") as src, open(dest, "xb") as dst:
        shutil.copyfileobj(src, dst, CHUNK)
    source = {"acquisition_mode": "manual_registration (user attests the zip came from the official page)",
              "requested_url": None, "final_url": None, "url_filename": src_zip.name,
              "original_path_given": str(src_zip), "downloaded_utc": "UNKNOWN (registered " + utc_now() + ")"}
    return ingest_zip(dest, raw_dir, source)
