"""Orchestration: prepare the base table, split, calibration constants; run the pilot or the evaluation.

Every output file is written ONCE (never overwritten). The evaluation can be run only once.
Nothing here computes result metrics; it writes manifests, run logs and oracle labels.
"""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any, Dict

import pandas as pd

from g1 import data_prep, faults, protocol, runner, seeding, split
from g1.rules import RuleConstants


class PoolCountMismatch(RuntimeError):
    """The pool built from the raw file differs from the counts in the approved decisions."""


def _write_once(path: Path, text: str) -> str:
    path.parent.mkdir(parents=True, exist_ok=True)
    digest = hashlib.sha256(text.encode("utf-8")).hexdigest()
    if path.exists():
        if hashlib.sha256(path.read_bytes()).hexdigest() != digest:
            raise FileExistsError(f"{path} exists and differs; not overwriting.")
        return digest
    with open(path, "x", encoding="utf-8") as fh:
        fh.write(text)
    return digest


def prepare(df: pd.DataFrame, root: Path, proto: Dict[str, Any]) -> Dict[str, Any]:
    """Raw table -> pool (Scenario D) -> base_lines.csv, splits.json, constants_calibration.json."""
    invoices, counts = data_prep.select_pool(df)
    exp = proto["pool"]
    if exp.get("expected_pool_invoices") is not None and counts["pool_invoices"] != exp["expected_pool_invoices"]:
        raise PoolCountMismatch(f"pool has {counts['pool_invoices']} invoices, decisions say {exp['expected_pool_invoices']}; counts: {counts}")
    if exp.get("expected_t4_capable_invoices") is not None and counts["t4_capable_invoices"] != exp["expected_t4_capable_invoices"]:
        raise PoolCountMismatch(f"T4-capable invoices {counts['t4_capable_invoices']} != {exp['expected_t4_capable_invoices']}; counts: {counts}")
    root = Path(root)
    csv_hash = data_prep.write_base_lines(invoices, root / "data" / "interim" / "base_lines.csv")

    # The split uses the WHOLE eligible pool (approved). T4-capability only decides which cases get a T4 fault.
    sp = split.split_invoices([i.invoice_no for i in invoices], proto["seeds"]["split"], proto["sizes"])
    by_no = {i.invoice_no: i for i in invoices}
    consts = split.calibration_constants([by_no[n] for n in sp["calibration"]], proto["limit_L"]["percentile_method"])
    out = {"counts": counts, "base_lines_sha256": csv_hash, "split_sha256": split.split_hash(sp), "constants": consts.to_json()}
    _write_once(root / "results" / "splits.json", json.dumps({"seed": proto["seeds"]["split"], "sizes": proto["sizes"],
                                                              "sha256": out["split_sha256"], "subsets": sp}, indent=1, sort_keys=True))
    _write_once(root / "results" / "constants_calibration.json", json.dumps(out["constants"], indent=1, sort_keys=True))
    return out


def build_subset_manifest(root: Path, proto: Dict[str, Any], subset: str):
    """Manifest and the invoices needed to run it. Used by run_subset and verify_rerun, so both are identical.

    pilot      : exactly the earlier behaviour (T4 skipped for non-capable invoices, nothing added).
    evaluation : same rows for every invoice, then T4 top-up cases from T4-capable invoices outside all subsets.
    """
    root = Path(root)
    invoices = data_prep.read_base_lines(root / "data" / "interim" / "base_lines.csv")
    by_no = {i.invoice_no: i for i in invoices}
    sp = json.loads((root / "results" / "splits.json").read_text(encoding="utf-8"))["subsets"]
    consts = RuleConstants.from_json(json.loads((root / "results" / "constants_calibration.json").read_text(encoding="utf-8")))
    subset_invoices = [by_no[n] for n in sp[subset]]
    rng = seeding.make_rng(proto["seeds"]["faults"])
    manifest = faults.build_manifest(subset_invoices, consts, rng)
    case_invoices = list(subset_invoices)
    if subset == "evaluation":
        needed = sum(1 for r in manifest if r["fault_type"] == "T4" and r["status"] == "skipped")
        if needed:
            nos = [i.invoice_no for i in invoices]
            assigned = {n for names in sp.values() for n in names}
            if split.split_invoices(nos, proto["seeds"]["split"], proto["sizes"]) != sp:
                raise ValueError("splits.json does not match the deterministic split; refusing to build a T4 reserve")
            reserve = [by_no[n] for n in split.reserve_after_split(nos, proto["seeds"]["split"], proto["sizes"])
                       if n not in assigned]
            topup = faults.build_t4_topup(reserve, needed, rng)
            manifest = manifest + topup
            case_invoices += [by_no[r["invoice_no"]] for r in topup]
    return manifest, case_invoices, consts


def run_subset(root: Path, proto: Dict[str, Any], subset: str) -> Dict[str, Any]:
    """Build the manifest (hashed BEFORE any run), run B0/F/I once, write logs and oracle labels."""
    if subset not in ("pilot", "evaluation"):
        raise ValueError("subset must be 'pilot' or 'evaluation'")
    root = Path(root)
    out_dir = root / "results" / subset
    if out_dir.exists() and any(out_dir.iterdir()):
        raise FileExistsError(f"{out_dir} already has files. The run is done once; start a new protocol version instead.")
    manifest, case_invoices, consts = build_subset_manifest(root, proto, subset)
    mhash = faults.manifest_hash(manifest)
    _write_once(out_dir / "manifest.json", json.dumps(manifest, indent=1, sort_keys=True))
    _write_once(out_dir / "manifest.sha256", mhash + "\n")          # recorded before any condition runs

    cases = runner.build_cases(case_invoices, manifest)
    logs = runner.run_cases(cases, consts)
    run_hash = runner.write_jsonl(out_dir / "runs.jsonl", logs)
    labels = runner.label_cases(cases, logs, consts)
    runner.write_jsonl(out_dir / "labels.jsonl", labels)

    counts: Dict[str, Any] = {}
    for l in logs:
        counts[f"{l['condition']}_{l['outcome']}"] = counts.get(f"{l['condition']}_{l['outcome']}", 0) + 1
    t4 = [r for r in manifest if r["fault_type"] == "T4"]
    summary = {"subset": subset, "invoices": len(sp_names(root, subset)), "cases_run": len(cases),
               "faults_skipped": sum(r["status"] == "skipped" for r in manifest), "manifest_sha256": mhash,
               "t4_cases_injected": sum(r["status"] == "inject" for r in t4),
               "t4_cases_from_reserve": sum(r.get("source") == "t4_reserve" for r in t4),
               "runs_sha256": run_hash, "outcome_counts_by_condition": counts,
               "label_counts": {k: sum(1 for x in labels if x["label"] == k) for k in sorted({x["label"] for x in labels})}}
    _write_once(out_dir / "summary.json", json.dumps(summary, indent=1, sort_keys=True))
    return summary


def sp_names(root: Path, subset: str):
    return json.loads((Path(root) / "results" / "splits.json").read_text(encoding="utf-8"))["subsets"][subset]


def verify_rerun(root: Path, proto: Dict[str, Any], subset: str) -> Dict[str, Any]:
    """Determinism check (Prompt 07 Part 4): recompute the run in memory and compare with the saved files.
    Writes nothing. A difference means a bug."""
    root = Path(root)
    out_dir = root / "results" / subset
    manifest, case_invoices, consts = build_subset_manifest(root, proto, subset)
    logs = runner.run_cases(runner.build_cases(case_invoices, manifest), consts)
    saved_manifest = (out_dir / "manifest.sha256").read_text().strip()
    saved_runs = hashlib.sha256((out_dir / "runs.jsonl").read_bytes()).hexdigest()
    result = {"subset": subset, "manifest_identical": faults.manifest_hash(manifest) == saved_manifest,
              "runs_identical": runner.logs_hash(logs) == saved_runs}
    result["identical"] = result["manifest_identical"] and result["runs_identical"]
    return result
