# File inventory (final package; manuscript Rev 5.2.2)

Main code files, with line count, SHA-256 and purpose. "Original" = byte-identical to the file in `g1_silent_errors_v0.6_validation.zip` (hash from `docs/SHA256_ORIGINAL_FILES.txt`). Nothing in `src/`, `scripts/` (except the new file), `configs/` or `tests/` was modified. The complete list of every file with its hash is `docs/FILE_MANIFEST_V5.sha256`.

## Code, scripts and configuration

| File | Lines | SHA-256 | Status | Purpose |
|---|---|---|---|---|
| `src/g1/pipeline.py` | 149 | `9c873fe2f3d58134...` | original | The four-stage pipeline (S1-S4), conditions B0/F/I, `run_pipeline`, commit record, halt at first failed rule |
| `src/g1/rules.py` | 146 | `82da5947691d3ff8...` | original | Checkpoints CP1, CP2, CP3 and the final validation (RF.1-RF.6); `RuleConstants` |
| `src/g1/faults.py` | 168 | `eca9a5c45c88ab5d...` | original | Builds the fault manifest and injects T1-T5; T4 reserve top-up; manifest hash |
| `src/g1/experiment.py` | 137 | `78bf0a167fd9c55a...` | original | Orchestration: `prepare` (pool, split, constants, count gate), build manifests, run once, `verify_rerun` |
| `src/g1/runner.py` | 68 | `936548e4a5afc245...` | original | Runs each case under B0/F/I and attaches the oracle label |
| `src/g1/oracle.py` | 32 | `5129836826ad2dfc...` | original | Reference computation of the correct commit record, used only to label outcomes (not an independent validation) |
| `src/g1/metrics.py` | 267 | `a15b862fa4c4fe37...` | original | Metrics M1-M11, Wilson and bootstrap intervals, tables R1-R9 |
| `src/g1/split.py` | 73 | `430822f123b5ae1e...` | original | Deterministic split (1,000/50/500, rest reserve) and calibration constants (Q_max, P_max, T_max, countries, L) |
| `src/g1/data_prep.py` | 105 | `86fcc00bef2ab322...` | original | Scenario D pool from the raw table into `BaseInvoice` objects; writes `base_lines.csv` |
| `src/g1/eligibility.py` | 309 | `4b849d21a8828279...` | original | Eligibility rules and counts, duplicate signatures, price/pence facts |
| `src/g1/money.py` | 34 | `ac0b3eca521fe0dd...` | original | Exact decimal price to integer pence; integer line amount |
| `src/g1/seeding.py` | 87 | `7288330a664c7575...` | original | Master seed 20261029 and derived seeds; random-generator construction |
| `src/g1/protocol.py` | 29 | `7ff598d48d2f9d95...` | original | Loads and validates `configs/protocol_v1_0.json` and `seeds.json` |
| `src/g1/pilot_check.py` | 121 | `4d21970cd0fd3c46...` | original | Pilot-output inspection checks (used by `inspect_pilot.py`) |
| `src/g1/dataset_io.py` | 212 | `262671be86327857...` | original | Download/register the UCI ZIP, hash manifest, verify raw files |
| `src/g1/audit.py` | 240 | `7934f3e370b830db...` | original | Read-only dataset audit facts and report text |
| `src/g1/__init__.py` | 3 | `b82cf86086ba8cef...` | original | Package marker |
| `scripts/run_experiment.py` | 89 | `07556222ac21bde3...` | original | **MAIN ENTRY POINT**: `prepare`, `pilot`, `evaluate --confirm-freeze`, `verify-rerun` |
| `scripts/score_results.py` | 75 | `6bf06a08e80a2992...` | original | Scores the evaluation outputs and writes the 13 metric CSVs (once) |
| `scripts/inspect_pilot.py` | 35 | `e442eff7629ec55f...` | original | Read-only pilot inspection (exit 1 = FAIL) |
| `scripts/dataset_audit.py` | 115 | `f79398d27aa6c6f1...` | original | `download`, `register --zip`, `audit` for the raw data |
| `scripts/final_eligibility_audit.py` | 168 | `0fc3c3b4748d1f40...` | original | Read-only eligibility and fault-feasibility audit |
| `scripts/env_test.py` | 397 | `8fc08ca1671904c6...` | original | Environment test (PASS/WARN/FAIL; writes logs) |
| `scripts/verify_stored_results.py` | 66 | `e1a569c7b3ead7d2...` | NEW | **NEW (assembly, read-only):** recomputes headline numbers and hashes from the stored evaluation files |
| `configs/protocol_v1_0.json` | 35 | `4a72ee7ccfc92dd4...` | original | Protocol settings: pool counts, sizes, conditions, T4 policy, L method |
| `configs/seeds.json` | 10 | `03f5bab967570120...` | original | Seeds and offsets (status PROVISIONAL) |
| `requirements.txt` | 13 | `e006e420e33445e4...` | MODIFIED (comments only) | Minimum package versions (original lines unchanged; header comments replaced by recorded-version notes) |

## Tests (153 tests, all original)

| File | Tests | Covers |
|---|---|---|
| `tests/synth.py` | 0 | helper: synthetic invoice tables |
| `tests/test_dataset.py` | 10 | download/register/manifest logic |
| `tests/test_eligibility.py` | 14 | eligibility counts, price/pence |
| `tests/test_experiment.py` | 10 | prepare, pilot, guards, top-up policy, verify-rerun |
| `tests/test_faults_pipeline.py` | 26 | T1-T5, pipeline conditions, top-up |
| `tests/test_metrics.py` | 19 | metrics and tables |
| `tests/test_oracle_runner.py` | 19 | oracle and runner |
| `tests/test_pilot_check.py` | 6 | pilot inspector |
| `tests/test_prep_split.py` | 13 | pool, money, split, constants |
| `tests/test_rules.py` | 14 | CP1-CP3 and final validation |
| `tests/test_seeding.py` | 6 | seeds and RNG |
| `tests/test_validation_scale.py` | 16 | scale and edge cases |

## Supporting material (not code)

- `docs/`: original package documents (`ORIGINAL_v0.6_README.md`, `COLAB_COMMANDS.md`, `DATASET_*`, `DEPENDENCIES.md`, `IMPLEMENTATION_REPORT_PROMPT09.md`, `TROUBLESHOOTING.md`, `PROJECT_STRUCTURE.md`, `ENVIRONMENT_VERIFICATION_LOG.md`) and assembly documents (decision record, discrepancy report, recorded hashes, plans, result map, paper check, demo script, viva sheet).
- `notebooks/`: original environment-check notebook; two assembly notebooks marked UNTESTED.
- `results/stored_evaluation/`, `results/stored_figures/`: stored outputs, unchanged (`results/CHECKSUMS_STORED_RESULTS.sha256`).
- `paper/`: manuscript Rev 5.2.2 final (claims corrected, body 10 pages excluding references, 13 in total; see `docs/CHANGE_REPORT_FINAL.md`); figures, bibliography and class unchanged.

## Differences from the original v0.6 package

- `README.md` of the original is kept unchanged as `docs/ORIGINAL_v0.6_README.md`; the root `README.md` is new.
- `requirements.txt`: package lines identical; header comments differ.
- Added: `scripts/verify_stored_results.py`, `scripts/h3_replay_check.py` (v4), `docs/H3_EVIDENCE_REPORT.md`, `docs/H3_REPLAY_OUTPUT.txt`, `docs/REQUIREMENT_TO_FILE_MATRIX.md` (v4), `scripts/check_paper_vs_csv.py`, `docs/AUTHOR_REVIEW_SHEET.md`, `docs/CHANGE_REPORT_FINAL.md`, `paper/supplementary_text.*`, `paper/build_supplement_text.py`, `paper/change_log_rev5_2_2.md` (v5), `PROMPT07_FINAL_DECISIONS.txt`, `START_HERE.md`, `docs/` assembly files, `notebooks/` assembly notebooks, `results/stored_*`, `paper/`, `data/README.md`.
- No explanatory file replaces any code file; all 17 `src/g1/*.py` files, all 6 original scripts, 2 configs and 12 test files are present.
