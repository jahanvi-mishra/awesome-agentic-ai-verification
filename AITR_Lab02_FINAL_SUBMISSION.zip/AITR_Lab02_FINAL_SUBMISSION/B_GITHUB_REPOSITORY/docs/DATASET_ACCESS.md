# Dataset access, download and audit

Dataset: UCI Machine Learning Repository, "Online Retail", ID 352. Official page: https://archive.ics.uci.edu/dataset/352/online+retail
From Prompt 06 (not re-verified here): CC BY 4.0, 541,909 rows, 8 variables, about 22.6 MB xlsx. Real file contents and anomaly counts are UNKNOWN until the audit report exists.

## What the code does (scripts/dataset_audit.py, src/g1/dataset_io.py, src/g1/audit.py)
| Command | Effect |
|---|---|
| `download` | fetches the zip ONLY from https://archive.ics.uci.edu (redirects leaving that host are refused), saves it to data/raw/online_retail.zip, extracts the one .xlsx, writes data/raw/SOURCE_MANIFEST.json, marks the files read-only |
| `register --zip PATH` | fallback if the download is blocked: you save the zip from the official page in your browser; the code copies (never moves) it and does the same registration; the record says "manual_registration" |
| `audit` | re-hashes the raw files (must match the manifest), reads the xlsx read-only, writes logs/dataset_audit_<UTC>.md and .json, re-hashes again |

Recorded in the manifest: source URL, final URL, local and URL file names, sizes, SHA-256 of zip and xlsx, zip member list with CRC32, download or registration time (UTC), HTTP headers when available (Last-Modified, ETag), licence note, dataset version. UCI gives no version field the code can read, so the version is stored as UNKNOWN; copy the page's date information in by hand.

## Safety rules
- Raw files are created once (exclusive mode); existing files are never overwritten, edited or deleted by the code.
- The audit reads everything as text/objects, changes nothing, drops nothing, fixes nothing.
- The raw zip, xlsx and manifest are read-only. In Colab you run as root, so read-only is a guard, not a lock; the hash check is the real protection.
- A second copy of data/raw and the report should be saved to Google Drive (copy, not move). See docs/DATASET_AUDIT_COMMANDS.md.

## What the audit deliberately does NOT do
- No cleaning, no filtering, no case selection, no train/calibration/evaluation split.
- No invoice-total percentiles, so the constant L cannot be set from all data by accident.
- Whole-file statistics must not be used for Q_max, P_max, T_max, L or the Country set; those come from the calibration subset later.
