# Technical viva sheet (short answers you can say aloud)

**Research question.** Do deterministic checkpoints between pipeline stages, added to a final validation, reduce harmful faults that reach the final commit, and at what cost in extra checks and false alarms?
**Why it matters.** In a multi-stage agentic workflow a wrong value from an early stage can be accepted by all later stages (a *silent error*). Final-only checking may be too late.
**What the pipeline is.** A deterministic four-stage Python simulation: S1 intake, S2 transform (line amounts), S3 state update (totals), S4 decide and commit (POST/HOLD). It stands in for an agentic workflow; **no LLM is used**.
**Commit record.** Six fields: invoice number, customer, country, number of lines, total (integer pence), decision.
**Conditions.** B0 no checks (reference). F final validation only (RF.1-RF.6). I = CP1 (intake), CP2 (after transform), CP3 (after state update), then the identical final validation. Halt at the first failed rule; no repair or retry.
**Fault types.** T1 missing CustomerID or UnitPrice; T2 quantity becomes text like "3 pcs"; T3 negative or 10x-maximum quantity; T4 one line amount uses another line's price (after S2); T5 total or CustomerID copied from another invoice (after S3).
**Harmful.** A fault is harmful if the B0 commit record differs from the reference record. All 2,500 injected cases were harmful.
**Data and split.** UCI Online Retail ID 352; invoices split by seed 20261029 into 1,000 calibration, 50 pilot, 500 evaluation, rest reserve. Calibration only sets constants (Q_max, P_max, T_max, country set, limit L). 10 reserve invoices replace 10 evaluation invoices that cannot host T4.
**Metrics.** M1 reach-commit rate among harmful cases; M4 false-alarm rate on clean cases; cost = rule applications per run. Wilson intervals; invoice-level bootstrap (2,000 resamples) for the F-minus-I difference.
**Results.** F 1,972 / 2,500 (78.88%) reach commit; I 0 / 2,500. Difference 78.88 points (77.24 to 80.39). False alarms 10 / 500 under both. I applies 13.07x the rules (71.41 vs 5.46 per run). T1 and T3 reach commit about half the time under F (49.8%, 51.4%); T2, T4, T5 about 98%.
**Why I is zero: be careful.** The checkpoints were written for these five faults, and F's checks are nested inside I's, so "I catches everything F catches" is by construction. The result is coverage of a known list, not general detection.
**Limitations.** Simulation only; confounded position/information/rule count (no ablation); no wall-clock cost; RQ2 not evaluated; single run, seed and dataset; same author/AI for code, tests and audit (common-mode risk); no published baseline reproduced; reference module is not independent; 13+ items of provenance missing (see README).
**Tests vs experiment.** 153 unit tests pass on synthetic data. That shows the code behaves as designed; it is **not** the research experiment.
**Stored vs reproduced.** The result files are my Colab outputs. I re-checked that they agree with each other; I did not reproduce them from raw data here. Missing: original logs, pilot output, freeze decisions file, raw-data manifest.
**Why no LLM?** Controlled, deterministic ground truth and exact repeatability; LLM-agent behaviour is future work.
**AI assistance.** Claude (Anthropic) was used under my direction for planning, code, tests, audits, figures, drafting and reference checking; the log (`ai_assistance_log.md`) lists activities, including AI errors that were found and corrected (T4 sampling bug, misattributed citation, over-claimed interval). I am responsible for the content.

## Likely questions
1. *Is this an LLM-agent study?* No; a deterministic stand-in.
2. *Is I = 0 impressive?* Only as taxonomy coverage; checks were designed for these faults.
3. *Why 10 reserve invoices?* 10 evaluation invoices had fewer than two distinct unit prices, so T4 could not be injected; the protocol tops up from reserve.
4. *What do the false alarms mean?* 10 of 500 clean invoices halted under both F and I (shared final validation and calibration-derived limits).
5. *Did you reproduce a baseline?* No. B0 is an internal reference.
6. *Can I rerun it?* With the raw data: yes, per `docs/PROTOCOL_IMPLEMENTATION_CHECK.md` (not tested here); my original 14-item decisions file is recovered in the repository root. Without them I report stored results only.
7. *What is missing?* See README "MISSING / NOT VERIFIED".
8. *Why is the seed provisional?* `seeds.json` records it as provisional; no approval record exists. I do not claim a frozen protocol.

**Q (added 11 Nov 2026): Is the fault draw order (H3) verified?** No. The stored manifest and runs hashes equal the recorded values, and 3,256 draw-dependent parameters in the stored manifest match a replay of seed 20261031 in the implemented order (`scripts/h3_replay_check.py`). That is consistency evidence. T4 line choices, the 10 reserve draws, pilot seed usage, code provenance and historical approval are unverified, and no fresh `evaluate` has been run. See `docs/H3_EVIDENCE_REPORT.md`.

**Q (added 13 Nov 2026): The paper says 57 audit checks passed. Can you show them?** No. The audit script and its output are not in the project, so I report that result as my earlier account only. What I can show is `scripts/verify_stored_results.py` (19 PASS lines), `scripts/check_paper_vs_csv.py` (61 checks, 0 failures) and the 153 unit tests on synthetic data. These check consistency of stored files and code, not an independent reproduction.
