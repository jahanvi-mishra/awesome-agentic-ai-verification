# Likely failures and diagnostics

| Symptom in output | Likely cause | What to do |
|---|---|---|
| `python: can't open file 'scripts/env_test.py'` | wrong folder / zip not extracted | run `%cd /content/drive/MyDrive/g1_silent_errors`, then `!ls` |
| `FAIL project_dirs_writable ... missing` | partial unzip | re-run unzip with `-o`; check zip is the full file |
| `FAIL ... not writable` | Drive not mounted or full | re-run `drive.mount`; check Drive storage |
| `FAIL dependencies ... missing` | package absent | `!pip install -q -r requirements.txt` |
| `FAIL imports` with `numpy.dtype size changed` / `binary incompatibility` | numpy/pandas mismatch after pip upgrade | Runtime > Restart session, re-run Cell 5 |
| `pip` dependency-resolver warnings | Colab preinstalled packages conflict | note them; they matter only if a later check FAILs |
| `WARN dependencies ... newer major version` | pandas 3 / numpy 3 etc. | not a failure; read remaining checks and unit tests; send output |
| `FAIL excel_roundtrip` | openpyxl missing/old | `!pip install -q "openpyxl>=3.1"` |
| `FAIL matplotlib_png` | backend/font issue | send the full traceback line |
| `WARN drive_persistence` | project is under /content | move to Drive or accept and download logs often |
| `WARN network_uci_page` | Colab or UCI temporarily unreachable | not fatal; manual browser download still works |
| `FAIL unit_tests` | seeding code changed or numpy issue | run `!python -m unittest discover -s tests -v` and send output |
| Runtime disconnected mid-run | idle timeout | reconnect, re-mount Drive, re-run from Cell 1 |
