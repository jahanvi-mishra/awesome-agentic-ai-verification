# H3 evidence report (read-only; 11 November 2026)

**H3** = fault draw order, with pilot and evaluation both starting the fault stream at the derived fault seed 20261031. **Status: UNCONFIRMED PENDING EVALUATION MANIFEST HASH VERIFICATION. H3 is not fully verified.**
Nothing was regenerated. No raw data, pilot, evaluation or prediction was used or created. Stored results and v0.6 source are unchanged.

## 1. What was checked and found

| Check | Result | Evidence level |
|---|---|---|
| Canonical manifest hash (`g1.faults.manifest_hash` of `results/stored_evaluation/manifest.json`) vs recorded `ce58e5613cca7129970f230e2c268634a3890adf6c81016e390f3420fb4ddf50` | **match**; also equals `manifest.sha256` and `summary.json` | VERIFIED (stored files agree with the record) |
| Plain `sha256sum` of the pretty-printed `manifest.json` file | `e1df73bb...` (differs by design; the recorded value hashes the canonical compact JSON) | not a discrepancy |
| `runs.jsonl` SHA-256 vs recorded `5380db45a873c4499f6cd750151f3bb819f699b105857c6f1e0bd81eb6ecd0c5` | **match** | VERIFIED |
| `evaluation_audit_bundle.zip` `evaluation/` and `paper_figures/` vs `results/stored_evaluation/` and `results/stored_figures/` | identical (18 files each, `diff -r`) | VERIFIED |
| Manifest row order | invoices in sorted text order; rows CLEAN, T1..T5 inside each invoice | VERIFIED from the file |
| Manifest contents | 3,010 rows (3,000 main + 10 `t4_reserve`); realised parameters stored; **no seed and no raw draw values** | VERIFIED from the file |
| Seed derivation (`protocol.load_protocol` -> `seeding.derive_seeds`) gives faults = 20261031; pilot and evaluation both start there (`experiment.build_subset_manifest`) | as stated | VERIFIED by reading the code (not evidence of what the original run did) |
| Replay of seed 20261031 in the implemented order (T1 2, T2 1, T3 2, T4 2, T5 2 draws per invoice) against the stored manifest | **3,256 draw-dependent parameters checked, 0 mismatches** | CONSISTENCY evidence (`scripts/h3_replay_check.py`; output in `docs/H3_REPLAY_OUTPUT.txt`) |
| Negative controls (seeds 20261029 / 20261030 / 20261032) | 2,361 / 2,373 / 2,382 mismatches of 3,256 | shows the test is sensitive to the seed |

The 3,256 checks cover T1 target and unit-price line index, T2 line index, T3 variant and line index, and T5 target and partner, for the 500 main invoices.

## 2. What remains UNVERIFIED
1. **T4 line choices**: they depend on unit prices, so the raw data is needed.
2. **The 10 reserve top-up draws** and the stream position they continue from (also need the reserve invoices).
3. **Pilot seed usage**: no pilot output exists; the code shares the start seed but nothing shows what the original pilot did.
4. **Original code provenance**: which code version produced the stored files is not established (v0.6 is the likeliest; the 153 tests match).
5. **Historical approval or intent** of the draw order: no dated record.
6. **A fresh regeneration**: whether `prepare` then `evaluate` on freshly downloaded data reproduces `ce58e561...` and `5380db45...` has not been run.

## 3. Consequence for the claims
The stored evaluation is hash-consistent and consistent with the documented seed and draw mechanism. It is **not** independently reproduced, and H3 is **not** confirmed. Only a later full evaluation whose manifest and runs hashes equal the recorded values would confirm H3, and even then it would show only that this code reproduces the stored outputs, not that H3 was the intended design. A fresh evaluation is **not** needed for the claims as worded in the paper ("stored results ... not re-run by a second person"); it is needed only to claim reproduction.

Run it yourself (read-only, numpy only): `python scripts/h3_replay_check.py` (defaults: `results/stored_evaluation`, seed 20261031).
