# Requirement-to-file matrix and deliverables audit (11 November 2026)

Source of requirements: the course handout (G1-G4 gates, research standard, repository structure) and the author's final-assembly brief. Checked on the v3 files; v4 adds only documentation and one read-only script. **COMPLETE** means present and consistent with the evidence; it does not mean verified by an independent run.

| # | Requirement | Where it lives | Status | Note / caveat |
|---|---|---|---|---|
| 1 | Paper PDF | `paper/manuscript_rev5_2_1.pdf` (Rev 5.2.2, **10 pages**) + `paper/supplementary_text.pdf` (2 pages, methodology detail and discussion) | COMPLETE | Body exactly 10 pages excluding references (13 pages in total); the PDF name keeps the rev5_2_1 stem so existing paths work. Rebuilt in v5 |
| 1 | LaTeX, bibliography, figures | `paper/manuscript_rev5_2_1.tex`, `.bbl`, `refs.bib`, `acmart.cls`, `paper/figures/`, `paper/supplementary_text.tex/.pdf`, `paper/supplementary*` | COMPLETE | LaTeX rebuilt in v5 (pdflatex + bibtex, no undefined citations); references checked at abstract level only (stated in the paper) |
| 2 | Complete Python implementation | `src/g1/` (16 modules), `scripts/`, `tests/` (153 tests pass on a copy, sandbox) | COMPLETE | v0.6 unchanged (hash-checked against `docs/SHA256_ORIGINAL_FILES.txt`); `scripts/h3_replay_check.py` added, read-only |
| 3 | Dataset source, preprocessing, reproducibility | `data/README.md`, `docs/DATASET_ACCESS.md`, `docs/RECORDED_DATASET_HASHES.md`, `docs/COLAB_COMMANDS.md`, `docs/PREPARE_ONLY_COLAB_PLAN.md`, `configs/`, `requirements.txt` | COMPLETE | Raw data not redistributed. Hashes, counts and constants are recorded values, **not re-derived** until the prepare-only run |
| 4 | Evaluation CSVs, metrics, logs, figures | `results/stored_evaluation/` (runs, labels, manifest, summary, 13 metric CSVs), `results/stored_figures/`, `results/logs/colab_env_check_console_2026-10-31.txt` | COMPLETE as stored files; provenance NOT established | Original Colab run logs, pilot output, calibration-constants file are MISSING |
| 5 | Research brief (G1) | `docs/research_brief_one_page.md` | COMPLETE | |
| 6 | Baseline validation report (G2) | `baseline_validation.md` | NEEDS AUTHOR REVIEW | Fixed in v4: it cites `audit_evaluation.py`, `eval_audit/audit_checks.csv`, `change_summary_rev5.md`, which are **not in the repository**; now flagged. B0 validation is internal; no published baseline reproduced |
| 7 | AI assistance log | `ai_assistance_log.md` (A1-A23; evidence audit in its Section 1A) | NEEDS AUTHOR REVIEW | Draft; every row must be confirmed against her own history; A1-A9 prompts/dates UNKNOWN; A7 pilot/evaluation runs are author-reported, no log |
| 8 | README, START_HERE, repo structure | `README.md`, `START_HERE.md`, `docs/PROJECT_STRUCTURE.md`, required tree | COMPLETE | All required top-level items present: README, requirements, configs, data/README, notebooks, src, scripts, results, paper, research_decisions, baseline_validation, ai_assistance_log |
| 9 | 5-minute demo script, viva sheet | `docs/DEMO_SCRIPT_5MIN.md`, `docs/VIVA_SHEET.md` | COMPLETE | They repeat the author's statement that the results are her Colab outputs; no log supports it, and both say so |
| 10 | Author decision record + review sheet | `docs/AUTHOR_DECISION_RECORD.md` / `.docx`, `docs/AUTHOR_REVIEW_SHEET.md` | NEEDS AUTHOR ACTION | PROPOSED, **unsigned**; only the author can sign, with the actual signing date |
| 10 | Protocol discrepancy report | `docs/PROTOCOL_DISCREPANCY_REPORT.md` / `.docx` | COMPLETE | |
| - | Prompt 07 14-item protocol text | `PROMPT07_FINAL_DECISIONS.txt` | COMPLETE (recovered) | v0.1 / v0.2 texts MISSING |
| - | Execution logs of the original run | - | MISSING | Not available anywhere |
| - | Fresh execution evidence | executed prepare-only notebook output | NOT YET DONE | Needs the author's Colab run |

## Cross-checks (all read-only)

| Check | Result |
|---|---|
| Paper headline numbers vs `R1`, `R2`, `R4`, `R5`, `R6`, `summary.json` (78.88%, 1,972 / 2,500, 0 / 2,500, interval 77.24 to 80.39, 13.07, 16,390, 214,231, 5.46, 71.41, 10 of 500, per-type 49.8 / 98.0 / 51.4 / 97.6 / 97.6) | All present in the PDF, `.tex` and source markdown, and equal to the stored CSVs |
| Denominators | 2,500 harmful (5 types x 500), 500 clean, 3,000 runs per condition; 10 T4 reserve cases among the 500 T4 injections; M2 = 1 - M1 (528 / 2,500) |
| F and I outcome counts (`summary.json`) | F committed 2,462 = 1,972 faulty + 490 clean; I committed 490 clean only; 10 clean false alarms each: consistent |
| Tables and figures vs the same outputs | `paper/supplementary/figure_data/*.csv` match the stored metrics; Figure 1 is conceptual (no data); Figures 2, S1, S2 come from the stored CSVs |
| Methodology vs code | B0 no checks, F final validation only, I CP1-CP3 plus the identical final validation, halt at first failed rule, no repair: matches `docs/PROTOCOL_IMPLEMENTATION_CHECK.md` and the tests |
| Run commands refer to existing files | Checked every path quoted in the docs: all exist, except outputs of future runs (`results/evaluation/`, `results/splits.json`, ...), `predictions.json` (RQ2 not evaluated), and the three files noted above |
| Limitations disclosed | Paper Section 8 (14 items), README MISSING / NOT VERIFIED, START_HERE status table |
| No false reproduction claim | Documents say "stored, internally consistent, not independently reproduced". Fixed in Rev 5.2.2 (v5): paper Section 9 now says the author *reports* the Colab run, with no logs, and separates stored results from current consistency checks; Section 10 calls the decision record an unsigned draft. Author must confirm the new wording |

## Issues fixed in v4 (documentation only); later changes are in `docs/CHANGE_REPORT_FINAL.md`
1. H3 status updated with the read-only evidence (`docs/H3_EVIDENCE_REPORT.md`, decision record md/docx, baseline validation rows 4-5, README, START_HERE, VIVA_SHEET).
2. `baseline_validation.md`: three cited files not in the repository are now flagged.
3. `ai_assistance_log.md`: row A22 added; `SUBMISSION_GUIDE.md` range updated to A1-A22.

## Left for the author
Confirm the new wording of paper Sections 9 and 10; sign the decision record; confirm every AI-log row. Automated check: `python scripts/check_paper_vs_csv.py` (read-only): paper numbers vs stored CSVs, 61 checks.
