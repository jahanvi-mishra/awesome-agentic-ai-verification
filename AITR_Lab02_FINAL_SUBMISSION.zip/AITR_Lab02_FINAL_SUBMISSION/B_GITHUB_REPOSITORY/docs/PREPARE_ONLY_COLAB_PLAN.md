# Prepare-only execution plan for a fresh Google Colab session

**Scope.** Environment checks, dataset download/hash check, dataset audit, and `prepare` only. **No pilot, no evaluation, no scoring, no predictions file, no source or config edit.** Nothing here has been run; all commands are NOT TESTED in Colab (the comparison logic was tested locally on synthetic output only). The notebook that automates this plan is `notebooks/g1_prepare_only_colab_UNTESTED.ipynb`.

## Before you start
1. Finish and sign `docs/AUTHOR_DECISION_RECORD.md` (decisions A-H). Step 6 will not run until you set `APPROVAL_RECORD_FINALISED = True`.
2. Open a **new** Colab notebook, CPU runtime. Upload `AITR_Lab02_Project_FINAL.zip` (Files panel), then open and run `g1_prepare_only_colab_UNTESTED.ipynb` from the ZIP, or paste its cells.
3. Use a fresh session. Never use a Drive folder where an earlier run exists.

## Steps, expected values and stop rules
| Step | Command (existing code) | Expect | If different |
|---|---|---|---|
| 1 | unzip; check protocol file sha256; check v0.6 files against `docs/SHA256_ORIGINAL_FILES.txt` | protocol sha256 `abbe90370a07...931542`; no changed files; no prior `results/` | **STOP** |
| 2 | `pip install -r requirements.txt`; `python scripts/env_test.py` | PASS/WARN only (exit 0) | exit 1 = FAIL: **STOP** |
| 3 | `python scripts/dataset_audit.py download` (fallback: `register --zip PATH`) | `data/raw/SOURCE_MANIFEST.json` written | fallback; else **STOP** |
| 4 | compare manifest hashes with the recorded ones | raw XLSX `43465a06f2cc...`; ZIP `f5385cbb54bb...` | **STOP**; do not audit or prepare |
| 5 | `python scripts/dataset_audit.py audit` | 541,909 rows x 8 columns | **STOP** |
| 6 | `python scripts/run_experiment.py prepare` | pool 17,023; T4-capable 16,679; `base_lines_sha256` `67f95be8...`; `split_sha256` `c6bfe38c...`; Q_max 2400; P_max 394932; T_max 1195610; L 81216 | exit 3 or any mismatch: **STOP** |
| 7 | save the evidence zip | `prepare_only_outputs.zip` | n/a |

Full recorded hashes: `docs/RECORDED_DATASET_HASHES.md`. The base-lines and split labels are INFERRED to be the hashes printed by `prepare` for `data/interim/base_lines.csv` and the split; a mismatch there is first reported, not assumed to be an error in the data.

## How to read a mismatch (explain, do not repair)
| Mismatch | Likely meaning | What it implies for decisions |
|---|---|---|
| Raw XLSX hash differs | different file version or a bad download | the original data cannot be confirmed; stop |
| XLSX matches, ZIP differs | UCI re-packaged the ZIP | data unchanged in content; record and ask the assistant before continuing |
| Pool or T4 count differs (exit 3) | pool rules differ from the original (decisions A, B, C) | the rule set is not the one used originally; do not edit code |
| Counts match, base-lines hash differs | different pool membership or order (decision A "first", or C) | same count, different invoices |
| Split hash differs | pool differs, or permutation/seed differs (H1) or library version drift | see versions printed in Step 2 |
| L differs, others match | percentile method (H2) | decision H2 is not what was used |
| All match | the code, under the operative readings, reproduces the recorded pool, split and constants | supports A, B, C, H1, H2 as the readings that were used; it does **not** prove they were intended or approved, and it does **not** test H3 (fault draw order), which stays unconfirmed pending evaluation manifest hash verification |

## Outputs and files
The run writes only inside the fresh working copy: `data/raw/*` (raw ZIP, XLSX, manifest; read-only), `logs/` (environment and audit reports), `data/interim/base_lines.csv`, `results/splits.json`, `results/constants_calibration.json`, plus the transcripts the notebook saves. Raw data is **not** included in the evidence zip and must not be committed.

## After prepare-only
Send `prepare_only_outputs.zip` (or the printed comparison table). Pilot and evaluation need a separate decision. Evaluation remains: `evaluate --confirm-freeze` (refuses a second run), `verify-rerun evaluation`, `score_results.py evaluation`, and comparison with the stored hashes (see `docs/PROTOCOL_IMPLEMENTATION_CHECK.md`, section 5).
