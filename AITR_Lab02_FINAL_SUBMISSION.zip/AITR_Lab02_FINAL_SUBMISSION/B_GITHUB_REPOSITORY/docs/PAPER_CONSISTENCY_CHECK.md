# Paper consistency check (manuscript Revision 5.2.1 against code and stored results)

Checked 2026-11-10 from the files in this repository. The manuscript was **not rewritten**. Sources: `paper/manuscript_rev5_2_1_src.md` (same text as the `.tex`), `results/stored_evaluation/`, `src/`, `configs/`.

## A. Numbers that match the stored files
Headline and secondary numbers match `R1`, `R2`, `R4`, `R5`, `R6`, `summary.json`: 78.88%, 1,972, 0/2,500, interval 77.24 to 80.39, 13.07, 16,390, 214,231, 5.46, 71.41, 10 of 500 false alarms, per-type 49.8 / 98.0 / 51.4 / 97.6 / 97.6%, the 302 decision-changing cases (2/9/234/17/40), 9 of 10 reserve T4 cases reaching commit, 20261029 seed, 17,023 / 16,679. The counts were recomputed from case-level files (see `docs/RESULT_TO_SOURCE_MAP.md`); intervals were not.
Paper statement "153 tests, all passing": re-confirmed in the assembly sandbox on a copy of v0.6.

## B. Claims that cannot be supported from the files supplied (already flagged in the paper, Section 8 item 13)
1. That `prepare -> evaluate -> verify-rerun -> score_results` were run in Colab, by whom, how many times, and on which version: **no logs**; the only evidence is the stored bundle. v0.6 is the likeliest version (153 tests match) but not established.
2. Pilot results, calibration-constants file, eligibility report, Prompt 07 v0.2 text, raw-data manifest and retrieval date, seed approval, protocol freeze record (date/hash): **missing**. *Update:* the 14-item decisions text is now recovered (`PROMPT07_FINAL_DECISIONS.txt`); it confirms that 17,023 and 16,679 are in the author's record (items 1 and 11) and that the condition "at least two lines" is **not** among the 14 items, as the manuscript already says. The manuscript was not edited.
3. Eligibility counts and calibration constants: the counts are now verified as recorded in the author's decisions file; neither counts nor constants are re-derived from the raw data.
4. Determinism re-run (`verify-rerun evaluation`): not recorded.

## C. Wording and consistency points for the author to decide (no change made)
1. `src/g1/oracle.py` docstring calls the module an "Independent ground-truth oracle"; the paper correctly calls it a **reference module, not an independent validation**. Keep the paper wording. The code was left unchanged on purpose.
2. `configs/seeds.json` says PROVISIONAL; the paper says so too. Do not describe the seed as approved or the protocol as frozen.
3. The README inside the original v0.6 package (kept unchanged as `docs/ORIGINAL_v0.6_README.md`) says "Status (v0.5): ... NOT been run on the real dataset and no experimental result exists"; that status line is out of date relative to the stored results. Use this repository's root `README.md`.
4. Length: the change log says about 14 pages total and 11.6 pages main text; the stated 6-10 page target is **not met**. Decide whether this matters for the instructor.
5. The AI-use paragraph (Section 10) is factual but still needs the author's approval of its wording; `ai_assistance_log.md` is a draft.
6. The LaTeX build was not re-run here; the PDF in `paper/` is the one supplied. `paper/refs.bib` was not re-verified; the paper states references were checked at abstract level only.
7. Figure 1 (pipeline) is conceptual and has no data source; Figure 2 (moved to the supplement as Figure S3 in Rev 5.2.2) and the supplementary figures are drawn from the stored CSVs (figure source values identical).

## D. Scope reminders (unchanged)
Deterministic simulation, not an LLM-agent experiment; no published baseline reproduced; RQ2 not evaluated; checkpoints were written for the injected fault types, so the result is coverage of this taxonomy.


## Addendum (12 November 2026, v5): Rev 5.2.2 re-check
- The manuscript was revised (claims in Sections 9-10 corrected; body fitted to exactly 10 pages excluding references; related work, per-type figure, false-alarm and classification detail restored in the final package). Paper numbers are now checked by `scripts/check_paper_vs_csv.py` (61 checks, 0 failures).
- `python scripts/check_paper_vs_csv.py` (read-only): 46 checks of Tables 4 and 5, rule applications, false alarms, Wilson intervals, halting attribution and first failing rules against `results/stored_evaluation/metrics/*.csv`: 0 failures.
- The length finding in item 4 above is resolved: 10 pages (acmsmall, unchanged fonts and margins).
- Still open: the original Colab logs, pilot output and calibration-constants file; author approval of the new wording of Sections 9 and 10.
