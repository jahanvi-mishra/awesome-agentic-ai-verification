# Exact commands to run the environment test in Colab

Runtime: Runtime > Change runtime type > Hardware accelerator: **None (CPU)**.

## Cell 1 - mount Drive (so files survive a runtime reset)
```python
from google.colab import drive
drive.mount('/content/drive')
```

## Cell 2 - unzip the project (zip must already be in My Drive)
```bash
!unzip -o -q /content/drive/MyDrive/g1_silent_errors_env_v0.1.zip -d /content/drive/MyDrive/
%cd /content/drive/MyDrive/g1_silent_errors
!ls
```
Without Drive: run `from google.colab import files; files.upload()`, pick the zip, then
`!unzip -o -q g1_silent_errors_env_v0.1.zip` and `%cd g1_silent_errors`. The test will WARN that files are not on Drive.

## Cell 3 - show interpreter and package state BEFORE installing
```bash
!python --version
!pip list 2>/dev/null | grep -i -E "^(numpy|pandas|matplotlib|openpyxl|pytest) "
```

## Cell 4 - install only what is missing or too old
```bash
!pip install -q -r requirements.txt
```
If pip says it changed numpy or pandas, do Runtime > Restart session, then continue from Cell 5.

## Cell 5 - run the test
```bash
!python scripts/env_test.py
```
Optional connectivity check (headers only, no download): `!python scripts/env_test.py --network`

## Cell 6 - show saved evidence
```bash
!ls -l logs
!cat logs/env_check_*.txt
```
Copy the full output of Cells 3-6 to me. Do not edit it.
