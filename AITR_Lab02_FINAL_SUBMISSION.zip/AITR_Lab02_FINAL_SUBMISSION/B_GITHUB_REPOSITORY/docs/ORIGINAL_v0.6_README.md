# G1: Verification Checkpoints for Silent Errors (Colab CPU)

Deterministic four-stage Python pipeline (a simulation of an agentic workflow, NOT an LLM agent) comparing
B0 (checks off, reference), F (final validation only) and I (CP1-CP3 + identical final validation) on
invoices from UCI Online Retail (ID 352). Frozen decisions: `PROMPT07_FINAL_DECISIONS.txt`; settings: `configs/protocol_v1_0.json`.

Status (v0.5): code complete and unit-tested on synthetic data only. It has NOT been run on the real dataset and
no experimental result exists.

## Run in Colab (project at /content/g1_silent_errors, raw data already in data/raw)
```
%cd /content/g1_silent_errors
!python -m unittest discover -s tests 2>&1 | tail -5          # all tests
!python scripts/run_experiment.py prepare                      # pool -> splits -> calibration constants (stops if counts differ from 17,023 / 16,679)
!python scripts/run_experiment.py pilot                        # debugging run on 50 pilot invoices
```
The main run is deliberately separate and refuses to run twice:
```
!python scripts/run_experiment.py evaluate --confirm-freeze
!python scripts/run_experiment.py verify-rerun evaluation      # determinism check, writes nothing
!python scripts/score_results.py evaluation                    # metrics M1-M11 and tables R1-R9 as CSV (writes once)
```
Check that an existing pilot run is untouched by v0.5: `!python scripts/run_experiment.py verify-rerun pilot` must print `"identical": true`.
Pilot scoring (debugging only): `!python scripts/score_results.py pilot`.
Optional input for RQ2: `results/predictions.json`, e.g. `{"T1": true, "T2": false, "T3": false, "T4": true, "T5": false}` (true = predicted to escape F), written BEFORE the main run.

T4 sampling: the whole pool is split and T1, T2, T3, T5 cover every evaluation invoice. T4 cases come only from T4-capable
invoices: evaluation invoices that are not capable get a logged skip, and the shortfall is topped up from T4-capable invoices
outside all subsets (fixed order, same fault generator), so T4 also has one case per evaluation invoice. The pilot only skips.

## Where things are
| Folder / file | Purpose |
|---|---|
| src/g1/data_prep.py, eligibility.py | Scenario D pool, base invoices, CSV copy |
| src/g1/split.py | deterministic split + calibration constants (Q_max, P_max, T_max, Country set, L) |
| src/g1/pipeline.py, rules.py | stages S1-S4, conditions, CP1-CP3, final validation, ledger |
| src/g1/faults.py | T1-T5 manifest and injection hook |
| src/g1/oracle.py | independent ground truth and harm labels |
| src/g1/runner.py, experiment.py | run B0/F/I, JSONL logs, orchestration |
| src/g1/metrics.py, scripts/score_results.py | M1-M11, Wilson and bootstrap intervals, tables R1-R9 as CSV |
| scripts/run_experiment.py | command line (prepare, pilot, evaluate, verify-rerun) |
| tests/ | 131 unit and integration tests (synthetic data only) |

Outputs (each written once, never overwritten): data/interim/base_lines.csv, results/splits.json,
results/constants_calibration.json, results/{pilot,evaluation}/{manifest.json, manifest.sha256, runs.jsonl, labels.jsonl, summary.json} and results/<subset>/metrics/*.csv
(metrics_summary, R1_primary, R2_per_type, R3_outcome_overlap, R4_halting_attribution, R4b_halting_by_rule, R5_clean_false_alarms, R5b_false_alarm_cases, R6_cost, R7_missed_by_both_review, R8_exclusions_anomalies, R9_decision_rules, cases_joined).
Run logs hold case id and pipeline outcome only; fault types are in the manifest and joined later.

## v0.6 – final pilot validation (synthetic) and pilot inspector

- `tests/test_validation_scale.py`: T4 reserve top-up at protocol scale (1000/50/500) and M1–M11 / R1–R9 edge checks on synthetic data.
- `src/g1/pilot_check.py` + `scripts/inspect_pilot.py`: read-only inspector for a REAL finished pilot. Run in Colab:
  `python scripts/inspect_pilot.py pilot` and paste the output. It writes nothing; exit code 1 means at least one FAIL.
- No protocol, seed, split, dataset-preparation or pilot-manifest code was changed. Full evaluation has NOT been run.
