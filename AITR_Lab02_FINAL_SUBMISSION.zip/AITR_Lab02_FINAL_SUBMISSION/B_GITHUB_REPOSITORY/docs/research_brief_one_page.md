# Research brief (one page)

**Title:** Designing Verification Checkpoints to Mitigate Silent Errors in Agentic AI Pipelines
**Author:** Jahanvi Mishra, M.Tech, IIIT Allahabad. **Guide:** Prof. Sonali Agarwal.

**Problem.** In a multi-step automated workflow, an early step can produce a wrong value that every later step accepts, so a wrong result is committed and no error is raised (a *silent error*). Checking only the final output may be too late.

**Question.** Does adding small, deterministic checks *between* the stages, on top of a final check, reduce the harmful faults that reach the final commit, and what does it cost in extra checking and false alarms?

**Design (a controlled stand-in, not an LLM agent).** A four-stage Python pipeline turns invoices from the UCI Online Retail data set (ID 352) into entries in a simulated ledger. Five fault types are injected one at a time: T1 a missing CustomerID or UnitPrice, T2 a quantity written as text, T3 an impossible quantity, T4 a line amount using another line's price, T5 a total or CustomerID copied from another invoice. Three conditions: **B0** no checks (reference), **F** final validation only, **I** three intermediate checkpoints (CP1-CP3) plus the identical final validation. Evaluation: 500 held-out invoices plus 10 reserve invoices, giving 2,500 faulty and 500 clean cases (3,000 cases, 9,000 runs). Fixed seed 20261029 (provisional).

**Stored result.** Faulty cases reaching commit: F 1,972 of 2,500 (78.88%); I 0 of 2,500. Difference 78.88 points (95% invoice-level bootstrap interval 77.24 to 80.39). False alarms on clean cases: 10 of 500 (2.0%) under both. Cost: I applies 13.07 times as many rule checks per run as F. RQ2 (predictions) was not evaluated.

**What it does and does not show.** The checkpoints were written for these five fault types, so the result shows coverage of a known list in a simulation. It does not show general detection ability, LLM-agent behaviour, or performance in production. No published baseline was reproduced; B0 is an internal reference.

**Evidence status.** The stored result files are internally consistent (re-checked). Who ran the evaluation, when, and with which code version is **not documented in the available files** (original logs, pilot output, a freeze date/hash and the raw-data manifest are missing; the 14-item decisions text has been recovered).
