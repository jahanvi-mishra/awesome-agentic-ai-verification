# Implementation report (Prompt 09)

## Files created (this prompt)
src/g1/: money.py, protocol.py, data_prep.py, split.py, rules.py, pipeline.py, faults.py, oracle.py, runner.py, experiment.py
scripts/: run_experiment.py
configs/: protocol_v1_0.json
tests/: synth.py (helper), test_prep_split.py, test_rules.py, test_faults_pipeline.py, test_oracle_runner.py, test_experiment.py
README.md (rewritten), docs/IMPLEMENTATION_REPORT_PROMPT09.md
## Reused unchanged
src/g1/seeding.py, eligibility.py, dataset_io.py, audit.py; configs/seeds.json; scripts/dataset_audit.py, final_eligibility_audit.py, env_test.py; raw data and manifest (never touched).

## Open points and possible conflicts with the approved protocol (not changed silently)
1. T4 count: with skip-and-log, fewer than 500 T4 cases are run (about 10 skipped if the 16,679/17,023 share holds: 500 x 344/17,023 = 10, an estimate, not a measurement). Prompt 07 said 500 per type. Decide: accept (report the real count) or choose the evaluation set to guarantee 500 T4 cases.
2. T5 can also be skipped when the copied value equals the original (as in Prompt 07).
3. "Keep the first invoice" for duplicates: implemented as first by sorted InvoiceNo text. The decisions do not define "first"; file order could differ.
4. Split rule (one seeded permutation of sorted InvoiceNos), the draw order of faults, and L = 90th percentile with the "higher" method (an observed total, in pence) are my specifications; Prompt 07 only says "seeded" and "90th percentile".
5. Pilot and evaluation both start the fault generator at the fault seed (master + 2); their invoices differ, so draws differ. No new seed was invented.
6. Prompt 07 "v0.2" text was not available to me; faults follow the v0.1 table and the Prompt 09 summary (T1 CustomerID or UnitPrice; T2 malformed Quantity; T3 negative or 10 x Q_max; T4 other line's price; T5 total or CustomerID from another evaluation invoice). If v0.2 differs, tell me where.
7. CP1 has no "at least one line" rule (R1.2 is vacuous for zero lines); RF.5 catches it at the final gate. This is the spec wording.
8. F+ is not implemented (not in the approved conditions). Metrics M1-M11, intervals and tables are not implemented (the scorer is outside Prompt 09's deliverables).
9. Decision 8 (zero-pence lines) cannot occur after the exact 2-decimal rule; the filter is implemented and its count is reported.
10. The real file PROMPT07_FINAL_DECISIONS.txt lives in your Colab; I used the text you gave me.
11. The count gate in `prepare` stops with nothing written if the pool is not 17,023 or T4-capable is not 16,679.

## Test status
See the final chat message for the exact run.

---
# Update v0.5: metrics M1-M11 and T4 sampling

## Changed or added
Added: src/g1/metrics.py, scripts/score_results.py, tests/test_metrics.py.
Modified: src/g1/faults.py (T4 row helper + build_t4_topup), src/g1/split.py (reserve_after_split), src/g1/experiment.py
(build_subset_manifest shared by run and re-run; T4 top-up for the evaluation only; summary counts), src/g1/protocol.py,
configs/protocol_v1_0.json (t4_policy = capable_only), tests/test_experiment.py, tests/test_faults_pipeline.py, tests/test_prep_split.py,
README.md, this report.
Unchanged: data_prep.py, eligibility.py, dataset_io.py, audit.py, seeding.py, pipeline.py, rules.py, oracle.py, runner.py,
scripts/run_experiment.py, configs/seeds.json, raw data and manifest.

## T4 sampling
Existing manifests are byte-identical to before (golden hashes recorded before the change and asserted in tests), so seeds, splits, the
splits.json file and any pilot run stay valid. Evaluation only: for each evaluation invoice that is not T4-capable the T4 row stays a
logged skip, and the same number of extra T4 cases is drawn from T4-capable invoices outside calibration, pilot and evaluation
(taken in the order of the SAME split permutation, no new seed; faults drawn with the same fault generator continuing after the main
manifest). Other fault types are not restricted. Interpretation to confirm: top-up invoices carry one T4 case and no clean case, are not
T5 partners, and count as clusters in the bootstrap.

## Metrics (Prompt 07 Part 6) and decisions made while implementing
- Harmful = oracle label; the same set for F and I. Crashes are neither halted nor committed, so M2 = 1 - M1 holds only without crashes among harmful cases (R8 reports crashes).
- Pooled rates and differences (M1, M1d, M2, M3, M7-M9): invoice-level percentile bootstrap, 2,000 resamples, seed master+4, resampling all invoices that have an injected faulty case. Single proportions (M4, M6): Wilson 95%.
- M3 denominator: injected faulty cases whose B0 label is harmful or benign (crashes and skipped faults excluded). M10: halted harmful+benign cases by first failing checkpoint, F and I. M11: benign / harmful+benign.
- M5 counts rule applications over all runs (clean and faulty); B0 must be 0 (checked in R8).
- R7 lists all missed-by-both cases (a seeded sample of 50, seed master+3, if more); category and note stay blank for human review. R5b classification stays blank.
- R9: RQ1 and RQ3 are computed; RQ2 is computed only if results/predictions.json exists, otherwise it is reported as NOT EVALUATED (no invented predictions).
- F+ columns and Figures 1-3 are not produced (F+ not approved; figures are not CSV).

## v0.6 addendum – validation

Added 16 scale/edge tests and 6 inspector tests (153 tests total, all passing in the build sandbox on synthetic data).
Real pilot outputs were not available in the build sandbox; they must be checked with `scripts/inspect_pilot.py` in Colab.
