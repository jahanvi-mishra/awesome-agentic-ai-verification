# Result-to-source map

All paths are inside `results/stored_evaluation/` (the stored evaluation bundle, unchanged). **Stored** = read from a file produced earlier. **Recomputed** = `python scripts/verify_stored_results.py` rebuilt the number from `runs.jsonl` / `labels.jsonl` on 2026-11-10 and it agreed. Neither means "independently reproduced from the raw dataset": that has not been done (see README, MISSING / NOT VERIFIED).

| Reported result (manuscript) | Value | Source file : column / field | Status |
|---|---|---|---|
| Cases / runs | 3,000 cases; 9,000 condition-runs (B0, F, I) | `runs.jsonl` (one line per run); `summary.json` : `cases_run` | Stored; recomputed |
| Invoices; T4 from reserve | 500 evaluation + 10 reserve = 510 invoices; 10 reserve T4 cases | `summary.json` : `invoices`, `t4_cases_from_reserve`; `metrics/cases_joined.csv` : `source` | Stored; recomputed (`source` counts 2,990 / 10) |
| Labels | 2,500 harmful, 500 reference_match, 0 benign, 0 crashed | `summary.json` : `label_counts`; `labels.jsonl` | Stored; recomputed |
| Manifest hash | `ce58e5613cca7129970f230e2c268634a3890adf6c81016e390f3420fb4ddf50` | `manifest.sha256`; `summary.json` : `manifest_sha256` | Recomputed with `g1.faults.manifest_hash` |
| Runs hash | `5380db45a873c4499f6cd750151f3bb819f699b105857c6f1e0bd81eb6ecd0c5` | `summary.json` : `runs_sha256` | Recomputed (SHA-256 of `runs.jsonl`) |
| **RQ1 / main result:** harmful cases reaching commit | F 1,972 / 2,500 (78.88%); I 0 / 2,500 | `metrics/R1_primary.csv` : `reached_commit_n`, `M1_rate` | Counts recomputed |
| Difference F minus I and its 95% interval | 78.88 points (77.24 to 80.39) | `metrics/R1_primary.csv` row "F minus I", `ci_low`, `ci_high` | **Stored only** (bootstrap, 2,000 resamples, seed 20261033, not recomputed here) |
| Per-type reach-commit under F | T1 249/500 (49.8%), T2 490/500 (98.0%), T3 257/500 (51.4%), T4 488/500 (97.6%), T5 488/500 (97.6%); I = 0 for all | `metrics/R2_per_type.csv` : `F_reached_n`, `I_reached_n`; Wilson intervals in `metrics/metrics_summary.csv` | Counts recomputed; intervals stored |
| Which checkpoint halted what | T1-T3 -> CP1; T4 -> CP2; T5 -> CP3 (500 each) | `metrics/R4_halting_attribution.csv`; rule detail `metrics/R4b_halting_by_rule.csv` | Stored |
| Overlap F vs I | F halted 528 harmful, all also halted by I; 1,972 reached commit under F and were halted by I; no case caught only by F | `metrics/R3_outcome_overlap.csv` | Stored |
| Clean false alarms | F 10/500 (2.0%); I 10/500 (2.0%) | `metrics/R5_clean_false_alarms.csv`; list in `metrics/R5b_false_alarm_cases.csv` | Counts recomputed |
| Cost in rule applications | B0 0; F 16,390 (5.46 per run); I 214,231 (71.41 per run); ratio 13.07 | `metrics/R6_cost.csv` | Recomputed |
| Missed by both | 0 cases | `metrics/R7_missed_by_both_review.csv` (header only) | Stored |
| Decision rules | RQ1 met; RQ3 met (FPR(I) 0.02 <= 0.02 and <= FPR(F) + 2 points); **RQ2 NOT EVALUATED** (no `predictions.json`) | `metrics/R9_decision_rules.csv` | Stored |
| 302 of 2,490 harmful cases (with a clean counterpart) changed POST/HOLD (T1 2, T2 9, T3 234, T4 17, T5 40) | as stated | derived from `runs.jsonl` B0 commit records (checked during this assembly) | Recomputed ad hoc, no script kept |
| 9 of the 10 reserve T4 cases reached commit under F | 9 | `metrics/cases_joined.csv` (`source = t4_reserve`, `out_F`) | Recomputed ad hoc |
| Calibration constants (Q_max 2400, P_max 394932, T_max 1195610, L 81216), eligibility counts 17,023 / 16,679, seeds | as in manuscript Section 5 | **No stored constants file**; seeds in `configs/seeds.json`; counts in `PROMPT07_FINAL_DECISIONS.txt` items 1 and 11 and `configs/protocol_v1_0.json` | Partly VERIFIED (see `baseline_validation.md` check 11); constants file UNKNOWN |
| Figures 1-3 of the paper | Figure 1 is conceptual; Figure 2 is a conceptual diagram of the checkpoint responsibilities (no results); Figure 3 plots per-type reach-commit (same values as Table 5) | `paper/figures/*.png`; data `results/stored_evaluation/metrics/R2_per_type.csv` | Figure 3 not re-drawn here; Figure 2 is redrawn by `paper/supplementary/figure_data/make_checkpoint_figure.py` (no data) |
| Result figures (five PNG) | regenerated into scratch space with `paper/supplementary/figure_data/make_figures_rev5.py` | `results/stored_figures/*.png`; `paper/supplementary/figure_data/figure_source_values.csv` | The regenerated `figure_source_values.csv` is byte-identical to the stored one; PNGs not compared pixel by pixel |
