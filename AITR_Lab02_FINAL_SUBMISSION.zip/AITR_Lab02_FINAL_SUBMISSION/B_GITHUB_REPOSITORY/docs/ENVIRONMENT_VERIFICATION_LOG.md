# Environment verification log

**Status: env_test.py v0.1 run once on Colab CPU (2026-10-31 18:29 UTC): OVERALL WARN, 13 PASS, 1 WARN, 0 FAIL.** The WARN is the expected Drive-persistence warning. Scope: that one runtime on that day only.

## 1. Requirements extracted from Prompt 07 (v0.1, provisional; items marked APPROVE are not frozen)
| # | Requirement | Source | Environment implication |
|---|---|---|---|
| R1 | Deterministic four-stage pipeline S1-S4 with simulated ledger commit | P07 flowchart | plain Python, no external services |
| R2 | Conditions B0, F, I (CP1-CP3 + identical final validation); F+ optional | P07 | one code path with switches |
| R3 | Dataset UCI Online Retail id 352; case = invoice; split by InvoiceNo | P06/P07 | pandas, openpyxl for .xlsx |
| R4 | Master seed 20261029; sub-seeds +1 split, +2 faults, +3 missed-case review, +4 bootstrap (APPROVE) | P07 Part 5 | seeding.py, configs/seeds.json |
| R5 | Calibration 1,000 / pilot 50 / evaluation 500 invoices (APPROVE) | P07 | memory: invoice table small, fits Colab |
| R6 | 500 clean + 2,500 faulty cases = 3,000; 9,000 runs (12,000 with F+) | P07 | runtime small on CPU (UNKNOWN until measured) |
| R7 | Metrics M1-M11, Wilson intervals, invoice-level cluster bootstrap (2,000 resamples) | P07 | NumPy only |
| R8 | Results tables R1-R9 and Figures 1-3 | P07 | matplotlib, CSV outputs |
| R9 | Fresh ledger per run; no repair/retry/rollback; no tuning after results | P07 | no hidden state between runs |
| R10 | Laptop-feasible, no code claims of results | P07 | CPU only |

Source note: extracted from the Prompt 07 content as carried in this conversation; re-check against your saved Prompt 07 document.

## 2. Proposed environment (untested)
Python: Colab default, need >= 3.10. Packages: see DEPENDENCIES.md. Interpreter and package versions on your runtime are UNKNOWN until Section 3.

## 3. Genuine Colab run record (from user-supplied console output)
| Field | Value |
|---|---|
| Date/time (UTC) | 2026-10-31 18:29:12 |
| Colab runtime | CPU, 2 vCPU, 12.67 GB RAM, 87.1 GB disk free; release tag release-colab-external-images_20261029-060149_RC00 |
| OS / machine | Linux 6.6.159+ x86_64, glibc 2.39 |
| Python version | 3.13.18 (/usr/bin/python3) |
| numpy / pandas / matplotlib / openpyxl / pytest | 2.1.3 / 2.2.3 / 3.10.0 / 3.1.5 / 8.4.2 |
| Versions before and after `pip install -r requirements.txt` | identical (pip changed nothing; Colab's preinstalled versions already met the minimums) |
| Overall | WARN (PASS=13, WARN=1, FAIL=0) |
| WARN | drive_persistence: project in /content, not on Drive. Accepted for this check; copy logs and results out, or mount Drive, before real experiments |
| Evidence files (in Colab logs/) | env_check_20261031T182913Z.txt, .json, pip_freeze_20261031T182913Z.txt |
| PYTHONHASHSEED | not set (code must not depend on set/dict-of-set order) |

Not yet done: pip_freeze content was not shared, so requirements-lock.txt does not exist yet. Only one run exists, so run-to-run repeatability of the environment is not shown.

## 4. Script validation outside Colab
The script was run once in the assistant's own Linux container (Python 3.13, 2 CPUs, no Colab) to catch script bugs; one bug (unit-test discovery) was found and fixed.
This is NOT evidence about your Colab runtime.

## 5. Open items
Dataset file not yet downloaded or audited. Whether pandas 3.x behaves identically for later code (unit tests will decide).
