# Recorded dataset and run hashes (preserved verbatim; evidence, never overwritten)

**Source:** the author's own prompt texts supplied in the workspace. They are *recorded values*, not hashes computed from files in this repository. No raw data file, ZIP, base-lines file or splits file is available here, so none of these can be re-verified until Colab `download` and `prepare` are run.

| Item | Recorded value | Where recorded |
|---|---|---|
| Raw XLSX sha256 | `43465a06f2ccf7c8b5bd2892bc7defb52f97487934fe93b16ae4c3936424676d` | `d6a73839-attachment.txt` (author's Prompt 12), line 49 |
| ZIP sha256 | `f5385cbb54bbebf7196389109c6b0621faab0c304e3702548165e71c84aede8b` | same, line 50 |
| Base lines sha256 | `67f95be82e13cfc3a68c6194aa76031c4349e2e018ccfc75941d107aa7764a9c` | same, line 51 |
| Split sha256 | `c6bfe38c80b3af0b98d93e1c4f88c6f1e5f70b7c2d885207f630bb59f77d6e39` | same, line 52 |
| Evaluation manifest sha256 | `ce58e5613cca7129970f230e2c268634a3890adf6c81016e390f3420fb4ddf50` | author's Prompts 12/13; **also recomputed from** `results/stored_evaluation/` |
| Evaluation runs sha256 | `5380db45a873c4499f6cd750151f3bb819f699b105857c6f1e0bd81eb6ecd0c5` | same; also recomputed |
| Constants | Q_max 2400, P_max 394932 pence, T_max 1195610 pence, L 81216 pence (GBP 812.16, 90th percentile, method `higher`) | author's Prompts 09, 12, 15 |
| Raw table shape | 541,909 x 8 | author's Prompts 09, 12, 15 |
| Protocol file `PROMPT07_FINAL_DECISIONS.txt` sha256 | `abbe90370a074224c0bfc389c25f9c76c2a2dd568c9561a1194f2a207d931542` | recomputed 2026-11-10; prefix `abbe9037` matches `ai_assistance_log.md` row A2 | **recomputed** |
| v0.6 code ZIP / evaluation bundle ZIP sha256 | `cf6ed9b9b9ebc2558a9bc0d3664c57b824b00862dc941f02b01c1d0d07b69ac4` / `f9ec2d63023310b61353b5c36dee7a7e4df6c65751514b86b572d33aa49bcbdf` | computed on the supplied files | **recomputed** |

**Label mapping is INFERRED:** "Base lines" is assumed to be the SHA-256 of `data/interim/base_lines.csv` (`data_prep.write_base_lines`) and "Split" the value printed by `prepare` as `split_sha256` (`split.split_hash`), because the names match the outputs of those functions.

**Correction of an earlier statement.** `docs/PROTOCOL_IMPLEMENTATION_CHECK.md` (v2) said no stored hash of the original data file exists. That was wrong; the hashes above are recorded in the author's prompts. The original sentence is kept, struck through, in that file.
