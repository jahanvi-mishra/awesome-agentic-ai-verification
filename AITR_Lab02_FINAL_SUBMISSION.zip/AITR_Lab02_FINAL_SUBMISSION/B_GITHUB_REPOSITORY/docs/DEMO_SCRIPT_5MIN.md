# Five-minute demonstration script

Everything marked **[TESTED]** was run during assembly. Anything marked **[NOT TESTED]** must not be run live unless you have the missing inputs; say plainly that it is not verified.
Open a terminal in the repository folder first.

**0:00-0:45 The idea.** "Automated workflows can pass a wrong value from one stage to the next without any error. My study asks whether small deterministic checks *between* stages, on top of a final check, stop more harmful faults. It is a controlled Python simulation of an invoice pipeline, not an LLM agent." Show `README.md` (What this is / is not) and `docs/research_brief_one_page.md`.

**0:45-1:45 The pipeline and conditions.** Open `src/g1/pipeline.py` (`run_pipeline`) and `src/g1/rules.py`. Say: four stages S1-S4; B0 no checks; F final validation only; I = CP1, CP2, CP3 plus the same final validation; the run halts at the first failed rule; no repair. Show the five faults T1-T5 in `src/g1/faults.py` or in the brief. Main entry point: `scripts/run_experiment.py`.

**1:45-2:30 The code is tested. [TESTED]**
```
python -m unittest discover -s tests          # expect: Ran 153 tests ... OK
```
Say: "These use synthetic data. They show the code works, not that the experiment succeeded."

**2:30-3:45 The stored results are consistent. [TESTED]**
```
python scripts/verify_stored_results.py       # expect: every line PASS, then ALL CHECKS PASSED
```
Then open `results/stored_evaluation/metrics/R1_primary.csv` and `R5_clean_false_alarms.csv`, `R6_cost.csv`. Say: "F let 1,972 of 2,500 harmful cases reach commit, I let 0; both raise the same 10 false alarms on 500 clean cases; I does 13.07 times more rule checks." Show `results/stored_figures/fig1_primary_result.png`.

Optional, same minute **[TESTED]**: `python scripts/check_paper_vs_csv.py` (expect `61 checks, 0 failures`): every number in the paper's tables and results text equals the stored metrics CSVs. Say: "This shows the paper matches the stored files, not that the experiment was reproduced."

**3:45-4:30 Honesty slide.** Open `README.md` -> "Evidence status" and "MISSING / NOT VERIFIED". Say: "By my own account these are the outputs of my Colab run, but I have no log of it. The original logs, pilot output, raw-data manifest and freeze record are not in this package, so I report them as stored results, not as reproduced. The 14-item protocol text was recovered from my records and checked against the code. The tests check the code on synthetic data, and the consistency script checks the stored files against each other." Mention RQ2 was not evaluated.

**4:30-5:00 Reproduction path and limits.** "Full reproduction is `prepare`, `pilot`, `evaluate --confirm-freeze`, `score_results` from `README.md` **[NOT TESTED here]**; it needs the raw UCI data (my recovered decisions file `PROMPT07_FINAL_DECISIONS.txt` is in the repository root). Limits: coverage of a known fault list in a simulation, not generalisation; shared author and AI-assistance risk; AI use is logged in `ai_assistance_log.md`."

Optional backup if a command fails: show the saved terminal output, or open `docs/RESULT_TO_SOURCE_MAP.md` and walk one row from paper number to CSV.
