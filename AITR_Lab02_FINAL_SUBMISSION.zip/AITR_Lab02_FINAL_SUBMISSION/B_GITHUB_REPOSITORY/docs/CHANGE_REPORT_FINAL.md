# Change report: final package (13 November 2026)

V3, V4 and V5 packages are unchanged. v0.6 source (`src/`, `configs/`, `tests/`), seeds, stored results and `PROMPT07_FINAL_DECISIONS.txt` are byte-identical to V5 (hash-checked). No Colab run, pilot, evaluation or prediction was performed; the decision record is unsigned.

## Paper (Rev 5.2.2, final)
- Body exactly 10 pages excluding references (13 pages in total), same ACM acmsmall template, fonts and margins. No instructor-specified template was found in the project or the handout ("use instructor-selected template if specified"; Prompt 15 says "IEEE/ACM-style").
- Restored: fuller Related Work (with the search caveat and "does not establish a research gap"), per-type reach-commit figure (Figure 3, Section 6.2), false-alarm detail, run-level classification values, cost split.
- Added: conceptual Figure 2 (checkpoint responsibilities; no results; from the Revision 5 package, redrawn by `paper/supplementary/figure_data/make_checkpoint_figure.py`); abstract clause that the results are stored evaluation results not independently reproduced.
- Preserved: corrected Sections 9 and 10; Section 5.5 now says neither the 57-check audit script nor its output is in the project files.
- Numbers: `scripts/check_paper_vs_csv.py` checks 61 values against `results/stored_evaluation/metrics/*.csv`; 0 failures.
- Supplement regenerated: S1 methodology detail, S2 extended discussion (the related work and results detail now live in the main paper).

## Repository documentation
- `baseline_validation.md` and `README.md`: the files `audit_evaluation.py`, `eval_audit/audit_checks.csv` and `change_summary_rev5.md` were searched for in every supplied file and are not present; they are reported as not available and not recreated. The inspectable checks are listed (19 PASS stored-file checks, 61 paper-vs-CSV checks, 3,256 H3 replay matches, 153 sandbox tests).
- `.gitignore` and the GitHub readiness section added to `README.md`; notebook/plan/START_HERE refer to `AITR_Lab02_Project_FINAL.zip`; AI log row A24 added (draft); file inventory, matrix and source map updated; manifest `docs/FILE_MANIFEST_FINAL.sha256` regenerated last.

## Still missing (not recreated)
Original Colab logs for prepare/pilot/evaluate/verify-rerun/score; pilot output; calibration-constants file; eligibility report; audit script and `eval_audit/audit_checks.csv`; Prompt 07 v0.1/v0.2 texts; raw-data manifest and retrieval date; protocol freeze record.
