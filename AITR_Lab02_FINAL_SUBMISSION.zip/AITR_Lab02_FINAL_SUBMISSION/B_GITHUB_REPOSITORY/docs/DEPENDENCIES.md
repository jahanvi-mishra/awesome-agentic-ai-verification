# Dependency list (proposed, UNTESTED until your Colab output)

| Package | Minimum | Why it is needed | Why not something else |
|---|---|---|---|
| Python | 3.10 (script FAILs below; WARNs at 3.14+) | language | Use Colab's default; do not pin an interpreter |
| numpy | 1.26 | arrays, seeded `Generator`, percentile, Wilson/bootstrap maths | needed by pandas anyway |
| pandas | 2.1 | read data, invoice-level tables, groupby, split by InvoiceNo | the data is tabular |
| matplotlib | 3.8 | figures 1-3 and result plots | standard, no extra plotting stack |
| openpyxl | 3.1 | pandas needs it to read the UCI `.xlsx` | only way to read xlsx in pandas |
| pytest | 8.0 | Colab usually has it; tests themselves use stdlib `unittest` | optional runner; not required by tests |

Deliberately NOT included: scipy (Wilson interval and bootstrap are a few lines of NumPy), scikit-learn (nothing is trained),
PyYAML (configs are JSON), ucimlrepo (optional; manual download is simpler to audit), any agent framework (the pipeline is plain Python).

## How compatibility is checked (not assumed)
1. `scripts/env_test.py` reads requirements.txt and compares installed versions (FAIL if missing/below minimum).
2. It WARNs when a package has a newer major version than the project was written against (numpy>=3, pandas>=3, matplotlib>=4).
3. It then runs real operations (seeded RNG, invoice arithmetic, NaN coercion, xlsx round-trip, PNG save, unit tests).
4. A PASS means "these operations worked in that runtime on that day". It does not prove future compatibility.
5. After your first PASS/WARN run, copy `logs/pip_freeze_*.txt` to `requirements-lock.txt`; that is the reproducible record.

Why ">=" and not "==": Colab ships its own versions. ">=" lets pip leave them alone; "==" could force a downgrade and break numpy/pandas binaries.
