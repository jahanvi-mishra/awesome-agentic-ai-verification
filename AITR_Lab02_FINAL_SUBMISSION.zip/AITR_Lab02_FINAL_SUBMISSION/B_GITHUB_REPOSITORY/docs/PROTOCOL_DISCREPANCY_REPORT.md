# Protocol discrepancy report for author approval

**Project:** Designing Verification Checkpoints to Mitigate Silent Errors in Agentic AI Pipelines (code v0.6, protocol decisions file `PROMPT07_FINAL_DECISIONS.txt`, recovered 2026-11-10)
**Prepared:** 2026-11-10. **Purpose:** list every place where the v0.6 code goes beyond, or interprets, the 14 recovered decisions, so that the author can approve or reject each one **before** any experiment is run.
**Not done:** no code, configuration, stored result, seed or manuscript number was changed; no experiment was run. Nothing below is treated as approved. No historical approval is claimed.

Evidence labels: **VERIFIED** = read in a file; **INFERRED** = reasoned, not shown in a file; **UNKNOWN** = no evidence supplied. Paths are relative to the repository root `AITR_Lab02_Project/`; "author prompts" are the prompt texts you supplied in this workspace.

## 0. One-page summary

| # | Issue | What Prompt 07 v1.0 says | What the code does | Evidence for the choice | Author decision needed |
|---|---|---|---|---|---|
| 1 | Item 3, "keep the first" | "keep the first invoice" | first = lowest InvoiceNo (sorted text) | flagged by the AI as open at build time; no approval found | Approve lowest-InvoiceNo, or state another meaning |
| 2 | Item 5, "exact two-decimal" | "Require exact two-decimal prices" | at most two decimals (2.5 and 5 pass) | consistent wording elsewhere; no stated definition | Approve "at most two decimals" or state another meaning |
| 3 | Extra rules | not stated (item 1 gives only the count 17,023) | not cancelled; every line valid; at least 2 lines | code comment attributes them to Prompt 07 v0.1 steps 1-3 (text unavailable) | Confirm they were part of Scenario D, or approve them as added rules |
| 4 | T4 reserve top-up | T4 only from invoices with >= 2 prices; 500 evaluation invoices | 10 extra T4 cases from 10 reserve invoices | author prompts call it "authorised reserve"; no dated approval | Approve it as part of the protocol, or do not run under v0.6 |
| 5 | Prompt 07 v0.2 text | "T1-T5 as specified in Prompt 07 v0.2" | code follows v0.1 table + Prompt 09 summary | the AI said so at build time | Accept code definitions as operative, or supply v0.2 |
| 6 | Freeze record | (none) | seeds "PROVISIONAL"; no freeze hash/date | author prompts call the run "frozen" | Approve a dated, retrospective approval record |

## 1. Item 3: "keep the first invoice" read as lowest InvoiceNo

1. **Existing code.**
   - `src/g1/eligibility.py:143-153` `keep_first_ids`: iterates `for inv in sorted(ids)` and keeps an invoice only if its signature has not been seen. `sorted` is Python text sorting of the InvoiceNo strings.
   - Called with `kind="full"` at `src/g1/data_prep.py:50-52`.
   - Signature: `eligibility.py:113-131`, `full_sig = (CustomerID, Country, sorted tuple of (StockCode, Quantity, UnitPrice in pence))`; InvoiceNo, InvoiceDate and Description are excluded (`eligibility.py:116-119`).
2. **Prompt 07 v1.0 says (item 3).** "Remove using the full signature (CustomerID, Country, sorted line contents); keep the first invoice." It does not define "first", nor what "line contents" are.
3. **Why it is an interpretation.** "First" could mean (a) lowest InvoiceNo, (b) earliest InvoiceDate, or (c) first row in the raw file. "Line contents" could include or exclude StockCode. The code picks (a) and StockCode + Quantity + pence. The choice changes **which** invoice of a duplicate group stays in the pool, not how many (so the 17,023 count gate cannot detect it) and, through the split permutation, which invoices land in each subset. For six-digit InvoiceNo of equal length, text order equals numeric order (VERIFIED by reasoning). Whether (a) equals (b) or (c) on the real file is UNKNOWN; the file is usually chronological, which makes them often coincide (INFERRED from general knowledge of the data set, not checked here).
4. **Evidence.**
   - Prompt 09 (`99b42aa3-attachment.txt`, section 1): "keep the first" (no definition).
   - `docs/IMPLEMENTATION_REPORT_PROMPT09.md`, open point 3: the AI wrote "implemented as first by sorted InvoiceNo text. The decisions do not define 'first'; file order could differ." So the ambiguity was flagged at build time. No reply or approval of that point is in any supplied file (UNKNOWN).
   - Manuscript (Section 5): "the first kept"; no definition.
   - Tests: `tests/test_eligibility.py:87-97` check the duplicate counts ("keep first") on a small table; they do not test the definition of "first".
5. **Decision.** State which meaning of "first" you approve: (a) lowest InvoiceNo (current code), or (b)/(c) another. Option (b)/(c) would need a code change, which is outside this task; if you want it, the experiment cannot be run as v0.6.
   *Empirical check available before any fault is injected:* `prepare` writes `data/interim/base_lines.csv` and reports its SHA-256. Your Prompt 12 text records a "Base lines" hash `67f95be82e13cfc3a68c6194aa76031c4349e2e018ccfc75941d107aa7764a9c` (`d6a73839-attachment.txt:51`). If `prepare` reproduces it from the raw file, items 1-9 and the extra rules (issue 3) produced the same pool as in the original run; this supports the current reading as what was *used*, not as what was *intended* (the label-to-hash mapping is INFERRED from the names).

## 2. Item 5: "exact two-decimal prices" read as at most two decimals

1. **Existing code.**
   - `src/g1/eligibility.py:32-36` `price_info`: `d = Decimal(repr(float(x)))`; `decimals = max(0, -d.normalize().as_tuple().exponent)`.
   - `eligibility.py:81`: `r["price_2dp"] = r["dec"].le(2)`; used in `:106` (`type_strict`) and `src/g1/data_prep.py:47`.
   - `src/g1/money.py:15-21` `price_to_pence`: raises `ValueError` unless `d * 100` is a whole number (at most two decimals).
   - `tests/test_eligibility.py:55-56` `test_integer_price`: 5.0 has 0 decimals and is accepted.
2. **Prompt 07 v1.0 says (item 5).** "UnitPrice: Require exact two-decimal prices."
3. **Why it is an interpretation.** Read literally, "exactly two decimals" could exclude 2.5 or 5. The code treats "exact two-decimal" as "exactly representable in two decimals". In a numeric Excel column 2.5 and 2.50 are the same value, so a literal reading cannot be applied to the data (INFERRED; the xlsx cell type was not inspected). Pence conversion for prices with more than two decimals uses half-up rounding that the code itself calls "a proposal; the rounding rule needs your approval" (`eligibility.py:11-12`); this does not affect the eligible pool, because such prices are already excluded by the same filter (VERIFIED by reading `data_prep.py:47-48`).
4. **Evidence.** Prompt 09 section 1 repeats "exact two-decimal UnitPrice". Manuscript Section 5: "price exact to two decimals". `docs/IMPLEMENTATION_REPORT_PROMPT09.md` open point 9 notes that zero-pence lines cannot occur after this rule. No definition or approval of "exact" in any file (UNKNOWN).
5. **Decision.** Approve "at most two decimal places (2.5 and 5 count as exact)", or state another meaning. The same Base-lines hash comparison (issue 1) tests whether the original pool was built this way.

## 3. Additional rules: not cancelled, all lines valid, at least two lines

1. **Existing code.**
   - `eligibility.py:70`: `cancelled` = InvoiceNo starts with "C" or "c".
   - `eligibility.py:75-78`: `row_valid` = InvoiceNo, StockCode, Country, CustomerID, Quantity, UnitPrice all present, and Quantity > 0, UnitPrice > 0.
   - `eligibility.py:104-105`: `all_valid = n_valid == n_lines` (every line of the invoice); `s1 = not cancelled and all_valid and n_lines >= 2`.
   - Applied first in `src/g1/data_prep.py:44-47`; docstring at `data_prep.py:3-5`.
2. **Prompt 07 v1.0 says.** Item 1: "Eligible pool: Scenario D - 17,023 invoices." Items 2-9 add six-digit numbers, no duplicates, single date, two-decimal prices, five-digit CustomerID, integer Quantity, no zero-pence lines. **None of the 14 items mentions cancellation, per-line validity (Quantity > 0, UnitPrice > 0, fields present) or a minimum of two lines.** Item 1 does not define "Scenario D".
3. **Why it may be an additional rule.** Cancellation and validity are plausible parts of "Scenario D" (the six-digit rule already removes most "C..." numbers). The two-line condition is the least certain: it removes single-line invoices, and it is the one the manuscript already flags.
4. **Evidence.**
   - Code comment, `eligibility.py:3` and `:10`: S1 is the "rule set from Prompt 07, steps 1-3 ... not cancelled, EVERY line of the invoice is valid, >= 2 lines", following "Prompt 07 v0.1 (Part 2)". This is an AI-written comment in an earlier session; **Prompt 07 v0.1 itself is not in the supplied files**, so it cannot be checked (UNKNOWN).
   - Manuscript Section 5 states that the two-line condition "is not in the decisions record and has not been checked against the executed copy of the code". With the decisions file now recovered, the first half of that sentence is confirmed (VERIFIED); the second half stands.
   - Author prompt 15 (`a14a3bc6-attachment.txt:180`): "the two-line eligibility requirement" was "inferred rather than directly verified".
   - The count 17,023 was said to come from the author's eligibility audit; its rule set is not recorded (UNKNOWN). The `prepare` count gate (`experiment.py:40-43`) is the only empirical test: if the code's rule set yields exactly 17,023 and 16,679, it is consistent with the original; a mismatch stops the run.
5. **Decision.** Either confirm these three conditions were part of Scenario D in Prompt 07 v0.1/the eligibility audit (if you have that text, supply it), or approve them explicitly as additional rules. If `prepare` does not give 17,023 / 16,679, the run must stop; changing the rules is then a protocol change that needs a new version.

## 4. T4 reserve top-up (10 extra T4 cases)

*Clarification of the issue:* the 10 evaluation invoices are **not replaced**. They stay in the evaluation set and receive clean, T1, T2, T3 and T5 cases; only their T4 attempt is logged as skipped. Ten **additional** T4 cases are drawn from ten T4-capable reserve invoices outside every subset (manuscript Section 5; `summary.json`: `t4_cases_injected` 500, `t4_cases_from_reserve` 10).

1. **Existing code.**
   - `src/g1/faults.py:64-84` `build_t4_topup`: walks the reserve in order, skips invoices with fewer than two distinct prices, takes capable ones until the shortfall is filled, using the same fault generator (2 draws each); rows carry `source='t4_reserve'`.
   - `src/g1/split.py:43-52` `reserve_after_split`: the unassigned invoices in the order of the same single permutation (no new seed).
   - `src/g1/experiment.py:78-82`: builds the top-up for the evaluation only; the pilot only skips.
   - `configs/protocol_v1_0.json`: `"t4_policy": "capable_only"` and a note describing the top-up; `src/g1/protocol.py` allows only this policy; `tests/test_experiment.py:136-138` asserts it. The earlier policy (skip and log, 490 T4 cases) **no longer exists** in v0.6.
2. **Prompt 07 v1.0 says.** Item 11: "Select T4 fault cases only from invoices with at least two distinct unit prices. Scenario D has 16,679 T4-capable invoices." Item 12: "1,000 calibration + 50 pilot + 500 evaluation invoices." Nothing about reserve invoices, replacement, or a count of 500 T4 cases.
3. **Why it is an addition.** The text can be met by skipping (490 T4 cases) or by topping up (500). The top-up goes beyond the 14 items: it adds 10 invoices (510 clusters), those 10 cases have no clean counterpart, and the T4 count becomes 500. `docs/IMPLEMENTATION_REPORT_PROMPT09.md` open point 1 recorded that "Prompt 07 said 500 per type" and asked the author to "accept (report the real count) or choose the evaluation set to guarantee 500 T4 cases"; the v0.5 note lists "Interpretation to confirm: top-up invoices carry one T4 case and no clean case, are not T5 partners, and count as clusters in the bootstrap."
4. **Evidence.** Author prompts 12, 13 and 15 describe the 10 cases as "supplied by an authorised reserve" / "10 reserve invoices added for T4 fault top-up" (`d6a73839-attachment.txt:46,60`; `8f5b22bd-attachment.txt:30`; `a14a3bc6-attachment.txt:149`). That is the author's wording in later prompts, **not a dated approval of the design change**; `ai_assistance_log.md` row A5 says that approval "should be confirmed" (UNKNOWN). The manuscript reports the top-up openly (Section 5, limitation 9).
5. **Decision.** Approve the top-up as part of the protocol for this run (with its consequences: 500 T4 cases, 510 clusters, 10 cases without a clean counterpart), **or** decline. Declining means v0.6 cannot be run as is (the skip-only policy was removed), so the full run would not be possible without a code change, which this task excludes.

## 5. Missing Prompt 07 v0.2 fault definitions (item 13)

1. **Existing code.** `src/g1/faults.py:1-17` (docstring) and `:87-138` `build_manifest`: T1 removes CustomerID (even first draw) or one line's UnitPrice, after S1; T2 turns one Quantity into its digits + " pcs", after S1; T3 makes one Quantity negative or 10 x Q_max, after S1; T4 gives one line amount another line's different price, after S2 (skipped if all prices equal); T5 copies invoice_total or CustomerID from another invoice of the same subset, after S3 (skipped if equal). Draw counts T1 2, T2 1, T3 2, T4 2, T5 2 (`faults.py:35`).
2. **Prompt 07 v1.0 says (item 13).** "Fault types: T1-T5 as specified in Prompt 07 v0.2." The file contains no definitions.
3. **Why it is uncertain.** The text of v0.2 is not available, so no one can check the code against it. Specific details that may be requirements or implementation choices: the string form in T2; the 50/50 variant choice in T1, T3, T5; uniform line and partner selection; the injection stage per type; the skip rules; the draw order.
4. **Evidence.**
   - Author prompt 09 (`99b42aa3-attachment.txt`, section 4) gives one-line summaries and says "exactly according to the approved Prompt 07 v0.2 specification". The same one-liners appear in author prompts 12 and 15.
   - `docs/IMPLEMENTATION_REPORT_PROMPT09.md` open point 6: "Prompt 07 'v0.2' text was not available to me; faults follow the v0.1 table and the Prompt 09 summary ... If v0.2 differs, tell me where." No reply is in the supplied files (UNKNOWN).
   - The manuscript Section 5 table agrees with the code. The code, the Prompt 09 summaries and the manuscript agree with one another; none of them is the v0.2 source. Tests: `tests/test_faults_pipeline.py` (T1-T5).
5. **Decision.** Either (a) supply Prompt 07 v0.2 so it can be compared line by line (any difference then needs your ruling; the code stays unchanged), or (b) declare the code definitions, as summarised in the manuscript, to be the operative definitions for this run and state that v0.2 could not be recovered.

## 6. Missing formal freeze record

1. **Existing code and configuration.**
   - `configs/seeds.json:2`: `"status": "PROVISIONAL - master seed is an APPROVE item in Prompt 07 (v0.1), not frozen"`.
   - `configs/protocol_v1_0.json:3`: source "PROMPT07_FINAL_DECISIONS.txt ... and Prompt 07 v0.1 text"; no hash or date.
   - `scripts/run_experiment.py:46-49`: only tests that `PROMPT07_FINAL_DECISIONS.txt` exists; contents never read.
   - `src/g1/experiment.py:94`: run-once guard; the manifest is hashed and written before any run (`manifest.sha256`).
   These make a run *internally* once-only; they are not a record of when the protocol was fixed.
2. **Prompt 07 v1.0 says.** Nothing about freezing; the file has no date, signature or hash.
3. **Why it matters.** Without a dated record the study cannot be called "pre-specified" or "frozen" in the strict sense, and the seed (20261029) has no approval record. The manuscript already avoids those claims (limitation 13).
4. **Evidence that exists (partial, all in author prompts or reports, none a formal record).**
   - Decisions text (recovered; sha256 `abbe9037...`).
   - Author prompts 12/13 calling the run "frozen" and giving hashes: raw XLSX `43465a06f2ccf7c8b5bd2892bc7defb52f97487934fe93b16ae4c3936424676d`, ZIP `f5385cbb54bbebf7196389109c6b0621faab0c304e3702548165e71c84aede8b`, base lines `67f95be8...`, split `c6bfe38c...`, constants (Q_max 2400, P_max 394932, T_max 1195610, L 81216 pence), manifest `ce58e561...`, runs `5380db45...` (`d6a73839-attachment.txt`, `8f5b22bd-attachment.txt`).
   - AI log row A2: the decisions file was "created and backed up" (no date).
   These hashes give you a **checkable reference** for a re-run (they are not a record of approval).
5. **Decision.** Approve writing a **new, dated, retrospective** approval record (template in section 8) that lists the 14 decisions, the interpretations you accept, the seed, and the hashes above, clearly stating it is signed on the date of signing and does not claim an earlier freeze. Do not back-date it.

## 7. Related items found while checking (not in your list; also author specifications)

Per `docs/IMPLEMENTATION_REPORT_PROMPT09.md` open point 4 and the v0.5 notes, these were specified by the implementer, not by the 14 items: the split mechanism (one seeded permutation of sorted InvoiceNos, `split.py:3`); the fault draw order and the use of the fault seed for both pilot and evaluation; L = 90th percentile with method "higher" (`configs/protocol_v1_0.json` marks it OPEN); CP1 has no "at least one line" rule (RF.5 catches it); half-up pence rounding; the oracle docstring "independent" versus the manuscript's "reference module". They can be approved together with issue 6.

## 8. Corrections to earlier statements of mine

- `docs/PROTOCOL_IMPLEMENTATION_CHECK.md` (in `AITR_Lab02_Project_v2.zip`), blocker 1, says no stored hash of the original data file exists. That is **wrong**: your Prompt 12 text records the raw XLSX, ZIP, base-lines and split hashes (`d6a73839-attachment.txt:49-52`). Those hashes can be compared with the Colab download and the `prepare` output. The v2 ZIP has not been changed; this correction belongs in the next build.
- My description of the T4 issue as "replacing 10 evaluation invoices" (in your request) is corrected in section 4: the evaluation invoices are kept; 10 extra reserve invoices are added.

## 9. Minimum decisions to approve before a valid full run

Tick one option per line. Leaving a line blank means "not approved" and the run should not start.

| # | Decision | Options |
|---|---|---|
| A | "First invoice" = lowest InvoiceNo (item 3) | [ ] approve  [ ] reject (code change needed: do not run v0.6) |
| B | "Exact two-decimal" = at most two decimals (item 5) | [ ] approve  [ ] reject (code change needed) |
| C | Extra rules (not cancelled, all lines valid, at least two lines) belong to / are approved for the pool | [ ] approve  [ ] reject (code change needed) |
| D | T4 reserve top-up is part of the protocol (500 T4 cases, 510 clusters) | [ ] approve  [ ] reject (v0.6 cannot run) |
| E | T1-T5 operative definitions are the code/manuscript ones because v0.2 is unavailable | [ ] approve  [ ] I will supply v0.2 first |
| F | This run is a **re-execution under a retrospective, dated approval record**, with seeds recorded as PROVISIONAL, not a pre-registered freeze | [ ] approve wording  [ ] other: ______ |
| G | If any hash differs from the stored/recorded hashes, I report both sets and never overwrite the stored results; if `prepare` does not give 17,023 / 16,679, I stop | [ ] approve |
| H | Items in section 7 (split mechanism, draw order, "higher" percentile, etc.) are accepted as implemented | [ ] approve  [ ] review first |

**Recommended order once A-H are decided (no experiment yet):** run only `prepare` in a fresh Colab copy, then compare the raw XLSX, ZIP, base-lines and split hashes and the constants with the values above. That single step tests decisions A, B, C and H against your own recorded hashes before any fault is injected. It is not part of the evaluation run, but it writes `data/interim/base_lines.csv`, `results/splits.json` and `results/constants_calibration.json`, so it should also be explicitly approved.

### Retrospective approval record (template: blank; to be completed only by the author)

> I, ____________________, on ____/____/2026, approve the items ticked above for a re-execution of the G1 experiment (code v0.6, `PROMPT07_FINAL_DECISIONS.txt` sha256 `abbe90370a074224c0bfc389c25f9c76c2a2dd568c9561a1194f2a207d931542`). I understand this record is made on the date above and does not establish that the protocol was frozen before the original run. Seed status: ____________________. Signature / initials: ____________.
