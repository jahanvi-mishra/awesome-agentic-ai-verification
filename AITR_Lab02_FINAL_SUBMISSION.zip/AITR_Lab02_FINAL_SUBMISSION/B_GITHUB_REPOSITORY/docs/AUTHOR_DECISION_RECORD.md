# Author decision record (PROPOSED, not in force until signed)

**Project:** Designing Verification Checkpoints to Mitigate Silent Errors in Agentic AI Pipelines. Code v0.6; protocol file `PROMPT07_FINAL_DECISIONS.txt` (sha256 `abbe90370a074224c0bfc389c25f9c76c2a2dd568c9561a1194f2a207d931542`).
**Draft prepared:** 11 November 2026; **updated 12 November 2026** (neither is an approval date; see `docs/AUTHOR_REVIEW_SHEET.md` for a plain-language explanation of A-H), from `PROTOCOL_DISCREPANCY_REPORT.md`, the recovered protocol file, the v0.6 code, the research decisions, the manuscript and the evidence in this repository.

## 0. Author's overall decision (stated in the author's message of 11 November 2026)
Preserve the existing v0.6 implementation as the **operative implementation for reproduction**. Do not redesign the experiment or change working code to resolve documentation discrepancies. Disclose every historical detail that cannot be independently recovered.

## 1. Rules used in this record
- "**Operative**" means: this is what the code does and what the reproduction will use. It does **not** mean the choice was approved at the time of the original run. No historical approval is claimed for any item.
- Evidence labels: **VERIFIED** (read in a file), **INFERRED**, **UNKNOWN**.
- Every item below stays **"requires your explicit approval"** until you tick it. I recommend; I do not approve for you.
- Nothing here changes code, configuration, seeds or stored results. The manuscript (Rev 5.2.2, 12 November 2026) was changed only in wording and length; every number is unchanged (`docs/CHANGE_REPORT_FINAL.md`). Its Section 10 now describes this record as an unsigned draft; it must be updated if you sign.

## 2. Decisions A-H

### A. "Keep the first invoice" = lowest InvoiceNo (item 3)
- **Code:** `src/g1/eligibility.py:143-153` `keep_first_ids` iterates `sorted(ids)` (text order); called at `src/g1/data_prep.py:50-52`. Signature = (CustomerID, Country, sorted (StockCode, Quantity, pence)), `eligibility.py:113-131`.
- **Recommend: approve as operative.** It is deterministic, was flagged by the implementer at build time, and the reproduction can test it (see G).
- **Affects:** experimental results (which invoice of a duplicate group stays in the pool); not the pool *count*.
- **Historical evidence:** none of approval. Prompt 07 item 3 and Prompt 09 say only "keep the first"; the Prompt 09 implementation report (open point 3) records the ambiguity; no reply is in the files (UNKNOWN).
- **Disclose as:** "first" was implemented as lowest InvoiceNo; its approval date is not recorded.
- **Your approval needed:** YES.

### B. "Exact two-decimal prices" = at most two decimals (item 5)
- **Code:** `eligibility.py:32-36, 81` (`decimals <= 2`), `data_prep.py:47`, `src/g1/money.py:15-21` (rejects more than two decimals); `tests/test_eligibility.py:55-56` (a price of 5.0 is accepted).
- **Recommend: approve as operative.** In a numeric Excel column 2.5 and 2.50 cannot be told apart, so the literal reading cannot be applied (INFERRED; cell type not inspected).
- **Affects:** results (pool membership); not code or documentation otherwise.
- **Historical evidence:** none of approval; wording repeated in Prompt 09 and the manuscript.
- **Your approval needed:** YES.

### C. Additional pool rules: not cancelled, every line valid, at least two lines
- **Code:** `eligibility.py:70` (cancelled = starts with C/c), `:75-78` (row valid: fields present, Quantity > 0, UnitPrice > 0), `:104-105` (`s1 = not cancelled and all_valid and n_lines >= 2`); applied at `data_prep.py:44-47`.
- **Recommend: approve as operative, disclosed as "not among the 14 items".** The only attribution is an AI-written code comment pointing to Prompt 07 v0.1 steps 1-3 (`eligibility.py:3, 10`); that text is not available (UNKNOWN). The count gate (17,023 / 16,679) and the recorded base-lines hash test whether these rules reproduce the original pool.
- **Affects:** results (pool membership).
- **Historical evidence:** none (manuscript Section 5 already states the two-line rule is not in the decisions record).
- **Your approval needed:** YES.

### D. T4 reserve top-up
- **Code:** `src/g1/faults.py:64-84`, `src/g1/split.py:43-52`, `src/g1/experiment.py:78-82`; `configs/protocol_v1_0.json` `t4_policy: capable_only`; `src/g1/protocol.py` and `tests/test_experiment.py:136-138` allow no other policy. The 10 evaluation invoices stay in the evaluation set; 10 extra T4 cases come from reserve invoices (500 T4 cases, 510 clusters).
- **Recommend: approve as operative.** The stored outputs show it was used (`summary.json`: `t4_cases_from_reserve` = 10; VERIFIED), and declining it would make v0.6 impossible to run. The manuscript already discloses it.
- **Affects:** results and analysis (T4 n = 500; 10 cases with no clean counterpart).
- **Historical evidence:** your later prompts call it an "authorised reserve" (`d6a73839-attachment.txt:46,60`; `8f5b22bd-attachment.txt:30`); this is your wording, not a dated approval of the design change (UNKNOWN; AI-log row A5 says to confirm).
- **Your approval needed:** YES.

### E. T1-T5 definitions (item 13; Prompt 07 v0.2 unavailable)
- **Code:** `src/g1/faults.py:1-17, 87-138` (T1 CustomerID or UnitPrice removed; T2 quantity becomes "<q> pcs"; T3 negative or 10 x Q_max; T4 another line's price, after S2; T5 total or CustomerID from another invoice, after S3; draws T1 2, T2 1, T3 2, T4 2, T5 2).
- **Recommend: approve the code as operative; do not fabricate v0.2.** The code, your Prompt 09 summaries and the manuscript table agree with one another; none is the v0.2 source. If you find v0.2, supply it and differences are reported, not silently fixed.
- **Affects:** results; documentation wording.
- **Historical evidence:** implementation report open point 6 ("v0.2 text was not available to me"); no reply on file (UNKNOWN).
- **Your approval needed:** YES.

### F. Status of the run: retrospective approval, not a freeze
- **Code:** `configs/seeds.json` status "PROVISIONAL ... not frozen"; `run_experiment.py:46-49` checks only that the protocol file exists; `experiment.py:94` run-once guard; the manifest is hashed before any run. No freeze date or hash exists anywhere.
- **Recommend: approve the wording in section 4** (retrospective approval on the actual date; not pre-registered; seed recorded as provisional).
- **Affects:** documentation only (and what claims the paper may make).
- **Historical evidence:** your prompts call the run "frozen" and give hashes; none is a dated freeze record.
- **Your approval needed:** YES.

### G. Hash and count handling
- **Code:** `prepare` stops with exit 3 and writes nothing if the pool is not 17,023 or T4-capable is not 16,679 (`experiment.py:40-43`; `run_experiment.py:73-75`); the raw files are hash-checked against `SOURCE_MANIFEST.json` before and after reading; `evaluate` refuses a second run. Stored outputs live in `results/stored_evaluation/` and are never overwritten.
- **Recommend: approve** these procedures: stop on any count or hash difference; report both hash sets; never overwrite stored files; do not run the pilot or evaluation until the prepare-only result is reviewed.
- **Affects:** procedure and documentation only; no code change.
- **Historical evidence:** n/a (procedural).
- **Your approval needed:** YES.

### H. Other implementation choices (report section 7)
| Item | Code | Affects results? | Test before evaluation? | Status |
|---|---|---|---|---|
| H1 split = one permutation of sorted InvoiceNos, seed 20261030 | `split.py:3-10, 27-40` | **Yes** | Yes: `prepare` split hash vs recorded `c6bfe38c...` | **UNCONFIRMED** until the `prepare` split hash matches the recorded value |
| H2 L = 90th percentile of calibration totals, method **`higher`** (integer pence) | `split.py:63-73`; config says **OPEN** | **Yes** (POST/HOLD and the final total-limit rule) | Yes: `prepare` must give L = 81216 pence | **UNCONFIRMED** until `prepare` gives L = 81216 (see detail below) |
| H3 fault draw order; pilot and evaluation both start at fault seed 20261031 | `faults.py:87-138`; `experiment.py:70-82` | **Yes** | **Partly.** Read-only checks of the stored files (11 Nov 2026, `docs/H3_EVIDENCE_REPORT.md`): hashes match; 3,256 draw-dependent parameters match seed 20261031 and the implemented order. A fresh `evaluate` regenerating `ce58e561...` has **not** been done | **UNCONFIRMED PENDING EVALUATION MANIFEST HASH VERIFICATION** (partial consistency evidence only) |
| H4 CP1 has no "at least one line" rule | `rules.py:67-86` | No for T1-T5 (INFERRED: none removes a line; RF.5 would catch it) | n/a | Documentation (INFERRED no result effect; not verified) |
| H5 half-up rounding for prices with more than two decimals | `eligibility.py:11-12, 35-37` | No (INFERRED: such invoices are excluded first) | n/a | Documentation |
| H6 `oracle.py` docstring says "independent" | `oracle.py:1` | No | n/a | Keep the manuscript's "reference module, not independent" |

- **H2 detail:** Prompt 07 says only "the 90th percentile"; the `higher` method is stated in your later prompts together with L = £812.16 (`a14a3bc6-attachment.txt:130`; `d6a73839-attachment.txt:43`), so it is recorded in your prompts but there is no dated approval (UNKNOWN). It is testable: a different method would almost certainly not give 81216.
- **H3 is UNCONFIRMED PENDING EVALUATION MANIFEST HASH VERIFICATION.** *Evidence added 11 Nov 2026 (read-only, nothing regenerated; see `docs/H3_EVIDENCE_REPORT.md`):* the stored manifest (canonical hash) equals `ce58e5613cca7129970f230e2c268634a3890adf6c81016e390f3420fb4ddf50` and `manifest.sha256`; the stored `runs.jsonl` equals `5380db45a873c4499f6cd750151f3bb819f699b105857c6f1e0bd81eb6ecd0c5`; 3,256 draw-dependent parameters in the stored manifest match a replay of seed 20261031 in the implemented draw order (0 mismatches; other seeds give 2,361 to 2,382 mismatches). **Still unverified:** T4 line choices (need unit prices from the raw data), the 10 reserve top-up draws and the stream position they continue from, pilot seed usage (no pilot output), original code provenance (which version produced the stored files), and historical approval. A fresh `evaluate` matching the two hashes is still required before H3 can be called confirmed, and even then it would show only that this code reproduces the stored outputs, not that H3 was the intended design. If a fresh run's hashes differ, report both sets of results (section G).
- **Recommend:** accept H1, H2 and H4-H6 as operative and disclosed (H1 and H2 remain unconfirmed until the `prepare` comparison; H4-H5 are inferred, not verified). Accept **H3 only as "operative for reproduction, UNCONFIRMED PENDING EVALUATION MANIFEST HASH VERIFICATION"**. The six items are **not** approved or verified as a group.
- **Your approval needed:** YES.

## 3. Summary of what needs your approval
All eight (A-H) need explicit approval; H3 stays unconfirmed even after you approve it as operative. Result-affecting: A, B, C, D, E, H1, H2, H3. Documentation or procedure only: F, G, H4-H6.

## 4. Proposed retrospective approval record (to be completed only by the author)
> **Record status: PROPOSED.** In force only after the author completes and signs it.
>
> This is a **retrospective approval** made on **the actual date on which the author signs it** (written in the signature line below; no approval date is pre-filled, and none may be back-dated or forward-dated). It is **not a pre-registration and not a historical freeze**. It does not show that any item below was approved before the original evaluation outputs were produced. The original run's date, logs and any earlier approvals are not available.
>
> I approve, for a **reproduction** of the G1 experiment using code v0.6 **unchanged**, the following as operative (tick each):
> [ ] A lowest-InvoiceNo "first"  [ ] B at-most-two-decimals  [ ] C three additional pool rules  [ ] D T4 reserve top-up  [ ] E T1-T5 as implemented (v0.2 unavailable)  [ ] F this wording  [ ] G stop-and-report rules
> [ ] H1  [ ] H2  [ ] H4  [ ] H5  [ ] H6 as operative and disclosed (H1 and H2 unconfirmed until the `prepare` comparison)
> [ ] H3 as operative for reproduction only: **UNCONFIRMED PENDING EVALUATION MANIFEST HASH VERIFICATION** (I understand this is neither verified nor historically approved)
>
> Seeds: master 20261029, derived 20261030-20261033, status **PROVISIONAL** (no approval record exists).
> Recorded reference hashes (from the author's prompts, preserved verbatim in `docs/RECORDED_DATASET_HASHES.md`): raw XLSX `43465a06...`, ZIP `f5385cbb...`, base lines `67f95be8...`, split `c6bfe38c...`, manifest `ce58e561...`, runs `5380db45...`.
> Unresolved and disclosed: Prompt 07 v0.1 and v0.2 texts; any freeze date; pilot results; original logs; H3 (unconfirmed pending evaluation manifest hash verification; partial read-only consistency evidence, see `docs/H3_EVIDENCE_REPORT.md`).
>
> Author: ____________________  **Actual date of signing: ____/____/2026**  Initials: ______

## 5. What this record does not claim
No historical approval of A-H; no pre-registration; no fresh run; no predictions file; no recovery of Prompt 07 v0.1/v0.2.
