# Protocol recovery and implementation check (2026-11-10)

**Scope.** The author recovered the original 14-item *Prompt 07 - Final Eligibility Protocol (v1.0)* text. This note records (1) where it is stored, (2) whether the v0.6 code, configuration and tests implement each decision, (3) the T1-T5 status, (4) what still blocks a valid full run, and (5) the Colab commands. It is a read-only consistency check. **No code, configuration, seed, stored result or manuscript number was changed, and no experiment was run.** Evidence labels: VERIFIED (read in a file in this repository), INFERRED, UNKNOWN.

> **Update (11 Nov 2026):** the T1-T5 / interpretation questions are now covered by `docs/PROTOCOL_DISCREPANCY_REPORT.md` and `docs/AUTHOR_DECISION_RECORD.md`; the Colab plan is now prepare-only (`docs/PREPARE_ONLY_COLAB_PLAN.md`). The Colab block in section 5 below runs pilot and evaluation and must **not** be used until the author has signed the decision record and the prepare-only result has been reviewed.

## 1. Recovered protocol file
- Location: `PROMPT07_FINAL_DECISIONS.txt` in the **repository root** (the folder `scripts/run_experiment.py` calls `ROOT`).
- Source: the author's upload `f6b5f6f2-PROMPT07_FINAL_DECISIONS.txt`; the repository copy is byte-identical (`cmp`), UTF-8, 959 bytes, 14 numbered decisions, and equals the text the author pasted in the same message.
- SHA-256: `abbe90370a074224c0bfc389c25f9c76c2a2dd568c9561a1194f2a207d931542`. The AI-assistance log (row A2) recorded the prefix `abbe9037`; the recovered file matches that prefix. The log never recorded the full hash, so the match is a prefix match only.
- What the file does **not** contain: a date, a signature, a freeze hash, the Scenario D filter definition, or the Prompt 07 v0.2 fault text. It is the decisions record, not a freeze record.
- Runner gate: `scripts/run_experiment.py:48-49` only tests `(ROOT / "PROMPT07_FINAL_DECISIONS.txt").is_file()`; the contents are never read. With the file in the repository root the gate is satisfied (checked with a one-line `Path.is_file()` call; `evaluate` itself was **not** run).

## 2. Decision-by-decision implementation status
Implemented = found in code and/or config; the real-data count can only be confirmed by running `prepare` on the raw data.

| # | Decision (recovered text, short) | Where in v0.6 | Status |
|---|---|---|---|
| 1 | Pool = Scenario D, 17,023 invoices | `configs/protocol_v1_0.json` `pool.expected_pool_invoices`; `src/g1/experiment.py:40-43` stops with `PoolCountMismatch` (exit 3 in the script) | Implemented as a hard gate. **Real count UNVERIFIED** until `prepare` runs on raw data. The 14 items do not define Scenario D; the code also requires *not cancelled*, *every line valid (Quantity > 0, UnitPrice > 0, fields present)* and *at least 2 lines* (`eligibility.py:70, 75, 105`). Those three conditions are **not in the 14 items**; their source (Prompt 07 v0.1/eligibility report) is not available |
| 2 | Six-digit invoice numbers only | `eligibility.py:71` (`\d{6}` full match); `data_prep.py:47` | Implemented |
| 3 | Remove duplicate contents by full signature (CustomerID, Country, sorted line contents); keep first | `eligibility.py:113-131` (signature = CustomerID, Country, sorted (StockCode, Quantity, pence)); `eligibility.py:143-153` and `data_prep.py:50-52` (first by sorted InvoiceNo text) | Implemented. **Interpretations:** "line contents" = StockCode, Quantity, price in pence (InvoiceNo, date and Description excluded; test `test_duplicate_contents_ignore_invoiceno_date_description`); "first" = lowest InvoiceNo text |
| 4 | Exclude invoices with multiple InvoiceDate values | `eligibility.py:107` (`n_dates <= 1`); `data_prep.py:47` | Implemented. Edge case: an invoice whose dates are all unparseable has 0 dates and would pass; cannot be checked without the data |
| 5 | UnitPrice exact to two decimals | `eligibility.py:81` (`price_2dp`, decimals <= 2); `src/g1/money.py:15-21` rejects more than 2 decimals | Implemented. **Interpretation:** "exact two-decimal" = exactly representable in at most two decimals (a price such as 2.5 passes) |
| 6 | Five-digit CustomerID | `eligibility.py:73` (integer, 10000-99999) | Implemented (numeric test; leading zeros cannot be distinguished) |
| 7 | Integer Quantity | `eligibility.py:74` | Implemented |
| 8 | Exclude zero-pence lines | `data_prep.py:48-49`; also UnitPrice > 0 in S1 (`eligibility.py:75-78`) | Implemented (cannot occur after item 5; counted anyway) |
| 9 | Keep repeated exact rows within an invoice | `data_prep.py:57` appends every row; test `test_content_and_repeated_rows_kept` | Implemented |
| 10 | Decimal arithmetic and integer pence; no direct float multiplication | `money.py` (Decimal conversion; `line_amount` accepts ints only); `eligibility.py:34` (`Decimal(repr(price))`); `data_prep.py:57` casts to `int` | Implemented for the experiment path. **Note:** the eligibility *reporting* column `line_pence` and the duplicate signature use float64 holding whole numbers (`eligibility.py:82` and `:124`); these are exact at this size and are not used for pipeline money, but they are not Decimal |
| 11 | T4 only from invoices with >= 2 distinct unit prices; 16,679 T4-capable | `eligibility.py:108`; `faults.py:51-61` and `64-84`; config `expected_t4_capable_invoices` 16,679, `t4_policy: capable_only`; gate `experiment.py:42-43` | Implemented; real count UNVERIFIED until `prepare`. The **reserve top-up** (10 T4 cases from reserve invoices) is consistent with "only from capable invoices" but is an addition the 14 items do not mention; whether the author approved it is UNKNOWN (log row A5) |
| 12 | 1,000 calibration + 50 pilot + 500 evaluation | config `sizes`; `split.py:27-40` | Implemented. The split *mechanism* (one seeded permutation of sorted InvoiceNos) is not in the 14 items; `split.py:3` calls it "my specification of Prompt 07 Part 4" |
| 13 | T1-T5 "as specified in Prompt 07 v0.2" | `faults.py` | **Cannot be checked against v0.2** (text not available); see section 3 |
| 14 | Conditions B0, F, I | `pipeline.py:26`, `metrics.py:28`, config `conditions` | Implemented |

Tests: the 153 synthetic unit tests cover items 2-12 and 14 on small constructed tables (for example `test_pool_matches_hand_count`, `test_exact_conversion_without_float_error`, `test_split_uses_whole_pool_and_t4_only_from_capable_invoices`). They passed on 2026-11-10 in the assembly sandbox. They cannot confirm 17,023 / 16,679.

## 3. T1-T5 consistency
The detailed **Prompt 07 v0.2 fault text is not available** (the decisions file only points to it). Three other descriptions exist and agree with the code:
(a) the code (`faults.py:1-17` and `build_manifest`); (b) the author's Prompt 09 instructions, which summarise T1-T5 "exactly according to the approved Prompt 07 v0.2 specification" (`99b42aa3-attachment.txt`, section 4); (c) the manuscript table (Section 5).

| Type | One-line summary in Prompt 09 | Code | Status |
|---|---|---|---|
| T1 | missing CustomerID or UnitPrice | removes CustomerID (even first draw) or one line's UnitPrice, after S1 | Consistent |
| T2 | malformed Quantity string | one Quantity becomes its digits + " pcs", after S1 | Consistent (v0.2 may have listed other string forms: UNKNOWN) |
| T3 | negative or 10x maximum Quantity | -q, or 10 x Q_max (Q_max from calibration), after S1 | Consistent |
| T4 | incorrect line amount using another line's different UnitPrice | one line amount uses another line's different price, after S2; skipped if all prices equal | Consistent |
| T5 | invoice_total or CustomerID copied from another evaluation invoice | value copied from another invoice in the same subset, after S3; skipped if equal | Consistent |

Not checkable against the original: the injection stage, draw counts (T1 2, T2 1, T3 2, T4 2, T5 2), the 50/50 choice of variants, uniform line and partner selection, and the skip rules. They may be v0.2 requirements or implementation choices; they are not invented here, only unverified. Each is tested (`tests/test_faults_pipeline.py`).

## 4. Remaining blockers to a valid full run
1. **Raw data:** not in this repository or the workspace (the Drive backup ZIP was never supplied). Colab can download it with `dataset_audit.py download` (network, archive.ics.uci.edu only; untested here). ~~No stored hash of the original file exists, so identity with the data used originally cannot be confirmed (expected shape 541,909 x 8 appears only in the author's prompts: INFERRED).~~ **CORRECTION (11 Nov 2026; first noted 10 Nov 2026):** the struck sentence was wrong. The author's Prompt 12 text records the raw XLSX, ZIP, base-lines and split hashes (`d6a73839-attachment.txt:49-52`), preserved verbatim in `docs/RECORDED_DATASET_HASHES.md`. They are *recorded* values, not a manifest, and have not been recomputed here; a fresh download and the `prepare` output can be compared with them (`docs/PREPARE_ONLY_COLAB_PLAN.md`). The expected shape 541,909 x 8 is likewise recorded only in the author's prompts.
2. **`prepare` count gate:** this is the first real test of items 1 and 11 and of the unlisted "at least 2 lines" rule. If it stops (exit 3) with different counts, **stop and report**; do not edit the code or config.
3. **Run-once guard:** `evaluate` refuses if `results/evaluation/` is non-empty (`experiment.py:94`). Use a fresh project copy in Colab, never the Drive folder where an earlier run may live. The stored results here are in `results/stored_evaluation/` and do not trigger the guard.
4. **Environment drift:** the stored run most likely used Python 3.13.18 / numpy 2.1.3 / pandas 2.2.3 (one recorded session). A new Colab image may differ; identical outputs are expected from the deterministic code but this is UNVERIFIED across library versions. Record versions and compare hashes.
5. **Seeds still PROVISIONAL** and no freeze date/hash exists. A re-run is a *re-execution*. Decide in advance to report the outcome either way: if `manifest.sha256` equals `ce58e5613cca7129970f230e2c268634a3890adf6c81016e390f3420fb4ddf50` and `runs.jsonl` equals `5380db45a873c4499f6cd750151f3bb819f699b105857c6f1e0bd81eb6ecd0c5`, the stored results are reproduced; if not, report the difference and do not overwrite the stored files.
6. **RQ2:** `predictions.json` does not exist and must **not** be created now (it would not be a prior prediction). RQ2 stays NOT EVALUATED.
7. **Still missing provenance:** Prompt 07 v0.2 text, protocol freeze record (date/hash), pilot results, original run logs, eligibility report, constants file. The regenerated constants can be compared with the values quoted in the author's prompts and the manuscript: Q_max 2400, P_max 394932, T_max 1195610, L 81216 pence.

## 5. Exact Colab commands (NOT TESTED here; CPU runtime)
```python
from google.colab import drive; drive.mount('/content/drive')
# upload AITR_Lab02_Project_v2.zip to My Drive first
!unzip -q /content/drive/MyDrive/AITR_Lab02_Project_v2.zip -d /content/
%cd /content/AITR_Lab02_Project
!python --version && pip list 2>/dev/null | grep -i -E "^(numpy|pandas|openpyxl|matplotlib) "
!pip install -q -r requirements.txt
!python -m unittest discover -s tests 2>&1 | tail -4                 # expect: Ran 153 tests ... OK
!sha256sum PROMPT07_FINAL_DECISIONS.txt                              # expect abbe90370a074224...931542
!python scripts/dataset_audit.py download                            # fallback: register --zip PATH
!python scripts/dataset_audit.py audit
!python scripts/run_experiment.py prepare                            # STOP if exit 3 / counts differ from 17,023 and 16,679
!python scripts/run_experiment.py pilot                              # debugging run, 50 invoices
!python scripts/inspect_pilot.py pilot                               # exit 1 = a FAIL: stop and report
!python scripts/run_experiment.py verify-rerun pilot                 # expect "identical": true
# review the pilot output, then (single main run; refuses to run twice):
!python scripts/run_experiment.py evaluate --confirm-freeze
!python scripts/run_experiment.py verify-rerun evaluation
!python scripts/score_results.py evaluation
!cat results/evaluation/manifest.sha256; sha256sum results/evaluation/runs.jsonl
!diff -r results/evaluation results/stored_evaluation && echo IDENTICAL   # compare with the stored bundle
```
Do not create `results/evaluation/` or `predictions.json` by hand. The Colab notebook `notebooks/g1_colab_regeneration_UNTESTED.ipynb` automates the same steps and the hash comparison, but has never been executed; its Step 7 now finds the recovered file when placed in its inputs folder.
