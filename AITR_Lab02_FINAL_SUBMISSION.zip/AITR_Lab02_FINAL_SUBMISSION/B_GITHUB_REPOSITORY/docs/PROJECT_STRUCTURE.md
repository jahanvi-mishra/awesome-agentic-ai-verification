# Project structure and purpose of each folder

```
g1_silent_errors/
  README.md            entry point: what this is, how to run the first check
  requirements.txt     proposed minimum dependency versions (read by env_test.py)
  .gitignore           keeps raw/derived data and caches out of version control
  configs/             settings as data: seeds.json now; later split sizes, thresholds, rule constants
  src/g1/              importable study code (seeding.py, dataset_io.py, audit.py exist so far)
  scripts/             command-line entry points (env_test.py, dataset_audit.py; later run_experiment.py etc.)
  tests/               unit tests (unittest); one file per src module
  notebooks/           Colab notebooks for running and inspecting; no logic lives only here
  data/raw/            original UCI file exactly as downloaded - never edited
  data/interim/        cleaned base table, split lists (regenerable)
  data/processed/      case sets with injected faults (regenerable from seed + config)
  results/figures/     PNG plots for the paper
  results/tables/      CSV tables matching Prompt 07 templates R1-R9 (filled only by code)
  results/runs/        per-run records (one row per case x condition)
  logs/                environment reports, pip freeze, run logs - evidence, keep them
  docs/                protocol, decisions, verification log, troubleshooting
  paper/               manuscript drafts and final figures/tables copied from results/
```

Planned later, NOT created yet (to avoid empty code): src/g1/pipeline.py (S1-S4), checkpoints.py (CP1-CP3, final rules),
faults.py (T1-T5 injector), conditions.py (B0/F/I/F+), metrics.py (M1-M11, Wilson, cluster bootstrap), data.py (load, audit, split).

Rules: raw data is read-only; everything under data/interim, data/processed, results is regenerable from code + configs + seed;
no threshold or rule is changed after seeing results (see Prompt 07 protocol-change process).
