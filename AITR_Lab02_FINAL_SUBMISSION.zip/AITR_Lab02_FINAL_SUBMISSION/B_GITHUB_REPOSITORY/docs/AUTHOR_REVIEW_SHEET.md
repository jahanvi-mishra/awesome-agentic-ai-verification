# Author review sheet: decisions A-H in plain language (12 November 2026)

**Not a signature and not an approval.** This sheet explains what you would be approving in `docs/AUTHOR_DECISION_RECORD.md`. Only you can sign it, with the actual date. Approving means: "for the reproduction, use this choice as it is in the v0.6 code". It does **not** claim the choice was approved before the original run.

## What each decision means

| | Decision | In plain words | If you approve | If you do not | Changes results? |
|---|---|---|---|---|---|
| **A** | "Keep the first invoice" = lowest invoice number | When two invoices have identical contents, the pool keeps the one with the smallest invoice number (compared as text) | The reproduction keeps the code as is | The code would have to change, so v0.6 would no longer be the operative version | **Yes** (which invoices are in the pool) |
| **B** | "Exact two-decimal price" = at most two decimals | A price of 5.0 counts as valid; a price like 1.234 does not | Same | Same | **Yes** (pool membership) |
| **C** | Three extra pool rules: not cancelled, every line valid, at least two lines | The code applies these although they are not among the 14 written items; their only source is a code comment pointing to a protocol text we do not have | Reproduction uses them; the paper already says the two-line rule is not in the decisions record | The pool would differ and the 17,023 / 16,679 check would probably fail | **Yes** |
| **D** | T4 reserve top-up | 10 evaluation invoices cannot host a T4 fault, so 10 T4 cases come from reserve invoices (500 T4 cases, 510 invoices in all) | Matches the stored results (`t4_cases_from_reserve` = 10) | v0.6 cannot be run as it was | **Yes** (T4 n, clusters) |
| **E** | T1-T5 as implemented | The fault definitions are those in the code; the detailed Prompt 07 v0.2 text is missing, so they are not checked against it | The code, your summaries and the paper table agree | You would need to supply v0.2; differences would be reported | **Yes** |
| **F** | Wording: retrospective approval, not a freeze | The record says approval happens on the signing date, not before the run; the seed stays "provisional" | The paper and README keep saying "no freeze record" | You would need a real freeze record, which does not exist | No (affects what you may claim) |
| **G** | Stop-and-report rules | Any count or hash difference stops the run; both hash sets are reported; stored results are never overwritten | Safe procedure | Risk of silently "fixing" a mismatch | No |
| **H1** | Split = one permutation of sorted invoice numbers, seed 20261030 | How invoices are assigned to calibration / pilot / evaluation / reserve | Confirmed only if the `prepare` split hash equals `c6bfe38c...` | - | **Yes** |
| **H2** | L = 90th percentile with method "higher" | The POST/HOLD limit (81,216 pence) | Confirmed only if `prepare` gives L = 81,216 | - | **Yes** |
| **H3** | Fault draw order, shared fault seed 20261031 | The order in which random numbers pick fault details | Operative for reproduction only. **Not verified** (see below) | - | **Yes** |
| **H4-H6** | CP1 has no "at least one line" rule; half-up rounding; "independent" in a docstring | Small implementation details; no effect on T1-T5 results as far as can be inferred | Disclosed | - | No (inferred, not proved) |

## Highlighted: do not tick these without understanding them

1. **H3.** The stored manifest and runs hashes match the recorded values, and 3,256 draw-dependent parameters match a replay of seed 20261031. That is consistency evidence only. T4 line choices, the 10 reserve draws, pilot seed usage, code provenance and historical approval are unverified. Ticking H3 means "operative for reproduction, still unconfirmed", never "verified".
2. **C and D.** They shape the data pool and the case set. C has no recorded source; D is a design change the stored outputs show was used, but a dated approval of it does not exist.
3. **E.** You are accepting fault definitions without the v0.2 text. If you later find v0.2, differences must be reported.
4. **F.** Do not describe the run as "frozen" or "pre-registered" anywhere. No freeze date or hash exists. The paper (Sections 1, 3, 5.2, 8, 9) already says so.
5. **H1 and H2.** Do not treat them as confirmed until the prepare-only run matches `c6bfe38c...` and L = 81,216.

## What a prepare-only Colab run can and cannot confirm
It can check: the raw file hashes, the table shape (541,909 x 8), the pool counts (17,023 / 16,679), the base-lines and split hashes and the constants (Q_max 2,400; P_max 394,932; T_max 1,195,610; L 81,216), which tests A, B, C, H1 and H2 indirectly. It cannot confirm D, E, F or H3 (no manifest is built).

## Wording you must confirm before submission
- **Paper Section 9** now says the author *reports* running the documented sequence in Colab, no log or pilot output exists, and the results are *stored evaluation results*, with read-only hash and replay checks as consistency evidence. Is "the author reports" a true description of what you did?
- **Paper Section 10** now calls the decision record an unsigned draft. If you sign it, tell me and I will update the sentence.
- **AI log:** read every row of `ai_assistance_log.md` against your own history.
