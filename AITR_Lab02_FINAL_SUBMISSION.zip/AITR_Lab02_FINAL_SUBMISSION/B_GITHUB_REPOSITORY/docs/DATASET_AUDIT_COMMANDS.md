# Exact Colab commands: dataset download and audit

Start from the project folder: `%cd /content/g1_silent_errors` (re-upload and unzip the project zip first if the runtime was reset).

## 0. Update the project files (once, from the v0.2 zip)
Upload `g1_silent_errors_v0.2_dataset_audit.zip` using the Colab Files panel, then:
```
!unzip -o -q /content/g1_silent_errors_v0.2_dataset_audit.zip -d /content/
%cd /content/g1_silent_errors
!python -m unittest discover -s tests -v 2>&1 | tail -25
```
Expect `OK`. Send me this output too.

## 1. Download from the official UCI source
```
!python scripts/dataset_audit.py download
```
If it prints `DATASET ERROR: Download failed ...`, use the fallback:
download the zip from the official page in your browser, upload it in the Files panel, then
```
!python scripts/dataset_audit.py register --zip "/content/<your zip file name>.zip"
```

## 2. Quick trial audit (first 2,000 rows; optional)
```
!python scripts/dataset_audit.py audit --nrows 2000
```

## 3. Full audit (reading the xlsx can take several minutes)
```
!python scripts/dataset_audit.py audit
```

## 4. Show saved evidence
```
!ls -l data/raw logs
!cat data/raw/SOURCE_MANIFEST.json
```

## 5. Back up to Drive (copy, not move)
```python
from google.colab import drive
drive.mount('/content/drive')
```
```
!mkdir -p /content/drive/MyDrive/g1_backup
!cp -r data/raw /content/drive/MyDrive/g1_backup/
!cp -r logs /content/drive/MyDrive/g1_backup/
!ls -R /content/drive/MyDrive/g1_backup | head -30
```
Send me: the output of steps 0, 1, 3 and 4, and the full audit report text (`!cat logs/dataset_audit_*.md`; use the newest file, the full-audit one).
