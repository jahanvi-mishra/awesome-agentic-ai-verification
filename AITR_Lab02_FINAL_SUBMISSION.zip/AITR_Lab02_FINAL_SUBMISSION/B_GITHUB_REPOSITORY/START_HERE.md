# START HERE

Project: *Designing Verification Checkpoints to Mitigate Silent Errors in Agentic AI Pipelines* (code v0.6, deterministic four-stage invoice pipeline, UCI Online Retail ID 352, **not** an LLM-agent experiment).

## 1. Where the code is
| Question | Answer |
|---|---|
| Main pipeline implementation | **`src/g1/pipeline.py`**, function `run_pipeline` (stages S1 intake, S2 transform, S3 state update, S4 decide/commit; conditions B0, F, I). Its checks are in `src/g1/rules.py` (CP1, CP2, CP3, final validation) and the fault injection in `src/g1/faults.py` (T1-T5) |
| Script that runs the experiment | **`scripts/run_experiment.py`** with subcommands `prepare`, `pilot`, `evaluate --confirm-freeze`, `verify-rerun`. It calls `src/g1/experiment.py` |
| Script that scores results | `scripts/score_results.py evaluation` (uses `src/g1/metrics.py`) |
| Full list of code files and purposes | `docs/FILE_INVENTORY.md` |

## 2. What each folder contains
| Folder / file | Contents |
|---|---|
| `src/g1/` | the experiment package (16 modules) |
| `scripts/` | command-line scripts; `verify_stored_results.py`, `h3_replay_check.py` and `check_paper_vs_csv.py` are new and read-only |
| `configs/` | `protocol_v1_0.json` (settings), `seeds.json` (seeds, status PROVISIONAL) |
| `tests/` | 153 unit tests on synthetic data (12 files) |
| `notebooks/` | `00_environment_check.ipynb` (original); `g1_prepare_only_colab_UNTESTED.ipynb` (current plan); `g1_colab_regeneration_UNTESTED.ipynb` (full re-run, **not** the current plan) |
| `data/` | `README.md` only; raw data is never committed |
| `results/` | `stored_evaluation/` (runs, labels, manifest, summary, 13 metric CSVs), `stored_figures/`, `logs/`; empty placeholders `figures/ runs/ tables/` |
| `paper/` | manuscript Rev 5.2.2 (10 pages; file stem `manuscript_rev5_2_1`): `.tex`, `.bib`, `.bbl`, `.pdf`, figures, `supplementary_text.pdf` (methodology detail), `supplementary_figures.pdf` |
| `docs/` | decision record, discrepancy report, recorded hashes, plans, result-to-source map, paper check, demo script, viva sheet |
| root files | `README.md`, `PROMPT07_FINAL_DECISIONS.txt`, `requirements.txt`, `research_decisions.md`, `baseline_validation.md`, `ai_assistance_log.md` |

## 3. Exact Colab execution order (current plan: prepare only)
Do this only after you have signed `docs/AUTHOR_DECISION_RECORD.md`. Details and stop rules: `docs/PREPARE_ONLY_COLAB_PLAN.md`.
1. New Colab notebook, CPU runtime; upload `AITR_Lab02_Project_FINAL.zip`; open `notebooks/g1_prepare_only_colab_UNTESTED.ipynb`.
2. Cell 1: leave `APPROVAL_RECORD_FINALISED = False` until you have signed.
3. Run: Step 1 (unzip and integrity) -> Step 2 (`pip install`, `scripts/env_test.py`) -> Step 3 (`dataset_audit.py download`) -> Step 4 (compare raw XLSX/ZIP hashes with recorded values) -> Step 5 (`dataset_audit.py audit`).
4. Set `APPROVAL_RECORD_FINALISED = True`, re-run Cell 1, then Step 6 (`run_experiment.py prepare`; expect 17,023 invoices, 16,679 T4-capable, recorded base-lines and split hashes, L = 81216) and Step 7 (save the evidence zip).
5. **Stop.** Any mismatch stops the notebook; send the printed output. Do **not** run `pilot`, `evaluate` or `score_results` yet: that needs a separate decision after the prepare-only result is reviewed. (Later sequence, not authorised now: `pilot` -> `inspect_pilot.py pilot` -> `verify-rerun pilot` -> `evaluate --confirm-freeze` -> `verify-rerun evaluation` -> `score_results.py evaluation` -> compare hashes with `results/stored_evaluation/`.)

## 4. What has and has not been tested
| Item | Status |
|---|---|
| `python -m unittest discover -s tests` (153 tests) | **Tested** in the assembly sandbox (not Colab), 2026-11-10 and again on the v3 ZIP; all pass; synthetic data only |
| `python scripts/verify_stored_results.py` | **Tested** in the sandbox; all checks pass; checks internal consistency of the stored files only |
| `python paper/supplementary/figure_data/make_figures_rev5.py results/stored_evaluation/metrics OUTDIR` | **Tested** in the sandbox (earlier assembly); source-values file identical to the stored one |
| `python scripts/check_paper_vs_csv.py` | **Tested** in the sandbox (12 Nov 2026): 61 checks, 0 failures; paper numbers equal the stored CSVs |
| `python scripts/h3_replay_check.py` | **Tested** in the sandbox (11 Nov 2026): 3,256 checks, 0 mismatches at seed 20261031; consistency evidence only; output in `docs/H3_REPLAY_OUTPUT.txt` |
| `python scripts/run_experiment.py --help` | **Tested** (prints usage only) |
| Notebook helper functions (hash comparison, parsing of `prepare` output) | **Tested locally** on synthetic output only |
| `scripts/env_test.py` in Colab | Ran once on 2026-10-31 per the pasted console log (`results/logs/colab_env_check_console_2026-10-31.txt`); not re-run |
| Both new notebooks as a whole, in Colab | **NOT tested** |
| `dataset_audit.py download/register/audit`, `prepare`, `pilot`, `inspect_pilot`, `evaluate`, `verify-rerun`, `score_results` | **NOT tested** by me; no raw data here; no log proves the original execution |
| Stored evaluation outputs | present and internally consistent; **provenance not established**; not independently reproduced |

## 5. What to show your instructor (actual implementation, honestly)
1. Open `src/g1/pipeline.py` (`run_pipeline`), `src/g1/rules.py` and `src/g1/faults.py`; explain stages, B0/F/I and T1-T5. Show `scripts/run_experiment.py` as the entry point.
2. Run in a terminal: `python -m unittest discover -s tests` (expect `Ran 153 tests ... OK`) and `python scripts/verify_stored_results.py` (expect ALL CHECKS PASSED).
3. Show `results/stored_evaluation/metrics/R1_primary.csv`, `R5_clean_false_alarms.csv`, `R6_cost.csv` and `results/stored_figures/`; use `docs/RESULT_TO_SOURCE_MAP.md` to trace a paper number to its file.
4. Show `docs/AUTHOR_DECISION_RECORD.md` (state whether signed) and the "MISSING / NOT VERIFIED" list in `README.md`.
5. Say clearly: the results are stored outputs, internally consistent but not independently reproduced; the prepare-only Colab run (if completed) checks dataset hashes, counts and constants only. Do not call anything a fresh reproduction of the experiment.
