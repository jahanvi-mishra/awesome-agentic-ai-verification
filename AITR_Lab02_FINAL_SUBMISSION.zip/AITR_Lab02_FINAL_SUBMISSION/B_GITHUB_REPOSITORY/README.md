# Verification checkpoints for silent errors in a simulated multi-stage pipeline (G1)

**Paper:** *Designing Verification Checkpoints to Mitigate Silent Errors in Agentic AI Pipelines* (manuscript Revision 5.2.2, 10 pages, `paper/manuscript_rev5_2_1.pdf`; methodology detail in `paper/supplementary_text.pdf`).
**Author:** Jahanvi Mishra, M.Tech, IIIT Allahabad. **Guide:** Prof. Sonali Agarwal.
**New here? Read `START_HERE.md` first** (main code files, folder map, Colab order, what is tested). Code inventory: `docs/FILE_INVENTORY.md`.

## What this is (and is not)
A **deterministic four-stage Python pipeline** turns invoices from the UCI Online Retail data set (ID 352) into entries in a simulated ledger. It is a **controlled stand-in for a multi-stage agentic workflow**: each stage hands its output to the next, so a wrong value from an early stage can travel silently to the final commit. Five fault types (T1-T5) are injected one at a time and three conditions are compared:

| Condition | Meaning |
|---|---|
| **B0** | all checks off (measurement reference; defines which faults are harmful) |
| **F** | final validation only |
| **I** | intermediate checkpoints CP1, CP2, CP3, then the identical final validation |

It is **not** an LLM-agent experiment, does **not** reproduce a published baseline, and does not test production systems.

## Result (stored evaluation outputs, `results/stored_evaluation/`)
Harmful cases reaching commit: **F 1,972 / 2,500 (78.88%); I 0 / 2,500**; difference 78.88 points (95% invoice-level bootstrap interval 77.24 to 80.39). Clean false alarms 10 / 500 (2.0%) under both. Rule applications per run: F 5.46, I 71.41 (ratio 13.07). RQ2 was **not evaluated**. The checkpoints were written for the injected faults, so this shows coverage of a known taxonomy in a simulation. Every number is mapped to its file in `docs/RESULT_TO_SOURCE_MAP.md`.

## Evidence status (read this before the demo)
| Item | Status |
|---|---|
| Code (`src/`, `scripts/`, `configs/`, `tests/`) | v0.6 package copied **unchanged** (hashes in `docs/SHA256_ORIGINAL_FILES.txt`) |
| 153 unit tests | **VERIFIED** in the assembly sandbox on 2026-11-10 (`Ran 153 tests ... OK`). Synthetic data only; this is not the research experiment |
| Stored evaluation bundle | Present and **internally consistent** (`scripts/verify_stored_results.py`, all checks pass). **Execution provenance not established**: no logs, no pilot output, no run record |
| Full pipeline `prepare -> pilot -> evaluate -> score_results` on the real data | **No log or notebook output proves it was run**; not re-run here |
| 14-item protocol decisions (`PROMPT07_FINAL_DECISIONS.txt`) | **RECOVERED** by the author and stored in the repository root (sha256 `abbe90370a07...931542`, matches the prefix recorded in the log). Implementation check: `docs/PROTOCOL_IMPLEMENTATION_CHECK.md`. It carries no date or freeze hash, so the *freeze record* is still missing |
| Protocol interpretations (decisions A-H) | **Proposed, not yet approved**: `docs/AUTHOR_DECISION_RECORD.md` (retrospective, not a freeze); discrepancy details in `docs/PROTOCOL_DISCREPANCY_REPORT.md` |
| Recorded dataset hashes | Recorded in the author's prompts, preserved in `docs/RECORDED_DATASET_HASHES.md`; **not yet recomputed** |
| Independent reproduction from raw data | **NOT DONE** (raw data and `SOURCE_MANIFEST.json` not available). Next step planned: prepare-only Colab run, `docs/PREPARE_ONLY_COLAB_PLAN.md` |

## Repository layout
```
README.md  PROMPT07_FINAL_DECISIONS.txt  requirements.txt  research_decisions.md  baseline_validation.md  ai_assistance_log.md
configs/    protocol_v1_0.json, seeds.json            (settings and seeds; seed status PROVISIONAL)
src/g1/     the experiment package (modules below)
scripts/    run_experiment.py (MAIN), score_results.py, inspect_pilot.py, dataset_audit.py,
            final_eligibility_audit.py, env_test.py, verify_stored_results.py (NEW, read-only), h3_replay_check.py and check_paper_vs_csv.py (NEW, read-only)
tests/      153 unit tests on synthetic data
notebooks/  00_environment_check.ipynb (original), g1_colab_regeneration_UNTESTED.ipynb
data/       README.md only (no raw data)
results/    stored_evaluation/ (runs, labels, manifest, summary, 13 metric CSVs), stored_figures/, logs/, CHECKSUMS_STORED_RESULTS.sha256
paper/      .tex, .bib, .bbl, .pdf (10 pages), supplementary_text.* (methodology detail, discussion), figures/, supplementary/ (figure data + figure script)
docs/       result map, paper consistency check, research brief, demo script, viva sheet, original package docs
```

## Main entry point
**`scripts/run_experiment.py`**, with subcommands `prepare`, `pilot`, `evaluate --confirm-freeze`, `verify-rerun [pilot|evaluation]`. It calls `src/g1/experiment.py`; the pipeline itself is `src/g1/pipeline.py`. Scoring is separate: `scripts/score_results.py evaluation`.

## What each module does
| Module | Purpose |
|---|---|
| `pipeline.py` | the four stages (S1 intake, S2 transform, S3 state update, S4 decide/commit); conditions B0, F, I; halts at the first failed rule; no repair |
| `rules.py` | CP1, CP2, CP3 and the final validation (RF.1-RF.6) |
| `faults.py` | builds the fault manifest once (T1-T5, per-type draw counts, T4 reserve top-up) and the injection hook |
| `oracle.py` | the reference computation of the correct commit record; labels a fault *harmful* if the B0 record differs (the paper calls it a reference module, not an independent validation) |
| `runner.py`, `experiment.py` | run B0/F/I for each case, write JSON-lines logs, orchestrate `prepare`/`pilot`/`evaluate` (run-once guard) |
| `metrics.py` | metrics M1-M11, Wilson and bootstrap intervals, tables R1-R9 |
| `split.py`, `seeding.py` | deterministic split (1,000 calibration / 50 pilot / 500 evaluation / reserve) and calibration constants; seed control |
| `eligibility.py`, `data_prep.py`, `dataset_io.py`, `audit.py` | dataset eligibility (Scenario D), base invoices, safe download/registration, read-only audit |
| `money.py`, `protocol.py`, `pilot_check.py` | integer-pence money, protocol/seed loading, pilot inspection |

## Commands
**Tested during assembly (2026-11-10, sandbox, no raw data needed)**
```
python -m unittest discover -s tests                         # 153 tests, OK (run on a copy)
python scripts/verify_stored_results.py                      # read-only; all checks pass
python scripts/check_paper_vs_csv.py                          # read-only; paper numbers vs stored CSVs (61 checks, 0 failures)
python scripts/h3_replay_check.py                              # read-only; stored manifest vs seed 20261031 replay: 3,256 checks, 0 mismatches (consistency only; H3 stays unconfirmed)
python paper/supplementary/figure_data/make_figures_rev5.py results/stored_evaluation/metrics /tmp/figs   # regenerates 5 figures
```
**Documented but NOT tested here (need the raw data; `evaluate` also needs `PROMPT07_FINAL_DECISIONS.txt` in the project root, which is now present; it is only checked for existence)**
```
python scripts/dataset_audit.py download                     # or: register --zip PATH ; then: audit
python scripts/run_experiment.py prepare
python scripts/run_experiment.py pilot
python scripts/inspect_pilot.py pilot
python scripts/run_experiment.py evaluate --confirm-freeze   # refuses to run twice / without the decisions file
python scripts/run_experiment.py verify-rerun evaluation
python scripts/score_results.py evaluation
```
Do not copy `results/stored_evaluation/` into `results/evaluation/`: the run-once guard treats a non-empty folder as already run. `PROMPT07_FINAL_DECISIONS.txt` is the author's recovered original and must not be edited. The Colab notebook `notebooks/g1_colab_regeneration_UNTESTED.ipynb` wraps these steps and compares the new outputs with the stored hashes; it has never been executed.

## Seeds and conditions
Master seed 20261029 (**PROVISIONAL**, `configs/seeds.json`); split +1, faults +2, missed-case review +3, bootstrap +4 (20261033). Calibration 1,000, pilot 50, evaluation 500 invoices; limit L is the 90th percentile of calibration totals (method "higher"). Draws per invoice: T1 2, T2 1, T3 2, T4 2, T5 2.

## MISSING / NOT VERIFIED
1. `g1_silent_errors_backup-20261110T054543Z-1-001.zip` (dataset, source manifest, dataset audit, environment logs) was named in the brief but is **not in the workspace**.
2. ~~`PROMPT07_FINAL_DECISIONS.txt` not available~~ **Resolved:** recovered and stored in the repository root. Still missing: the **Prompt 07 v0.2** text (detailed T1-T5 definitions), and any freeze record (date, hash) for the protocol.
3. Raw UCI data, `SOURCE_MANIFEST.json`, retrieval date, dataset audit report. (The author's prompts do record the raw XLSX, ZIP, base-lines and split hashes: `docs/RECORDED_DATASET_HASHES.md`; they are recorded values, not recomputed.)
4. Pilot results, `results/pilot/`, calibration-constants file, eligibility report, `predictions.json` (RQ2 not evaluated).
5. Original Colab notebooks and execution logs for `prepare`, `pilot`, `evaluate`, `verify-rerun`, `score_results`; number of evaluation executions; freeze date; seed approval.
6. Which code version (v0.4/v0.5/v0.6) produced the stored bundle: v0.6 is likeliest, not established.
7. Audit script and `audit_checks.csv` (57 checks) cited by the Revision 5 report: not found in any supplied file, not recreated. `scripts/check_paper_vs_csv.py` (61 checks) and `scripts/verify_stored_results.py` (19 PASS) are the inspectable checks.
8. Second-person rerun; LaTeX rebuild and BibTeX re-check; author review of `ai_assistance_log.md` and of the AI-use wording.

## Protocol decisions and next step
**Current plan:** run only `prepare` in a fresh Colab (no pilot or evaluation) after the author signs `docs/AUTHOR_DECISION_RECORD.md`; see `docs/PREPARE_ONLY_COLAB_PLAN.md` and `notebooks/g1_prepare_only_colab_UNTESTED.ipynb`. The command block in the next paragraph and in `docs/PROTOCOL_IMPLEMENTATION_CHECK.md` runs the full experiment and is **not** the current plan.

`PROMPT07_FINAL_DECISIONS.txt` holds the 14 final decisions. `docs/PROTOCOL_IMPLEMENTATION_CHECK.md` maps each decision to the code, compares T1-T5 with the code, lists the remaining blockers to a valid full run (raw data, the `prepare` count gate, a fresh `results/evaluation/` folder) and gives the exact Colab commands. The full experiment has **not** been run.

## Licence and data
Code: no licence file was supplied (add one if the instructor requires it). Data: UCI Online Retail, CC BY 4.0, not redistributed here.

## GitHub readiness (checked 13 Nov 2026; the repository has NOT been published)
- **Secrets / private data:** a text scan found no API keys, tokens, passwords or e-mail addresses in the project files (the only keyword hits were LaTeX class and style files).
- **Size:** about 8 MB, 145 files; the largest are `results/stored_evaluation/runs.jsonl` (3.0 MB), `manifest.json` (0.7 MB) and the paper PDF (0.9 MB). No file exceeds GitHub's limits.
- **Raw data:** none is included. `.gitignore` excludes `data/raw/`, `data/interim/` and `data/processed/` contents, so the UCI file is never committed (it is CC BY 4.0, but is fetched from UCI, see `data/README.md`). `runs.jsonl` and `manifest.json` hold derived records (invoice numbers, quantities, prices, country, CustomerID values and injected faults) taken from the public dataset; the author should decide whether she is content to publish these derived records.
- **Licence:** none is chosen. Code licence is the author's decision; add a `LICENSE` file before making the repository public if one is wanted. Cite the dataset (Chen 2015, CC BY 4.0).
- **Publishing steps** (run by the author, from the repository root; not run here):
```
git init -b main
git add .
git status                      # check: no data/raw files, no *.aux/*.log
git commit -m "Final submission: verification checkpoints for silent errors (G1)"
# on github.com: New repository -> name e.g. silent-errors-checkpoints -> leave empty (no README/licence) -> Create
git remote add origin https://github.com/<your-username>/<repo-name>.git
git push -u origin main
```
