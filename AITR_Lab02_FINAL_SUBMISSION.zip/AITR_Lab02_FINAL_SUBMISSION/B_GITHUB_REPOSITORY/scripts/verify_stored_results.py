#!/usr/bin/env python3
"""READ-ONLY consistency check of a stored evaluation output (added during final repository assembly).

NEW FILE: not part of the original v0.6 implementation. It runs nothing from the experiment and writes nothing.
It recomputes headline numbers from the case-level files (runs.jsonl, labels.jsonl, manifest.json) and compares them
with summary.json and the metric CSVs. A PASS shows the stored files agree with each other. It does NOT show who
produced them, when, or on which code version.

  python scripts/verify_stored_results.py [results/stored_evaluation]
"""
import csv, hashlib, json, sys
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))
from g1 import faults  # noqa: E402

D = Path(sys.argv[1]) if len(sys.argv) > 1 else ROOT / "results" / "stored_evaluation"
jl = lambda p: [json.loads(l) for l in p.read_text(encoding="utf-8").splitlines() if l.strip()]
rc = lambda p: list(csv.DictReader(open(p, encoding="utf-8")))
fails = 0
def check(name, ok, detail=""):
    global fails
    fails += (not ok)
    print(("PASS " if ok else "FAIL ") + name + (f"  [{detail}]" if detail else ""))

summ = json.loads((D / "summary.json").read_text())
manifest = json.loads((D / "manifest.json").read_text())
runs, labels = jl(D / "runs.jsonl"), jl(D / "labels.jsonl")
m = D / "metrics"

mh = faults.manifest_hash(manifest)
check("manifest hash == manifest.sha256", mh == (D / "manifest.sha256").read_text().strip(), mh[:16])
check("manifest hash == summary.json", mh == summ["manifest_sha256"])
rh = hashlib.sha256((D / "runs.jsonl").read_bytes()).hexdigest()
check("runs.jsonl sha256 == summary.json", rh == summ["runs_sha256"], rh[:16])

check("3,000 runs per condition (B0, F, I)", Counter(r["condition"] for r in runs) == {"B0": 3000, "F": 3000, "I": 3000})
lab = {l["case_id"]: l for l in labels}
check("every run has a label; 3,000 cases", {r["case_id"] for r in runs} == set(lab) and len(lab) == 3000)
check("label counts match summary", dict(Counter(l["label"] for l in labels)) == summ["label_counts"])
oc = Counter(f'{r["condition"]}_{r["outcome"]}' for r in runs)
check("outcome counts match summary", dict(oc) == summ["outcome_counts_by_condition"], str(dict(oc)))

harm = {c for c, l in lab.items() if l["label"] == "harmful"}
clean = {c for c, l in lab.items() if l["label"] == "reference_match"}
by = {(r["case_id"], r["condition"]): r for r in runs}
R1 = {r["condition"]: r for r in rc(m / "R1_primary.csv")}
for c in ("F", "I"):
    n = sum(by[(k, c)]["outcome"] == "COMMITTED" for k in harm)
    check(f"harmful reaching commit, {c}: recomputed == R1_primary", n == int(R1[c]["reached_commit_n"]), f"{n}/{len(harm)}")
R5 = {r["condition"]: r for r in rc(m / "R5_clean_false_alarms.csv")}
for c in ("F", "I"):
    n = sum(by[(k, c)]["outcome"] == "HALTED" for k in clean)
    check(f"clean false alarms, {c}: recomputed == R5", n == int(R5[c]["halted"]), f"{n}/{len(clean)}")
R6 = {r["condition"]: r for r in rc(m / "R6_cost.csv")}
for c in ("B0", "F", "I"):
    n = sum(r["rule_applications"] for r in runs if r["condition"] == c)
    check(f"rule applications, {c}: recomputed == R6", n == int(R6[c]["total_rule_applications"]), str(n))
ft = {c: l["fault_type"] for c, l in lab.items()}
for r in rc(m / "R2_per_type.csv"):
    t = r["type"]; ks = [k for k in harm if ft[k] == t]
    check(f"{t}: F reached commit recomputed == R2", sum(by[(k, "F")]["outcome"] == "COMMITTED" for k in ks) == int(r["F_reached_n"]))
print("\nRESULT:", "ALL CHECKS PASSED (internal consistency of stored files only)" if not fails else f"{fails} CHECK(S) FAILED")
sys.exit(1 if fails else 0)
