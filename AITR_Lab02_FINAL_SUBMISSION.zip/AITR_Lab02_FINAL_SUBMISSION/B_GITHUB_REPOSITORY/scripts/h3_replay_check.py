"""READ-ONLY consistency check added in v4 (not part of the original v0.6 code). Tests whether the stored evaluation manifest is consistent with the documented fault-draw
mechanism (seed 20261031, 9 draws per invoice in the order T1 2, T2 1, T3 2, T4 2, T5 2). It does NOT rebuild the manifest,
does NOT read raw data, and does NOT run any pipeline condition. 
Usage (project root):  python scripts/h3_replay_check.py [EVAL_DIR] [SEED]
Defaults: EVAL_DIR = results/stored_evaluation, SEED = 20261031 (the derived fault seed; configs/seeds.json is PROVISIONAL).
A zero-mismatch result is consistency evidence only. It is NOT a fresh verification of H3: T4 line choices, the 10 reserve
top-up draws, pilot seed usage, original code provenance and historical approval are not checked here."""
import json, sys
from pathlib import Path
import numpy as np
ROOT = Path(__file__).resolve().parents[1]
D = sys.argv[1] if len(sys.argv) > 1 else str(ROOT / "results" / "stored_evaluation")
SEED = int(sys.argv[2]) if len(sys.argv) > 2 else 20261031
man = json.load(open(f"{D}/manifest.json"))
runs = [json.loads(l) for l in open(f"{D}/runs.jsonl")]
nlines = {r["case_id"].rsplit("-",1)[0]: r["commit_record"]["n_lines"] for r in runs if r["condition"]=="B0" and r["case_id"].endswith("-CLEAN")}
main = [r for r in man if r.get("source") != "t4_reserve"]
by = {}
order = []
for r in main:
    by.setdefault(r["invoice_no"], {})[r["fault_type"]] = r
    if r["invoice_no"] not in order: order.append(r["invoice_no"])
print("main manifest rows:", len(main), "| invoices:", len(order), "| top-up rows:", len(man)-len(main))
print("invoice order == sorted text order:", order == sorted(order))
print("row order inside each invoice is CLEAN,T1..T5:", all([x["fault_type"] for x in main[i*6:(i+1)*6]]==["CLEAN","T1","T2","T3","T4","T5"] for i in range(len(order))))
rng = np.random.default_rng(SEED)
draw = lambda n: [int(x) for x in rng.integers(0, 2**31-1, size=n)]
res = {k:[0,0] for k in ["T1 target parity","T1 unit_price line_index","T2 line_index","T3 variant parity","T3 line_index","T5 target parity","T5 partner"]}
def chk(k, ok): res[k][0 if ok else 1] += 1
for inv in order:
    n = nlines[inv]; g = by[inv]
    u1=draw(2); u2=draw(1); u3=draw(2); u4=draw(2); u5=draw(2)
    t1=g["T1"]; chk("T1 target parity", (u1[0]%2==0)==(t1["params"]["target"]=="customer_id"))
    if t1["params"]["target"]=="unit_price": chk("T1 unit_price line_index", t1["params"]["line_index"]==u1[1]%n)
    chk("T2 line_index", g["T2"]["params"]["line_index"]==u2[0]%n)
    t3=g["T3"]; chk("T3 variant parity",(u3[0]%2==0)==(t3["params"]["variant"]=="negative")); chk("T3 line_index", t3["params"]["line_index"]==u3[1]%n)
    t5=g["T5"]; partners=[p for p in order if p!=inv]
    if "target" in t5["params"]:
        chk("T5 target parity",(u5[0]%2==0)==(t5["params"]["target"]=="invoice_total"))
        chk("T5 partner", t5["params"]["partner"]==partners[u5[1]%len(partners)])
for k,(a,b) in res.items(): print(f"{k:28s} match {a:4d}  mismatch {b:4d}")
tot=sum(a for a,b in res.values()); bad=sum(b for a,b in res.values()); print("TOTAL checks",tot+bad,"| mismatches",bad)
