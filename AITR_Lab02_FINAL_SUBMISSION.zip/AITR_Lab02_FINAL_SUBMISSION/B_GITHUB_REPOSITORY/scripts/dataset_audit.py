#!/usr/bin/env python3
"""Download / register / audit the UCI Online Retail dataset (ID 352).

Commands (run from the project root):
  python scripts/dataset_audit.py download            download from the official UCI host, register, verify
  python scripts/dataset_audit.py register --zip P    fallback: register a zip you downloaded yourself
  python scripts/dataset_audit.py audit [--nrows N]   verify hashes, read the xlsx (read-only), write the report

Raw files live in data/raw/ and are never modified. Reports go to logs/.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from g1 import audit, dataset_io  # noqa: E402

RAW_DIR = ROOT / "data" / "raw"
LOGS_DIR = ROOT / "logs"


def _json_default(obj):
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (np.floating,)):
        return float(obj)
    return str(obj)


def show_manifest(m: dict) -> None:
    print("--- Source record ---")
    for k in ("acquisition_mode", "requested_url", "final_url", "local_zip_filename", "zip_size_bytes",
              "zip_sha256", "xlsx_filename", "xlsx_size_bytes", "xlsx_sha256"):
        print(f"{k:20s}: {m.get(k)}")
    print(f"{'downloaded_utc':20s}: {m.get('downloaded_utc')}")
    print(f"{'dataset_version':20s}: {m.get('dataset_version')}")


def cmd_download(_args) -> int:
    print(f"Source: {dataset_io.OFFICIAL_ZIP_URL}\nTarget: {RAW_DIR}")
    m = dataset_io.fetch_from_uci(RAW_DIR)
    show_manifest(m)
    print("Raw files are read-only and hashed in SOURCE_MANIFEST.json. Next: audit.")
    return 0


def cmd_register(args) -> int:
    m = dataset_io.register_manual_zip(args.zip, RAW_DIR)
    show_manifest(m)
    print("Registered. Next: audit.")
    return 0


def cmd_audit(args) -> int:
    manifest = dataset_io.verify_manifest(RAW_DIR)   # raises if raw files changed
    xlsx = RAW_DIR / manifest["xlsx_filename"]
    print(f"Hashes match the manifest. Reading {xlsx.name} (read-only). This can take several minutes...")
    book = pd.ExcelFile(xlsx, engine="openpyxl")
    sheet = book.sheet_names[0]
    df = book.parse(sheet, dtype=object, nrows=args.nrows)   # object dtype: wrong types stay visible
    scope = "FULL FILE" if args.nrows is None else f"PARTIAL AUDIT: first {args.nrows} rows only (not the full file)"
    print(f"Read {len(df)} rows x {df.shape[1]} columns from sheet {sheet!r}. Auditing...")
    facts = audit.run_audit(df)

    after = dataset_io.verify_manifest(RAW_DIR)      # raw files must be unchanged after the audit too
    integrity = {"hashes_verified_before_reading": True, "hashes_verified_after_reading": True,
                 "zip_sha256": after["zip_sha256"], "xlsx_sha256": after["xlsx_sha256"],
                 "raw_files_modified_by_audit": False}
    meta = {"run_utc": dataset_io.utc_now(), "scope": scope, "sheet_names": book.sheet_names,
            "sheet_read": sheet, "integrity": integrity}
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    LOGS_DIR.mkdir(exist_ok=True)
    md_path, js_path = LOGS_DIR / f"dataset_audit_{stamp}.md", LOGS_DIR / f"dataset_audit_{stamp}.json"
    text = audit.render_markdown(facts, manifest, meta)
    md_path.write_text(text, encoding="utf-8")
    js_path.write_text(json.dumps({"meta": meta, "manifest": manifest, "facts": facts}, indent=2,
                                  default=_json_default), encoding="utf-8")
    print(text)
    print(f"\nSaved: {md_path.relative_to(ROOT)} and {js_path.relative_to(ROOT)}")
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("download", help="download from the official UCI host and register").set_defaults(func=cmd_download)
    p_reg = sub.add_parser("register", help="register a zip you downloaded manually from the official page")
    p_reg.add_argument("--zip", required=True)
    p_reg.set_defaults(func=cmd_register)
    p_aud = sub.add_parser("audit", help="verify hashes and audit the data (read-only)")
    p_aud.add_argument("--nrows", type=int, default=None, help="audit only the first N rows (quick trial)")
    p_aud.set_defaults(func=cmd_audit)
    args = parser.parse_args(argv)
    try:
        return args.func(args)
    except dataset_io.DatasetError as exc:
        print(f"\nDATASET ERROR: {exc}", file=sys.stderr)
        return 2
    except (ValueError, OSError) as exc:
        print(f"\nERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
