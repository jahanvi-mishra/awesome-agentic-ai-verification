#!/usr/bin/env python3
"""Environment test for the G1 study (Google Colab CPU, also runs locally).

What it does
  1. Prints diagnostics (not graded): Python, OS, CPU, RAM, disk, Colab, seeds.
  2. Runs graded checks. Each is PASS, WARN or FAIL.
  3. Writes a text report, a JSON report and a `pip freeze` to logs/.
  4. Exits with code 1 only if something FAILED.

It does NOT download the dataset and does NOT touch data/raw.
Usage (from the project root):  python scripts/env_test.py [--network]
"""

from __future__ import annotations

import argparse
import datetime as dt
import importlib
import importlib.metadata as md
import importlib.util
import io
import json
import os
import platform
import re
import shutil
import subprocess
import sys
import tempfile
import traceback
import unittest
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, List, Optional, Tuple

PASS, WARN, FAIL = "PASS", "WARN", "FAIL"

MIN_PYTHON = (3, 10)        # below this: FAIL
UNTESTED_PYTHON = (3, 14)   # this or newer: WARN (not covered by the proposed dependency minimums)
RAM_FAIL_GB, RAM_WARN_GB = 2.0, 4.0
DISK_FAIL_GB, DISK_WARN_GB = 0.5, 2.0
# Major versions newer than what the project was written against -> WARN, not FAIL.
NEWER_MAJOR_WARN = {"numpy": 3, "pandas": 3, "matplotlib": 4}
REQUIRED_DIRS = ["configs", "src", "scripts", "tests", "notebooks", "data/raw", "data/interim",
                 "data/processed", "results/figures", "results/tables", "results/runs",
                 "logs", "docs", "paper"]

Outcome = Tuple[str, str, str]  # (status, detail, hint)


@dataclass
class Result:
    name: str
    status: str
    detail: str
    hint: str = ""


# ----------------------------------------------------------------- helpers
def version_tuple(text: str) -> Tuple[int, ...]:
    """'2.2.3rc1' -> (2, 2, 3). Only the first three numeric parts are compared."""
    return tuple(int(p) for p in re.findall(r"\d+", text)[:3])


def read_requirements(path: Path) -> List[Tuple[str, str]]:
    """Parse lines like 'numpy>=1.26' into [('numpy', '1.26')]. Comments are skipped."""
    pairs = []
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.split("#", 1)[0].strip()
        if not line:
            continue
        m = re.match(r"^([A-Za-z0-9_.\-]+)\s*(?:>=|==)\s*([0-9][0-9.]*)$", line)
        if not m:
            raise ValueError(f"Cannot parse requirement line: {line!r}")
        pairs.append((m.group(1), m.group(2)))
    return pairs


def read_meminfo_gb() -> Optional[Tuple[float, float]]:
    """(total_gb, available_gb) from /proc/meminfo; None if not available (non-Linux)."""
    try:
        info = {}
        for line in Path("/proc/meminfo").read_text().splitlines():
            key, rest = line.split(":", 1)
            info[key] = int(rest.split()[0])  # kB
        return info["MemTotal"] / 1024**2, info.get("MemAvailable", info["MemTotal"]) / 1024**2
    except (OSError, KeyError, ValueError):
        return None


def in_colab() -> bool:
    try:
        return importlib.util.find_spec("google.colab") is not None
    except (ImportError, ValueError):
        return False


# ----------------------------------------------------------------- graded checks
def check_python() -> Outcome:
    v = sys.version_info[:3]
    text = ".".join(map(str, v))
    if v < MIN_PYTHON + (0,):
        return FAIL, f"Python {text} is older than {MIN_PYTHON[0]}.{MIN_PYTHON[1]}", \
            "Use a newer Colab runtime (Runtime > Change runtime type) or install a newer Python."
    if v[:2] >= UNTESTED_PYTHON:
        return WARN, f"Python {text} is newer than the range this project was written for", \
            "Probably fine, but wheels for some packages may lag. Rely on the unit tests below."
    return PASS, f"Python {text}", ""


def check_64bit() -> Outcome:
    bits = 64 if sys.maxsize > 2**32 else 32
    return (PASS, "64-bit interpreter", "") if bits == 64 else \
        (WARN, "32-bit interpreter: large data frames may fail", "Use a 64-bit Python.")


def check_ram() -> Outcome:
    mem = read_meminfo_gb()
    if mem is None:
        return WARN, "Could not read /proc/meminfo (not Linux?)", "Check memory manually."
    total, avail = mem
    detail = f"total {total:.1f} GB, available {avail:.1f} GB"
    if total < RAM_FAIL_GB:
        return FAIL, detail, "Too little RAM for the 541,909-row dataset. Use a standard Colab runtime."
    if total < RAM_WARN_GB:
        return WARN, detail, "Tight. Reading the Excel file may be slow or fail."
    return PASS, detail, ""


def check_disk(root: Path) -> Outcome:
    free = shutil.disk_usage(root).free / 1024**3
    detail = f"{free:.1f} GB free at {root}"
    if free < DISK_FAIL_GB:
        return FAIL, detail, "Free some space (Colab: Runtime > Disconnect and delete runtime)."
    if free < DISK_WARN_GB:
        return WARN, detail, "Low. The dataset zip is about 23 MB, so this is still workable."
    return PASS, detail, ""


def check_dependencies(root: Path) -> Outcome:
    req_file = root / "requirements.txt"
    if not req_file.is_file():
        return FAIL, f"{req_file} not found", "Run from the project root; check that the zip was fully extracted."
    problems, warns, ok = [], [], []
    for pkg, minimum in read_requirements(req_file):
        try:
            installed = md.version(pkg)
        except md.PackageNotFoundError:
            problems.append(f"{pkg} missing (need >= {minimum})")
            continue
        if version_tuple(installed) < version_tuple(minimum):
            problems.append(f"{pkg} {installed} < required {minimum}")
            continue
        newer = NEWER_MAJOR_WARN.get(pkg.lower())
        if newer and version_tuple(installed)[0] >= newer:
            warns.append(f"{pkg} {installed} is a newer major version than the project was written against")
        ok.append(f"{pkg} {installed}")
    detail = "; ".join(ok)
    if problems:
        return FAIL, "; ".join(problems), "pip install -q -r requirements.txt  (then re-run)"
    if warns:
        return WARN, detail + " | " + "; ".join(warns), "Run the remaining checks and unit tests; they decide if it is usable."
    return PASS, detail, ""


def check_imports(root: Path) -> Outcome:
    failed = []
    for mod in ("numpy", "pandas", "matplotlib", "openpyxl", "pytest", "g1.seeding"):
        try:
            importlib.import_module(mod)
        except Exception as exc:  # noqa: BLE001 - we want every import problem reported
            failed.append(f"{mod}: {type(exc).__name__}: {exc}")
    if failed:
        return FAIL, " | ".join(failed), "Reinstall the package; for numpy/pandas binary errors restart the runtime."
    return PASS, "numpy, pandas, matplotlib, openpyxl, pytest, g1.seeding import cleanly", ""


def check_dirs_writable(root: Path) -> Outcome:
    missing, unwritable = [], []
    for rel in REQUIRED_DIRS:
        d = root / rel
        if not d.is_dir():
            missing.append(rel)
            continue
        try:
            with tempfile.NamedTemporaryFile(dir=d, prefix=".env_write_test_", delete=True) as fh:
                fh.write(b"x")
        except OSError as exc:
            unwritable.append(f"{rel} ({exc})")
    if missing or unwritable:
        parts = []
        if missing:
            parts.append("missing: " + ", ".join(missing))
        if unwritable:
            parts.append("not writable: " + ", ".join(unwritable))
        return FAIL, "; ".join(parts), "Re-extract the zip; if on Drive, check it is mounted and has space."
    return PASS, f"all {len(REQUIRED_DIRS)} project folders exist and are writable", ""


def check_seed_controls(root: Path) -> Outcome:
    from g1 import seeding
    cfg = seeding.load_seed_config(root / "configs" / "seeds.json")
    seeds = seeding.derive_seeds(cfg["master_seed"], cfg["offsets"])
    a = seeding.make_all_rngs(cfg["master_seed"], cfg["offsets"])
    b = seeding.make_all_rngs(cfg["master_seed"], cfg["offsets"])
    for name in a:
        if not (a[name].integers(0, 10**9, 50) == b[name].integers(0, 10**9, 50)).all():
            return FAIL, f"stream '{name}' is not reproducible", "Check numpy installation."
    if len(set(seeds.values())) != len(seeds):
        return FAIL, "sub-seeds are not distinct", "Fix offsets in configs/seeds.json."
    return PASS, f"master {cfg['master_seed']}, sub-seeds {seeds}; repeated runs identical", ""


def check_numpy() -> Outcome:
    import numpy as np
    assert np.isclose(sum([0.1] * 10), 1.0), "float sum"
    assert np.percentile(np.arange(1, 102), 90) == 91.0, "90th percentile (linear)"
    arr = np.array([1.0, np.nan, 3.0])
    assert np.isnan(arr).sum() == 1 and np.nanmax(arr) == 3.0, "NaN handling"
    assert float(np.dot([1, 2, 3], [4, 5, 6])) == 32.0, "dot product"
    return PASS, f"numpy {np.__version__}: arithmetic, NaN handling, percentile OK", ""


def check_pandas() -> Outcome:
    import pandas as pd
    df = pd.DataFrame({"InvoiceNo": ["A1", "A1", "A2"], "Quantity": [2, 1, 6], "UnitPrice": [3.50, 1.25, 0.50]})
    df["LineAmount"] = (df["Quantity"] * df["UnitPrice"]).round(2)
    totals = df.groupby("InvoiceNo")["LineAmount"].sum().round(2)
    assert totals["A1"] == 8.25 and totals["A2"] == 3.00, f"invoice totals wrong: {totals.to_dict()}"
    assert pd.api.types.is_integer_dtype(df["Quantity"]), "Quantity should be integer"
    coerced = pd.to_numeric(pd.Series(["5", "abc", None]), errors="coerce")  # T1/T2-style bad values
    assert coerced.isna().sum() == 2 and coerced.iloc[0] == 5, "to_numeric coerce"
    assert pd.to_datetime("2010-12-01 08:26:00").year == 2010, "datetime parsing"
    return PASS, f"pandas {pd.__version__}: invoice totals, dtype, coercion, datetime OK", ""


def check_excel_roundtrip(root: Path) -> Outcome:
    import pandas as pd
    df = pd.DataFrame({"InvoiceNo": ["536365", "C536379"], "Quantity": [6, -1], "UnitPrice": [2.55, 27.5]})
    with tempfile.TemporaryDirectory(dir=root / "logs") as tmp:
        path = Path(tmp) / "roundtrip.xlsx"
        df.to_excel(path, index=False, engine="openpyxl")
        back = pd.read_excel(path, engine="openpyxl", dtype={"InvoiceNo": str})
    assert list(back.columns) == list(df.columns) and len(back) == 2, "shape/columns changed"
    assert back["InvoiceNo"].tolist() == ["536365", "C536379"], "InvoiceNo must stay text"
    return PASS, "xlsx write+read via openpyxl OK (the real dataset is an .xlsx; not downloaded here)", ""


def check_matplotlib(root: Path) -> Outcome:
    import matplotlib
    matplotlib.use("Agg")  # no display needed
    import matplotlib.pyplot as plt
    out = root / "results" / "figures" / "_env_test_plot.png"
    fig, ax = plt.subplots(figsize=(3, 2))
    ax.plot([0, 1, 2], [0, 1, 4])
    fig.savefig(out)
    plt.close(fig)
    try:
        size = out.stat().st_size
        assert size > 0, "empty PNG"
    finally:
        out.unlink(missing_ok=True)
    return PASS, f"matplotlib {matplotlib.__version__}: PNG written ({size} bytes) and removed", ""


def check_unit_tests(root: Path) -> Outcome:
    suite = unittest.TestLoader().discover(str(root / "tests"), top_level_dir=str(root / "tests"))
    stream = io.StringIO()
    res = unittest.TextTestRunner(stream=stream, verbosity=0).run(suite)
    if res.testsRun == 0:
        return FAIL, "no unit tests were found in tests/", "Check that tests/test_seeding.py exists."
    if not res.wasSuccessful():
        return FAIL, f"{len(res.failures)} failure(s), {len(res.errors)} error(s) of {res.testsRun}", stream.getvalue()[-600:]
    return PASS, f"{res.testsRun} unit tests passed", ""


def check_persistence(root: Path) -> Outcome:
    if not in_colab():
        return PASS, "not running in Colab; persistence is not a Colab concern here", ""
    if str(root.resolve()).startswith("/content/drive"):
        return PASS, "project is on Google Drive (survives runtime reset)", ""
    return WARN, f"project is at {root}, NOT on Google Drive", \
        "Files vanish when the Colab runtime recycles. Mount Drive and keep the project there, or download results often."


def check_network() -> Outcome:
    import urllib.request
    url = "https://archive.ics.uci.edu/dataset/352/online+retail"
    try:
        req = urllib.request.Request(url, method="HEAD", headers={"User-Agent": "g1-env-test"})
        with urllib.request.urlopen(req, timeout=15) as r:
            return PASS, f"HTTP {r.status} from UCI dataset page (headers only, nothing downloaded)", ""
    except Exception as exc:  # noqa: BLE001
        return WARN, f"could not reach UCI page: {type(exc).__name__}: {exc}", \
            "Not fatal. Retry later or download the file manually in your browser and upload it."


# ----------------------------------------------------------------- driver
def run(name: str, fn: Callable[[], Outcome]) -> Result:
    try:
        status, detail, hint = fn()
    except Exception as exc:  # noqa: BLE001 - a crashing check is itself a FAIL
        tb = traceback.format_exc().strip().splitlines()[-1]
        status, detail, hint = FAIL, f"check crashed: {tb}", "See the message above; reinstall the related package."
    return Result(name, status, detail, hint)


def diagnostics(root: Path) -> dict:
    mem = read_meminfo_gb()
    from g1 import seeding
    return {
        "python": sys.version.replace("\n", " "),
        "executable": sys.executable,
        "platform": platform.platform(),
        "machine": platform.machine(),
        "cpu_count": os.cpu_count(),
        "ram_total_gb": round(mem[0], 2) if mem else None,
        "in_colab": in_colab(),
        "colab_release_tag": os.environ.get("COLAB_RELEASE_TAG"),
        "cwd": os.getcwd(),
        "project_root": str(root),
        "hashseed": seeding.hashseed_status(),
        "utc_time": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"),
    }


def main(argv: Optional[List[str]] = None) -> int:
    parser = argparse.ArgumentParser(description="G1 environment test")
    parser.add_argument("--network", action="store_true", help="also test reachability of the UCI page (HEAD request only)")
    parser.add_argument("--project-root", default=str(Path(__file__).resolve().parents[1]))
    args = parser.parse_args(argv)

    root = Path(args.project_root).resolve()
    sys.path.insert(0, str(root / "src"))
    (root / "logs").mkdir(exist_ok=True)

    lines: List[str] = []

    def out(text: str = "") -> None:
        print(text)
        lines.append(text)

    diag = diagnostics(root)
    out("=== G1 ENVIRONMENT TEST ===")
    out("--- Diagnostics (not graded) ---")
    for k, v in diag.items():
        out(f"{k:18s}: {v}")

    checks: List[Tuple[str, Callable[[], Outcome]]] = [
        ("python_version", check_python),
        ("python_64bit", check_64bit),
        ("ram", check_ram),
        ("disk", lambda: check_disk(root)),
        ("dependencies", lambda: check_dependencies(root)),
        ("imports", lambda: check_imports(root)),
        ("project_dirs_writable", lambda: check_dirs_writable(root)),
        ("seed_controls", lambda: check_seed_controls(root)),
        ("numpy_ops", check_numpy),
        ("pandas_ops", check_pandas),
        ("excel_roundtrip", lambda: check_excel_roundtrip(root)),
        ("matplotlib_png", lambda: check_matplotlib(root)),
        ("unit_tests", lambda: check_unit_tests(root)),
        ("drive_persistence", lambda: check_persistence(root)),
    ]
    if args.network:
        checks.append(("network_uci_page", check_network))

    out("--- Graded checks ---")
    results = [run(n, f) for n, f in checks]
    for r in results:
        out(f"[{r.status}] {r.name}: {r.detail}")
        if r.hint and r.status != PASS:
            out(f"       hint: {r.hint}")

    counts = {s: sum(r.status == s for r in results) for s in (PASS, WARN, FAIL)}
    overall = FAIL if counts[FAIL] else WARN if counts[WARN] else PASS
    out("--- Summary ---")
    out(f"PASS={counts[PASS]}  WARN={counts[WARN]}  FAIL={counts[FAIL]}  =>  OVERALL: {overall}")
    out("This result describes THIS runtime at THIS time only.")

    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    logs = root / "logs"
    (logs / f"env_check_{stamp}.txt").write_text("\n".join(lines) + "\n", encoding="utf-8")
    (logs / f"env_check_{stamp}.json").write_text(
        json.dumps({"diagnostics": diag, "results": [asdict(r) for r in results], "overall": overall}, indent=2),
        encoding="utf-8")
    try:
        freeze = subprocess.run([sys.executable, "-m", "pip", "freeze"], capture_output=True, text=True, timeout=120)
        (logs / f"pip_freeze_{stamp}.txt").write_text(freeze.stdout, encoding="utf-8")
        print(f"Saved: logs/env_check_{stamp}.txt, .json, pip_freeze_{stamp}.txt")
    except (OSError, subprocess.SubprocessError) as exc:
        print(f"Saved reports; pip freeze skipped ({exc})")
    return 1 if overall == FAIL else 0


if __name__ == "__main__":
    sys.exit(main())
