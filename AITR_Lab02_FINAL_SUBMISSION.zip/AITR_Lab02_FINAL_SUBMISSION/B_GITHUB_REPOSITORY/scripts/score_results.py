#!/usr/bin/env python3
"""Compute metrics M1-M11 and tables R1-R9 from a finished pilot or evaluation run. Writes CSV files, runs nothing.

  python scripts/score_results.py [pilot|evaluation]

Reads results/<subset>/{manifest.json, manifest.sha256, runs.jsonl, labels.jsonl} (and optionally
results/predictions.json: {"T1": true, ...} = predicted to escape F). Writes results/<subset>/metrics/*.csv once.
"""

from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from g1 import faults, metrics, protocol  # noqa: E402


def _read_jsonl(path: Path):
    return [json.loads(l) for l in path.read_text(encoding="utf-8").splitlines() if l.strip()]


def _fmt(v):
    return "" if v is None else (f"{v:.6f}" if isinstance(v, float) else v)


def write_csv(path: Path, rows) -> None:
    fields = list(rows[0].keys()) if rows else ["(no rows)"]
    with open(path, "x", encoding="utf-8", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: _fmt(v) for k, v in r.items()})


def score(root: Path, subset: str, proto: dict, resamples: int = metrics.RESAMPLES) -> dict:
    src = root / "results" / subset
    out = src / "metrics"
    if out.exists() and any(out.iterdir()):
        raise FileExistsError(f"{out} already has files; not overwriting.")
    manifest = json.loads((src / "manifest.json").read_text(encoding="utf-8"))
    if faults.manifest_hash(manifest) != (src / "manifest.sha256").read_text().strip():
        raise ValueError("manifest.json does not match manifest.sha256; refusing to score")
    pred_path = root / "results" / "predictions.json"
    predictions = json.loads(pred_path.read_text(encoding="utf-8")) if pred_path.is_file() else None
    tables = metrics.compute(manifest, _read_jsonl(src / "runs.jsonl"), _read_jsonl(src / "labels.jsonl"),
                             proto["seeds"], predictions, resamples)
    out.mkdir(parents=True, exist_ok=True)
    for name, rows in tables.items():
        write_csv(out / f"{name}.csv", rows)
    return {"subset": subset, "files": sorted(p.name for p in out.iterdir()), "predictions_used": predictions is not None}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("subset", nargs="?", default="evaluation", choices=("pilot", "evaluation"))
    args = ap.parse_args(argv)
    try:
        res = score(ROOT, args.subset, protocol.load_protocol(ROOT))
    except (OSError, ValueError, KeyError) as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    print(json.dumps(res, indent=1))
    if args.subset == "pilot":
        print("Note: pilot scores are for debugging only, not for conclusions.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
