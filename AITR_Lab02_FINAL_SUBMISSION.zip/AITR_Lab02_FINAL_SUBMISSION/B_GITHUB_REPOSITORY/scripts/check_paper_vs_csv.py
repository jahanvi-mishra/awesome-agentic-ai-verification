"""READ-ONLY (added in v5): check that the numbers printed in the manuscript source equal the stored metric CSVs.
Usage (project root): python scripts/check_paper_vs_csv.py
Checks Tables 4 and 5, the cost and false-alarm figures and the case composition. It does not regenerate anything."""
import csv, re, sys
from pathlib import Path
ROOT = Path(__file__).resolve().parents[1]
M = ROOT / "results" / "stored_evaluation" / "metrics"
paper = (ROOT / "paper" / "manuscript_rev5_2_1_src.md").read_text(encoding="utf-8")
rows = lambda f: list(csv.DictReader(open(M / f, encoding="utf-8")))
fails, n = [], 0
def need(label, text):
    global n; n += 1
    if text not in paper: fails.append((label, text))
r1 = {r["condition"]: r for r in rows("R1_primary.csv")}
for c in "FI":
    k = int(r1[c]["reached_commit_n"]); N = int(r1[c]["harmful_N"])
    need(f"R1 {c} count", f"{k:,} / {N:,}")
    need(f"R1 {c} rate", f"{100*float(r1[c]['M1_rate']):.2f}%")
need("R1 F interval", f"{100*float(r1['F']['ci_low']):.2f}% to {100*float(r1['F']['ci_high']):.2f}%")
need("R1 difference", f"{100*(float(r1['F']['M1_rate'])-float(r1['I']['M1_rate'])):.2f} percentage points")
for r in rows("R2_per_type.csv"):
    need(f"R2 {r['type']} F reached", f"| {r['type']} | {r['F_reached_n']} ({float(r['F_reached_pct']):.1f}%)")
    need(f"R2 {r['type']} injected", "500 injected cases each") if r["injected"] == "500" else fails.append((r["type"], "injected != 500"))
for r in rows("R6_cost.csv"):
    if r["condition"] in ("F", "I"):
        need(f"R6 {r['condition']} total", f"{int(r['total_rule_applications']):,}")
        need(f"R6 {r['condition']} mean", f"{float(r['mean_per_run']):.2f}")
need("R6 ratio", f"{float(next(r for r in rows('R6_cost.csv') if r['condition']=='I')['ratio_to_F']):.2f}")
for r in rows("R5_clean_false_alarms.csv"):
    need(f"R5 {r['condition']} halted", "Ten of 500 clean cases") if r["halted"] == "10" else fails.append((r["condition"], "halted != 10"))
r5 = rows("R5_clean_false_alarms.csv")[0]
need("R5 Wilson", f"{100*float(r5['ci_low']):.2f}% to {100*float(r5['ci_high']):.2f}%")

# Wilson 95% interval per type (F) recomputed from the counts, compared with Table 5
def wilson(k, n, z=1.959964):
    p = k / n; d = 1 + z*z/n; c = (p + z*z/(2*n)) / d; h = z*((p*(1-p)/n + z*z/(4*n*n))**0.5) / d
    return c - h, c + h
for r in rows("R2_per_type.csv"):
    lo, hi = wilson(int(r["F_reached_n"]), 500)
    need(f"Wilson {r['type']}", f"{100*lo:.1f}% to {100*hi:.1f}%")
# halting attribution (R4) and first failing rules (R4b)
for r in rows("R4_halting_attribution.csv"):
    cp = [c for c in ("CP1", "CP2", "CP3", "FINAL") if r[c] != "0"]
    need(f"R4 {r['type']}", f"| {r['type']} |" ) 
    for c in cp: need(f"R4 {r['type']} {c}", f"{c if c != 'FINAL' else 'Final'} ({r[c]})") if c != "FINAL" else None

# run-level classification values and rule-application split (restored in the paper, Section 6.3)
ms = {(r["metric"], r["scope"]): r for r in rows("metrics_summary.csv")}
for c in "FI":
    tp = int(ms[("M3", c)]["numerator"]); harm = int(ms[("M3", c)]["denominator"]); fp = int(ms[("M4", c)]["numerator"]); clean = int(ms[("M4", c)]["denominator"])
    fn, tn = harm - tp, clean - fp
    need(f"TP {c}", f"TP {tp:,}" if c == "I" else f"TP {tp:,}, FN {fn:,}, FP {fp}, TN {tn}")
    need(f"precision {c}", f"{100*tp/(tp+fp):.2f}%"); need(f"accuracy {c}", f"{100*(tp+tn)/(harm+clean):.2f}%"); need(f"F1 {c}", f"{100*2*tp/(2*tp+fp+fn):.2f}%")
cj = rows("cases_joined.csv")
def mean(rs, k): return sum(int(r[k]) for r in rs) / len(rs)
for c, hal, com in (("I", "61.19", "123.74"), ("F", "3.01", "6.00")):
    h = [r for r in cj if r["out_" + c] == "HALTED"]; k = [r for r in cj if r["out_" + c] == "COMMITTED"]
    need(f"mean apps halted {c}", hal); need(f"mean apps committed {c}", com)
    assert f"{mean(h, 'apps_' + c):.2f}" == hal and f"{mean(k, 'apps_' + c):.2f}" == com, (c, mean(h, 'apps_' + c), mean(k, 'apps_' + c))
extraI = sum(int(r["apps_I"]) - int(r["apps_F"]) for r in cj); clean_extra = sum(int(r["apps_I"]) - int(r["apps_F"]) for r in cj if r["fault_type"] == "CLEAN")
need("extra apps", f"{extraI:,}"); need("extra apps clean", f"{clean_extra:,}"); need("extra apps harmful", f"{extraI-clean_extra:,}")
for r in rows("R4b_halting_by_rule.csv"):
    need(f"R4b {r['rule_id']}", f"{r['rule_id']} ({r['count']})")
print(f"{n} checks, {len(fails)} failures")
for f in fails: print("FAIL", f)
sys.exit(1 if fails else 0)
