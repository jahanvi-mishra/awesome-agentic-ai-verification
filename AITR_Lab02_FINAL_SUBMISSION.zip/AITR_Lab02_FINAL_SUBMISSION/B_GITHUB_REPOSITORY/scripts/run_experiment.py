#!/usr/bin/env python3
"""Prepare data, run the pilot, or run the (single) evaluation. Run from the project root.

  python scripts/run_experiment.py prepare                      raw xlsx -> pool -> splits -> calibration constants
  python scripts/run_experiment.py pilot                        run B0, F, I on the 50 pilot invoices (debugging only)
  python scripts/run_experiment.py evaluate --confirm-freeze    THE main run: refuses to run twice
  python scripts/run_experiment.py verify-rerun [pilot|evaluation]   determinism check: recompute in memory, compare, write nothing

The raw dataset is only read (hash-checked before and after). Existing outputs are never overwritten.
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import pandas as pd  # noqa: E402

from g1 import dataset_io, experiment, protocol  # noqa: E402

RAW_DIR = ROOT / "data" / "raw"


def cmd_prepare(_a, proto) -> int:
    manifest = dataset_io.verify_manifest(RAW_DIR)
    xlsx = RAW_DIR / manifest["xlsx_filename"]
    print(f"Hashes match. Reading {xlsx.name} read-only (several minutes)...")
    book = pd.ExcelFile(xlsx, engine="openpyxl")
    df = book.parse(book.sheet_names[0], dtype=object)
    out = experiment.prepare(df, ROOT, proto)
    dataset_io.verify_manifest(RAW_DIR)
    print(json.dumps(out, indent=1, default=str))
    print("Wrote data/interim/base_lines.csv, results/splits.json, results/constants_calibration.json")
    return 0


def cmd_run(args, proto) -> int:
    subset = "pilot" if args.command == "pilot" else "evaluation"
    if subset == "evaluation":
        if not args.confirm_freeze:
            print("Refusing: the evaluation is the single main run. Re-run with --confirm-freeze after the freeze.", file=sys.stderr)
            return 4
        if not (ROOT / "PROMPT07_FINAL_DECISIONS.txt").is_file():
            print("Refusing: PROMPT07_FINAL_DECISIONS.txt not found in the project root.", file=sys.stderr)
            return 4
    summary = experiment.run_subset(ROOT, proto, subset)
    print(json.dumps(summary, indent=1))
    return 0


def cmd_verify(args, proto) -> int:
    res = experiment.verify_rerun(ROOT, proto, args.subset)
    print(json.dumps(res, indent=1))
    return 0 if res["identical"] else 5


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    sub = ap.add_subparsers(dest="command", required=True)
    sub.add_parser("prepare")
    sub.add_parser("pilot")
    ev = sub.add_parser("evaluate")
    ev.add_argument("--confirm-freeze", action="store_true")
    vr = sub.add_parser("verify-rerun")
    vr.add_argument("subset", nargs="?", default="evaluation", choices=("pilot", "evaluation"))
    args = ap.parse_args(argv)
    try:
        proto = protocol.load_protocol(ROOT)
        if args.command == "prepare":
            return cmd_prepare(args, proto)
        return cmd_verify(args, proto) if args.command == "verify-rerun" else cmd_run(args, proto)
    except experiment.PoolCountMismatch as exc:
        print(f"POOL COUNT MISMATCH (stopped, nothing written): {exc}", file=sys.stderr)
        return 3
    except dataset_io.DatasetError as exc:
        print(f"DATASET ERROR: {exc}", file=sys.stderr)
        return 2
    except (OSError, ValueError, KeyError) as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
