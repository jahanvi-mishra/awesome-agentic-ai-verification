#!/usr/bin/env python3
"""Inspect a finished pilot run (read-only). Run from the project root:  python scripts/inspect_pilot.py [pilot|evaluation]

Exit code 0 = PASS or WARN only, 1 = at least one FAIL. Writes nothing; copy the output into the chat.
"""

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from g1 import pilot_check, protocol  # noqa: E402


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("subset", nargs="?", default="pilot", choices=("pilot", "evaluation"))
    args = ap.parse_args(argv)
    try:
        rep = pilot_check.inspect(ROOT, protocol.load_protocol(ROOT), args.subset)
    except (OSError, ValueError, KeyError) as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1
    for r in rep["checks"]:
        print(f"[{r['status']}] {r['check']}: {r['detail']}")
    print(f"OVERALL: {rep['overall']}  (subset: {rep['subset']})")
    print(json.dumps({"overall": rep["overall"], "counts": {s: sum(r['status'] == s for r in rep['checks']) for s in ('PASS', 'WARN', 'FAIL')}}))
    return 1 if rep["overall"] == "FAIL" else 0


if __name__ == "__main__":
    sys.exit(main())
