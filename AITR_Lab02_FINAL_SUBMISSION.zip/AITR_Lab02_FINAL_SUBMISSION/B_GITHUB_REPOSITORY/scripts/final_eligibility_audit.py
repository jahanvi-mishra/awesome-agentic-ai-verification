#!/usr/bin/env python3
"""Final dataset eligibility and fault-feasibility audit (read-only).

Run from the project root:   python scripts/final_eligibility_audit.py [--nrows N]

Steps: verify raw-file hashes against data/raw/SOURCE_MANIFEST.json -> read the xlsx (read-only, all
columns as text/objects) -> compute counts (src/g1/eligibility.py) -> verify hashes again ->
write logs/final_eligibility_audit_<UTC>.json and .md.

It creates no split, no manifest of cases and no pipeline. Nothing is removed from any data file.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from g1 import dataset_io, eligibility  # noqa: E402

RAW_DIR, LOGS_DIR = ROOT / "data" / "raw", ROOT / "logs"


def _json_default(o):
    if isinstance(o, np.integer):
        return int(o)
    if isinstance(o, np.floating):
        return None if np.isnan(o) else float(o)
    if isinstance(o, np.bool_):
        return bool(o)
    return str(o)


def _rows(d: dict) -> str:
    return "\n".join(f"| {k} | {v} |" for k, v in d.items())


def conclusions(rep: dict) -> dict:
    """Plain statements generated from the computed numbers only."""
    sc, T = rep["scenarios"], rep["t4_feasibility"]
    s1_cnt = sc["A_S1_prompt07_steps_1_to_3_no_dedupe"]
    out = {"calibration_pilot_evaluation_1550_feasible": {
        k: v["enough"] for k, v in rep["feasibility_1000_50_500"].items()}}
    out["t4_feasible_on_S1"] = T["on_S1"]["enough_for_500_all_t4_capable"]
    out["t4_share_of_S1_capable"] = T["on_S1"]["share_t4_capable"]
    t5 = rep["t5_feasibility"]["on_S1"]
    out["t5_feasible_on_S1"] = (t5.get("min_partners_different_customer", 0) > 0 and t5.get("min_partners_different_total", 0) > 0)
    enough_all = all(out["calibration_pilot_evaluation_1550_feasible"].values())
    out["recommendation"] = (
        "Counts support the planned sizes under every scenario A-E; Prompt 07 can be frozen as v1.0 once the approval items are decided."
        if enough_all and out["t4_feasible_on_S1"] and out["t5_feasible_on_S1"] else
        "Do NOT freeze yet: at least one scenario, T4 or T5 requirement is not met (see feasibility section); "
        "reduce counts or switch dataset and record a new protocol version (v0.3).")
    out["S1_count"] = s1_cnt
    return out


def render_markdown(rep: dict, manifest: dict, meta: dict, concl: dict) -> str:
    il, rl, d, rp = rep["invoice_level"], rep["row_level"], rep["dates"], rep["repeated_rows"]
    L = ["# Final eligibility and fault-feasibility audit (Online Retail, ID 352)", "",
         f"Run (UTC): {meta['run_utc']}  |  Scope: {meta['scope']}", "",
         "## 1. Raw file integrity",
         f"- xlsx: {manifest['xlsx_filename']}  sha256 `{manifest['xlsx_sha256']}`",
         f"- hashes matched the manifest before and after reading; raw files not modified: {meta['hashes_ok']}", "",
         "## 2. Row-level counts", "| item | rows |", "|---|---|", _rows({k: v for k, v in rl.items()}), "",
         "## 3. Invoice-level counts", "| item | invoices |", "|---|---|",
         _rows({k: v for k, v in il.items() if not k.endswith("examples") and k != "lines_per_invoice_in_S1"}),
         f"| non-6-digit examples (non-cancelled) | {il['non_6_digit_examples']} |",
         f"| non-6-digit examples (in S1) | {il['S1_non_6_digit_examples']} |",
         f"| lines per S1 invoice (min/median/max/mean) | {il['lines_per_invoice_in_S1']} |", "",
         "## 4. Multiple dates and repeated rows", "| item | value |", "|---|---|", _rows(d), _rows(rp), "",
         "## 5. Duplicate invoice contents (nothing removed)", rep["duplicate_invoice_contents"]["6_signature_definition"], "",
         "| signature | invoices checked | duplicate groups | invoices in groups | extra invoices | largest group |", "|---|---|---|---|---|---|"]
    for k in ("lines_signature", "full_signature"):
        s = rep["duplicate_invoice_contents"][k]
        L.append(f"| {k} | {s['invoices_checked']} | {s['duplicate_groups']} | {s['invoices_in_duplicate_groups']} | "
                 f"{s['extra_invoices_if_one_kept_per_group']} | {s['largest_group_size']} |")
    L += ["", "## 6. Scenarios (counts only; invoices remaining)", "| scenario | invoices | >= 1,550 |", "|---|---|---|"]
    for k, v in rep["feasibility_1000_50_500"].items():
        L.append(f"| {k} | {v['invoices']} | {'yes' if v['enough'] else 'NO'} |")
    L += ["", "Effect of each filter alone on S1:", "| filter | removed | remaining |", "|---|---|---|"]
    for k, v in rep["scenario_marginal_effect_on_S1"].items():
        L.append(f"| {k} | {v['removed_from_S1']} | {v['remaining']} |")
    L += ["", "## 7. T4 feasibility (>= 2 distinct unit prices)"]
    for k, v in rep["t4_feasibility"].items():
        L.append(f"- {k}: {v}")
    L += ["", "## 8. T5 feasibility (partner invoice with a different CustomerID / total)"]
    for k, v in rep["t5_feasibility"].items():
        L.append(f"- {k}: {v}")
    L += ["", "## 9. UnitPrice precision and integer-pence risk"]
    for k, v in rep["price_precision"].items():
        L += [f"**{k}**", "```", json.dumps(v, indent=1, default=_json_default), "```"]
    L += ["", "## 10. Cross-check with the Prompt 06 audit", f"- {rep['cross_check_prompt06_definition']['description']}: "
          f"**{rep['cross_check_prompt06_definition']['count_here']}** invoices",
          f"- Prompt 06 audit value (`candidate_pool.invoices_with_no_defect_and_customer_present`): **{meta['p06_value']}**",
          "- These two should match; if not, blank-text handling is the likeliest cause (this audit treats blank text as missing).", "",
          "## 11. Feasibility conclusion (generated from the numbers above)",
          f"- 1,000 + 50 + 500 = 1,550 invoices feasible per scenario: {concl['calibration_pilot_evaluation_1550_feasible']}",
          f"- T4 feasible (>= 500 capable invoices on S1): {concl['t4_feasible_on_S1']} (share capable: {concl['t4_share_of_S1_capable']})",
          f"- T5 feasible on S1: {concl['t5_feasible_on_S1']}",
          f"- Recommendation: {concl['recommendation']}", "",
          "## 12. Decisions still needing your approval",
          "1. Which scenario (A-E) is the official eligible pool, and whether to restrict invoice numbers to the 6-digit pattern.",
          "2. Treatment of duplicate-content invoices: keep all (state it as a limitation) or keep one per group, and which signature.",
          "3. Treatment of multiple-date invoices: keep, or exclude (InvoiceDate is not used by the pipeline).",
          "4. Price rounding to integer pence (half-up proposed) or restricting to prices exact in 2 decimals; zero-pence lines.",
          "5. Whether evaluation invoices must all be T4-capable (restrict the pool) or non-capable invoices are logged as in Prompt 07.",
          "6. Whether repeated exact rows inside an invoice are kept (they may be genuine repeated scans).", ""]
    return "\n".join(L)


def p06_value() -> object:
    """Candidate-pool number from the newest FULL Prompt 06 audit JSON, if present."""
    for path in sorted(LOGS_DIR.glob("dataset_audit_*.json"), reverse=True):
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError):
            continue
        if data.get("meta", {}).get("scope") == "FULL FILE":
            return data["facts"]["candidate_pool"]["invoices_with_no_defect_and_customer_present"]
    return "UNKNOWN (no full dataset_audit_*.json found in logs/)"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--nrows", type=int, default=None, help="trial on the first N rows only (report says PARTIAL)")
    args = ap.parse_args(argv)
    try:
        manifest = dataset_io.verify_manifest(RAW_DIR)
        xlsx = RAW_DIR / manifest["xlsx_filename"]
        print(f"Hashes match. Reading {xlsx.name} read-only (several minutes for the full file)...")
        book = pd.ExcelFile(xlsx, engine="openpyxl")
        df = book.parse(book.sheet_names[0], dtype=object, nrows=args.nrows)
        print(f"Read {len(df)} rows. Computing...")
        rep = eligibility.build_report(df)
        dataset_io.verify_manifest(RAW_DIR)   # raises if the raw files changed
    except dataset_io.DatasetError as exc:
        print(f"DATASET ERROR: {exc}", file=sys.stderr)
        return 2
    except (ValueError, OSError) as exc:
        print(f"ERROR: {type(exc).__name__}: {exc}", file=sys.stderr)
        return 1

    meta = {"run_utc": dataset_io.utc_now(), "hashes_ok": True, "p06_value": p06_value(),
            "scope": "FULL FILE" if args.nrows is None else f"PARTIAL: first {args.nrows} rows only (not the full file)"}
    concl = conclusions(rep)
    stamp = dt.datetime.now(dt.timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    LOGS_DIR.mkdir(exist_ok=True)
    js, md = LOGS_DIR / f"final_eligibility_audit_{stamp}.json", LOGS_DIR / f"final_eligibility_audit_{stamp}.md"
    js.write_text(json.dumps({"meta": meta, "manifest": manifest, "report": rep, "conclusions": concl},
                             indent=2, default=_json_default), encoding="utf-8")
    text = render_markdown(rep, manifest, meta, concl)
    md.write_text(text, encoding="utf-8")
    print(text)
    print(f"\nSaved: {md.relative_to(ROOT)} and {js.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
