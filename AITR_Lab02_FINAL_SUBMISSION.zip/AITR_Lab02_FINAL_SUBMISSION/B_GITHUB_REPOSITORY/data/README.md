# Data

**No raw data is stored in this repository.** The dataset is the UCI Machine Learning Repository
*Online Retail* data set (ID 352), D. Chen (2015), CC BY 4.0, doi:10.24432/C5BW33.
Page: https://archive.ics.uci.edu/dataset/352/online+retail

## How to obtain it (existing code, `scripts/dataset_audit.py`; commands NOT re-run during assembly)
```
python scripts/dataset_audit.py download                    # fetches only from archive.ics.uci.edu, writes data/raw/SOURCE_MANIFEST.json
python scripts/dataset_audit.py register --zip PATH_TO_ZIP  # fallback: you download the zip in a browser, the code registers a copy
python scripts/dataset_audit.py audit                       # read-only audit; writes logs/dataset_audit_<UTC>.md/.json
```
Full description: `docs/DATASET_ACCESS.md`. Raw files are written once and never overwritten; hashes are in `SOURCE_MANIFEST.json`.

## What the folders mean
| Folder | Content here | Note |
|---|---|---|
| `data/raw/` | empty (`.gitkeep`) | put the UCI file here via the commands above; do not commit it |
| `data/interim/`, `data/processed/` | empty | written by `prepare` |

## Recorded hashes (from the author's prompts; not recomputed here)
Raw XLSX `43465a06f2ccf7c8b5bd2892bc7defb52f97487934fe93b16ae4c3936424676d`, ZIP `f5385cbb54bbebf7196389109c6b0621faab0c304e3702548165e71c84aede8b`, base lines `67f95be8...`, split `c6bfe38c...`. Full values, sources and caveats: `docs/RECORDED_DATASET_HASHES.md`. The Colab `download` and `prepare` steps can compare against them (`docs/PREPARE_ONLY_COLAB_PLAN.md`).

## MISSING / NOT VERIFIED
- The original `SOURCE_MANIFEST.json` and the dataset audit report (the raw XLSX and ZIP hashes are recorded in the author's Prompt 12 text, see `docs/RECORDED_DATASET_HASHES.md`; they are not a manifest): **not available in the files supplied for assembly** (the Drive backup ZIP named in the brief was not in the workspace). Retrieval date: UNKNOWN.
- The eligibility counts (17,023 eligible invoices; 16,679 T4-capable) are recorded in the author's decisions file (`PROMPT07_FINAL_DECISIONS.txt`, items 1 and 11, recovered 2026-11-10) and are enforced by a count check in `prepare`; they have not been re-derived from the raw data here.
