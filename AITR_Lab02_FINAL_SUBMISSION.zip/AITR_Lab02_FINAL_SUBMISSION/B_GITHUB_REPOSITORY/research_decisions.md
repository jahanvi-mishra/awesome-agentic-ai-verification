# Research decisions

**Scope of this file.** Part A is the author's own decision log (`D-000` to `D-004`), copied word for word from the supplied PDF (original also in `docs/research_decisions_MNS2026004_original.pdf`). That log covers **Stages 1-2 only** (setup, scope of the earlier review paper, candidate gaps) and says "Last updated 2026-10-21". Part B lists later decisions **only where an existing project file records them**; the author's decision log after D-004 is not available, so nothing here is reconstructed. The 14 final protocol decisions were recovered by the author and are stored word for word in `PROMPT07_FINAL_DECISIONS.txt` (repository root). Status words follow the author's convention: VERIFIED / INFERRED / UNKNOWN.

## Part A. Author's decision log (verbatim text of the supplied PDF)

```text
Research Decisions: Designing Verification
Checkpoints to Mitigate Silent Errors in
Agentic AI Pipelines
Project: Designing Verification Checkpoints to Mitigate Silent Errors in Agentic AI Pipelines
Author: Jahanvi Mishra
Created: 2026-10-21 | Last updated: 2026-10-21



Conventions
   VERIFIED: checked directly against the supplied review PDF or an actual execution output cited in
   the Evidence / source field. A claim attributed to another paper is verified only as "what this review
   says" until the original publication has been checked.
   INFERRED: a plausible interpretation, proposed experiment, or provisional decision that still needs
   testing.
   UNKNOWN: evidence is missing; the information needed to resolve it is stated.
   Never record a paper, dataset, repository link, execution, experiment, or metric as verified without
   supporting evidence.
   Decision entries are append-only. If a decision changes, add a new entry that supersedes the earlier
   one instead of silently rewriting the decision history.
Stage tracker
             Stage                           Status                           Evidence

 1. Workspace, decision log,   Done for the current review   D-000, D-001
 review scope                  inventory

 2. Evidence-based gap         Done (candidate gaps only;    D-002, D-003, gap_matrix.md, Sections A-C
 identification                none selected as final)

 3. Literature-to-experiment   Not started                   D-002; primary-source verification remains
 mapping                                                     open

 4. Feasibility and novelty    Not started                   D-003; resources and novelty are UNKNOWN
 check

 5. Research questions and     Not started                   Candidate questions in gap_matrix.md,
 success criteria                                            Section B

 6. Verified baseline          Not started                   No baseline has been implemented or
                                                             executed

 7. Coding and experiments     Not started                   No experiment execution or results have been
                                                             supplied

 8. Manuscript and             Not started                   No implementation paper or reproducibility
 reproducibility                                             package has been completed




Entry template

D-XXX | YYYY-MM-DD | Stage | Title
   Decision:
   Reason:
   Evidence / source:
   Status: VERIFIED | INFERRED | UNKNOWN
   Alternatives considered:
   Next action:



Decision log

D-000 | 2026-10-21 | Setup | Working protocol
   Decision: Work in stages and label claims VERIFIED, INFERRED, or UNKNOWN. Keep the evidence
   behind each claim traceable.
   Reason: This prevents proposed research from being presented as completed work.
  Evidence / source: Supplied review PDF, Designing Verification Checkpoints to Mitigate Silent Errors
  in Agentic AI Pipelines. Assignment requirements should also be checked against the assignment
  PDF before final submission.
  Status: VERIFIED (the supplied review PDF was inspected); INFERRED (the protocol is a working
  process choice).
  Alternatives considered: Drafting a final implementation paper before checking feasibility and
  evidence (not chosen).
  Next action: Maintain separate researchdecisions.md and gapmatrix.md files.


D-001 | 2026-10-21 | Stage 1 | Scope of the existing review
  Decision: Treat the paper as a conceptual review and framework proposal about detecting and
  containing silent errors in multi-step agentic AI pipelines. It defines silent errors and error
  propagation (Section 3); proposes a five-layer checkpoint architecture (Section 4.2, Table 1);
  discusses risk-adaptive placement, deterministic versus model-based verification, and independent
  verification (Section 5); describes recovery actions (Section 6); compares related approaches (Section
  7, Table 2); presents the VCP-AI architecture and proposed evaluation metrics (Section 8, Figure 3
  and Equations 12-16); and outlines limitations and future research directions (Sections 9-10).
  Reason: These topics are explicitly present in the supplied paper. The review proposes a framework
  and conceptual metrics but does not report an executed experiment evaluating its own checkpoint
  framework.
  Evidence / source: Supplied review PDF, PDF pp. 1-7: Abstract and Sections 1-11; especially Section
  4.2 and Table 1 (p. 3), Section 7 and Table 2 (pp. 4-5), Section 8.1 and Equations 12-16 (p. 5), Sections
  9-10 (pp. 5-6), and Conclusion (p. 6). References are on PDF p. 8.
  Status: VERIFIED as a description of the review. Findings attributed to references [1]-[17] remain
  unverified against the original publications.
  Alternatives considered: Treating the review as an experimental study with established measured
  results (rejected because no completed experiment or numerical evaluation of the proposed
  framework is reported).
  Next action: Use the review to identify candidate gaps, then verify the relevant primary sources before
  relying on their findings.


D-002 | 2026-10-21 | Stage 2 | Current phase limited to workspace and gap
extraction
  Decision: Complete the review inventory, decision log, and five candidate research gaps only. Do not
  yet claim a final research gap, novelty, dataset, baseline, implementation, or experimental result.
  Reason: The review identifies several research directions, but the best implementable question
  depends on primary-source verification and information about available tools, time, and resources.
  Evidence / source: Supplied review PDF, Sections 9-10 (pp. 5-6), covering verifier failure, correlated
  errors, cost, nondeterminism, ground truth, standardized benchmarks, causal error-trace datasets,
  adaptive scheduling, fault injection, adversarial verification, and human intervention.
  Status: INFERRED (workflow decision); VERIFIED (the listed challenges and future directions are in
  the review).
  Alternatives considered: Immediately implementing a full agent framework or learned checkpoint
  scheduler (not chosen because feasibility and baseline are not established).
  Next action: Compare the candidates in gap_matrix.md and map a feasible candidate to primary
  literature and a small experiment.


D-003 | 2026-10-21 | Stage 2 | Candidate gaps and provisional ranking
  Decision: Keep five candidates: G1 fault-injection measurement of checkpoint effectiveness; G2
  deterministic checks versus model-based verification; G3 correlated verifier errors; G4 risk-adaptive
  versus uniform checkpoint placement; and G5 error propagation and recovery using execution traces.
  Provisional top three: G1, G2, and G4.
  Reason: Fault-injection testing is proposed in Section 10.4; deterministic and model-based
  verification are compared in Section 5.2; correlated failures are discussed in Section 9.2; risk-
  adaptive placement is developed in Section 5.1 and proposed again in Section 10.3; and causal error-
  trace datasets are proposed in Section 10.2. The ranking is provisional and assumes a small controlled
  experiment is acceptable.
  Evidence / source: Supplied review PDF: Section 5.1, Equations 7-9 (p. 3); Section 5.2 (p. 3); Section
  9.2 (p. 5); Sections 10.2-10.4 (p. 6). Details are in gap_matrix.md, Sections B-C.
  Status: VERIFIED (the review discusses these topics); INFERRED (the gap framing and ranking).
  Alternatives considered: Starting with correlated verifier errors or full causal-trace construction
  (deferred because these may require more careful experimental controls or a more involved dataset).
  Next action: Check primary publications and confirm the available coding environment, model/API
  access, and time before selecting a research question.


D-004 | 2026-10-21 | Stage 2 | Points requiring editorial or mathematical
clarification
  Decision: Record possible issues for verification rather than silently correcting the source paper.
  Table 1 describes five checkpoint layers while Figure 3 labels six checkpoints; Equation 2 omits
  ROLLBACK although Section 6 and Figure 2 discuss it; symbol I is used for checkpoint information in
  Equation 7 and impact in Equation 8; and Section 7.6 says "most methods concentrate on output-
  stage verification," which should be checked against Table 2.
  Reason: These are observable differences or possible ambiguities. Some may have reasonable
  explanations, so they should not automatically be treated as confirmed technical errors.
  Evidence / source: Table 1 and Equations 7-9 (p. 3); Figure 2 and Section 6 (p. 4); Table 2 and Section
  7.6 (p. 5); Figure 3 (p. 5).
  Status: VERIFIED that these representations appear in the indicated locations; INFERRED that they
  may need clarification.
  Alternatives considered: Treating every difference as a confirmed error (not chosen without checking
  the intended definitions).
  Next action: If revising the review, clarify these points against the intended framework. They are
  editorial checks, not automatically separate research gaps.
Evidence ledger (summary)
                           Claim                                    Tag                  Source

The paper defines silent errors as incorrect intermediate     VERIFIED        Section 3.1, p. 2
decisions, actions, observations, assumptions, or state
transitions that continue undetected

The paper proposes a five-layer verification architecture     VERIFIED        Section 4.2 and Table 1, p. 3

Figure 3 labels six checkpoints across intent, planning,      VERIFIED        Section 8, Figure 3, p. 5
action, observation, state, and outcome

The paper discusses risk-adaptive checkpoint placement        VERIFIED        Section 5.1, Equations 7-9, p.
                                                                              3

The paper proposes detection recall, false-positive rate,     VERIFIED        Section 8.1, Equations 12-16,
containment rate, verification overhead, and silent-error                     p. 5
rate

The paper reports measured results from a completed           UNKNOWN / not   Sections 8-11, pp. 5-7
experiment evaluating its own framework                       evidenced

Fault-injection testing is proposed as a future direction     VERIFIED        Section 10.4, p. 6

Claims attributed to references [1]-[17] match the original   UNKNOWN         References, PDF p. 8;
publications                                                                  primary sources not checked

A small fault-injection experiment is the most feasible       INFERRED        Candidate comparison in
starting point                                                                gap_matrix.md, Sections B-C

Novelty of any candidate has been established                 UNKNOWN         Requires a separate literature
                                                                              search




Open UNKNOWNs
  Available programming environment and whether Google Colab or a local Python environment is
  preferred.
  Whether an LLM API, local model, or agent framework is available and whether usage has cost or
  access limits.
  Time available for implementation and writing.
  Whether the assignment accepts a controlled Python simulation or requires a working LLM agent.
  Access to original publications and benchmark resources.
  Whether existing work has already tested the exact candidate question; novelty is not established.
  Which injected faults can be defined with reliable ground-truth labels.
  Whether the assignment specifies any additional output files or naming requirements.
Next actions
1. Confirm assignment requirements, available tools, model/API access, and time.
2. Verify the original publications relevant to the selected gap, beginning with process supervision [10]
  and LLM-as-a-judge [14] if they remain relevant.
3. Select one research question and define its baseline, fault types, ground-truth labels, and success
  metrics before coding.
4. Implement and run a small baseline, recording the actual settings, outputs, and failures.
5. Conduct a separate literature search before making a novelty claim and prepare a reproducible
  implementation paper only after obtaining evidence.
```

## Part B. Later decisions recorded elsewhere (not in the log above)

| Decision | Where recorded | Status |
|---|---|---|
| Study G1: fault-injection measurement of checkpoint effectiveness (one of the five candidates in D-003) | Manuscript title and abstract (`paper/`) | VERIFIED that the manuscript studies G1; the selection decision entry itself is not in Part A |
| Use a deterministic four-stage Python simulation, **not** an LLM agent; dataset UCI Online Retail ID 352; conditions B0 / F / I; faults T1-T5 | `README.md`, `paper/manuscript_rev5_2_1_src.md` Sections 1, 5 | VERIFIED as stated design; the approval record is UNKNOWN |
| Fourteen final decisions (Scenario D pool 17,023; T4-capable 16,679; split 1,000/50/500; B0/F/I; etc.) | **`PROMPT07_FINAL_DECISIONS.txt`** in the repository root, recovered by the author from her Downloads folder (sha256 `abbe90370a074224c0bfc389c25f9c76c2a2dd568c9561a1194f2a207d931542`; prefix matches `ai_assistance_log.md` row A2); `configs/protocol_v1_0.json` (`source` field) | **VERIFIED** as the text of the 14 decisions (file read and compared). It has no date, signature or freeze hash, so *when* it was fixed and the approval record stay UNKNOWN. The code only checks that the file exists before `evaluate`. Implementation check: `docs/PROTOCOL_IMPLEMENTATION_CHECK.md` |
| Author decision on interpretations A-H (retrospective; the approval date will be the actual date of signing; **proposed, unsigned**; H3 stays unconfirmed pending evaluation manifest hash verification) | `docs/AUTHOR_DECISION_RECORD.md` | **PROPOSED**: the overall decision "preserve v0.6 as the operative implementation for reproduction" is the author's message of 11 Nov 2026; per-item approvals are not yet ticked. No historical approval is claimed |
| Detailed T1-T5 definitions ("Prompt 07 v0.2", decision 13) | not in any supplied file | **UNKNOWN**; the code, the author's Prompt 09 summary and the manuscript agree with each other (see the check document) |
| Master seed 20261029; derived seeds split 20261030, faults 20261031, missed-case review 20261032, bootstrap 20261033 | `configs/seeds.json` | VERIFIED in the file, which says **PROVISIONAL**; no approval record (UNKNOWN) |
| T4 "capable only" with a reserve top-up (10 evaluation invoices cannot host T4; 10 reserve invoices replace them) | `configs/protocol_v1_0.json` notes; `ai_assistance_log.md` row A5 | VERIFIED in code/config; whether the author approved it as a design change is UNKNOWN (flagged in the log) |
| Percentile method "higher" for the limit L | `configs/protocol_v1_0.json` notes ("OPEN") | VERIFIED as written; marked OPEN in the config |
| Keep F+ (a stronger final-only validator) as a stated limitation, do not run it | `ai_assistance_log.md` section 3; manuscript Section 8 item 2 | VERIFIED as recorded |
| RQ2 not evaluated (no dated predictions file) | manuscript Section 8 item 4; `results/stored_evaluation/metrics/R9_decision_rules.csv` | VERIFIED |
| Do not claim a published baseline, an independent oracle/audit, or a frozen/pre-specified protocol | `baseline_validation.md`; manuscript Section 5.4 and 8 | VERIFIED as stated wording decisions |
| Seven Phase A decisions on Revision 4 and the reference restorations | `ai_assistance_log.md` rows A11, A13 | The decisions' text is not in the supplied files (UNKNOWN) |

## Part C. Open items (from the sources above, not new decisions)
Pilot results, calibration-constants file, eligibility report, Prompt 07 v0.2 text, raw-data manifest and retrieval date, seed approval, protocol freeze record (date/hash; the decisions text itself is now recovered), number of evaluation executions, second-person rerun: **UNKNOWN / TEST REQUIRED** (see `README.md`, "MISSING / NOT VERIFIED").
