"""Tests for the pilot inspector on a synthetic pilot (and on deliberately damaged copies of it)."""

import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import synth  # noqa: E402
from test_experiment import raw_frame  # noqa: E402

from g1 import experiment, pilot_check, protocol  # noqa: E402

PROJECT = Path(__file__).resolve().parents[1]


class TestPilotCheck(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.root = Path(self.tmp.name)
        shutil.copytree(PROJECT / "configs", self.root / "configs")
        self.proto = protocol.load_protocol(self.root)
        self.proto["sizes"] = {"calibration": 40, "pilot": 12, "evaluation": 20}
        self.proto["pool"] = {"expected_pool_invoices": None, "expected_t4_capable_invoices": None}
        experiment.prepare(raw_frame(synth.make_invoices(100, seed=21, equal_price_every=4)), self.root, self.proto)
        experiment.run_subset(self.root, self.proto, "pilot")
        self.src = self.root / "results" / "pilot"

    def tearDown(self):
        self.tmp.cleanup()

    def status(self, rep, name):
        return next(r["status"] for r in rep["checks"] if r["check"].startswith(name))

    def test_clean_synthetic_pilot_has_no_failures(self):
        rep = pilot_check.inspect(self.root, self.proto, "pilot")
        self.assertNotEqual(rep["overall"], "FAIL", [r for r in rep["checks"] if r["status"] == "FAIL"])
        for name in ("files_present", "manifest_hash_matches_file", "runs_cover_every_case", "run_logs_contain_no_fault",
                     "B0_never_halts", "clean_B0_record", "M9_zero", "deterministic_rerun_identical", "no_t4_reserve_rows_in_pilot"):
            self.assertEqual(self.status(rep, name), "PASS", name)

    def test_inspection_writes_nothing(self):
        before = sorted(str(p) for p in self.root.rglob("*"))
        pilot_check.inspect(self.root, self.proto, "pilot")
        self.assertEqual(before, sorted(str(p) for p in self.root.rglob("*")))

    def test_missing_files_fail_cleanly(self):
        shutil.rmtree(self.src)
        rep = pilot_check.inspect(self.root, self.proto, "pilot")
        self.assertEqual((rep["overall"], rep["checks"][0]["check"]), ("FAIL", "files_present"))

    def test_tampered_manifest_is_detected(self):
        path = self.src / "manifest.json"
        path.chmod(0o644)
        rows = json.loads(path.read_text()); rows[1]["faulty_value"] = "tampered"; path.write_text(json.dumps(rows))
        self.assertEqual(self.status(pilot_check.inspect(self.root, self.proto, "pilot"), "manifest_hash_matches_file"), "FAIL")

    def test_b0_applying_rules_and_m9_violation_are_detected(self):
        path = self.src / "runs.jsonl"
        path.chmod(0o644)
        logs = [json.loads(l) for l in path.read_text().splitlines()]
        b0 = next(l for l in logs if l["condition"] == "B0"); b0["rule_applications"] = 3
        path.write_text("".join(json.dumps(l, sort_keys=True) + "\n" for l in logs))
        rep = pilot_check.inspect(self.root, self.proto, "pilot")
        self.assertEqual(self.status(rep, "B0_never_halts"), "FAIL")
        self.assertEqual(self.status(rep, "deterministic_rerun_identical"), "FAIL")      # file no longer matches a fresh run

    def test_crash_share_thresholds(self):
        path = self.src / "runs.jsonl"
        path.chmod(0o644)
        logs = [json.loads(l) for l in path.read_text().splitlines()]
        next(l for l in logs if l["condition"] == "F")["outcome"] = "CRASHED"
        path.write_text("".join(json.dumps(l, sort_keys=True) + "\n" for l in logs))
        rep = pilot_check.inspect(self.root, self.proto, "pilot")
        self.assertIn(self.status(rep, "crashes_at_most_2_percent"), ("WARN", "FAIL"))     # 1 crash of ~60 faulty cases is above 2%


if __name__ == "__main__":
    unittest.main()
