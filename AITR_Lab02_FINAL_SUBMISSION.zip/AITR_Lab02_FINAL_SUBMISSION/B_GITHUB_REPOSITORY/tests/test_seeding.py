"""Unit tests for g1.seeding (standard-library unittest, no extra dependency)."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from g1 import seeding  # noqa: E402


class TestSeeding(unittest.TestCase):
    def test_derive_seeds_values(self):
        s = seeding.derive_seeds(20261029)
        self.assertEqual(s, {"split": 20261030, "faults": 20261031,
                             "missed_case_review": 20261032, "bootstrap": 20261033})

    def test_same_seed_same_stream(self):
        a = seeding.make_rng(7).integers(0, 1000, 20)
        b = seeding.make_rng(7).integers(0, 1000, 20)
        self.assertTrue((a == b).all())

    def test_streams_are_independent(self):
        r1 = seeding.make_all_rngs(1)
        r2 = seeding.make_all_rngs(1)
        r1["faults"].random(500)  # extra draws on one purpose ...
        self.assertEqual(r1["split"].integers(0, 10**6), r2["split"].integers(0, 10**6))  # ... leave others unchanged

    def test_different_purposes_differ(self):
        r = seeding.make_all_rngs(1)
        self.assertNotEqual(r["split"].integers(0, 10**9), r["faults"].integers(0, 10**9))

    def test_invalid_seed_rejected(self):
        for bad in (-1, 2**32, 1.5, "1", True):
            with self.assertRaises((TypeError, ValueError)):
                seeding.make_rng(bad)

    def test_duplicate_offsets_rejected(self):
        with self.assertRaises(ValueError):
            seeding.derive_seeds(1, {"a": 1, "b": 1})


if __name__ == "__main__":
    unittest.main()
