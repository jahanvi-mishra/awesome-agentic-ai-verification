"""Tests for g1.eligibility on a hand-built SYNTHETIC table (never the real dataset).

Each invoice below exists to trigger one rule; expected counts were worked out by hand.
"""

import json
import sys
import unittest
from datetime import datetime
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from g1 import eligibility as el  # noqa: E402

D1, D2 = datetime(2010, 12, 1, 8, 26), datetime(2010, 12, 1, 9, 30)


def frame() -> pd.DataFrame:
    R = []
    def add(inv, stock, desc, qty, date, price, cust, country="United Kingdom"):
        R.append([inv, stock, desc, qty, date, price, cust, country])
    add("600001", "A", "x", 2, D1, 2.55, 12345.0); add("600001", "B", "x", 1, D1, 3.39, 12345.0)      # I1 eligible, T4 capable
    add("600002", "A", "other text", 2, D2, 2.55, 12345.0); add("600002", "B", "y", 1, D2, 3.39, 12345.0)  # I2 = same content as I1
    add("600003", "A", "x", 1, D1, 1.0, 11111.0)                                                       # I3 one line only
    add("C600004", "A", "x", -1, D1, 1.0, 22222.0); add("C600004", "B", "x", -1, D1, 2.0, 22222.0)     # I4 cancelled
    add("600005", "A", "x", 1, D1, 1.0, 33333.0); add("600005", "B", "x", 1, D1, 2.0, None)            # I5 one line lacks CustomerID
    add("600006", "A", "x", 1, D1, 1.0, 23456.0, "Unspecified"); add("600006", "B", "x", 1, D1, 1.0, 23456.0, "Unspecified")  # I6 same prices
    add("A600007", "A", "x", 1, D1, 1.1, 34567.0); add("A600007", "B", "x", 1, D1, 2.2, 34567.0)       # I7 non 6-digit
    add("600008", "A", "x", 1, D1, 1.5, 45678.0); add("600008", "B", "x", 1, D2, 2.5, 45678.0)         # I8 two dates
    add("600009", "A", "x", 1, D1, 1.0, 56789.0); add("600009", "A", "x", 1, D1, 1.0, 56789.0)         # I9 exact repeated row
    add("600010", "A", "x", 1, D1, 0.125, 67890.0); add("600010", "B", "x", 1, D1, 1.5, 67890.0)       # I10 3-decimal tie
    add("600011", "A", "x", 1, D1, 0.004, 78901.0); add("600011", "B", "x", 1, D1, 5.0, 78901.0)       # I11 sub-penny price
    add("600012", "A", "x", 0, D1, 1.0, 89012.0); add("600012", "B", "x", 1, D1, 2.0, 89012.0)         # I12 Quantity 0 on one line
    add(None, "A", "x", 1, D1, 1.0, 90123.0)                                                           # row without InvoiceNo
    return pd.DataFrame(R, columns=el.REQUIRED_COLUMNS).astype(object)


class TestPrice(unittest.TestCase):
    def test_two_decimal_and_truncation_risk(self):
        f = el.price_info(2.55)
        self.assertEqual((f["decimals"], f["pence_half_up"]), (2, 255))
        self.assertEqual(f["naive_truncate"], 254)      # int(2.55*100) is wrong: this is the rounding risk

    def test_tie_and_python_round(self):
        f = el.price_info(0.125)
        self.assertTrue(f["is_tie"])
        self.assertEqual((f["pence_half_up"], f["naive_round"]), (13, 12))

    def test_sub_penny(self):
        self.assertEqual(el.price_info(0.004)["pence_half_up"], 0)

    def test_integer_price(self):
        self.assertEqual((el.price_info(5.0)["decimals"], el.price_info(5.0)["pence_half_up"]), (0, 500))


class TestReport(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.df = frame()
        cls.before = cls.df.copy(deep=True)
        cls.rep = el.build_report(cls.df)

    def test_raw_frame_untouched(self):
        pd.testing.assert_frame_equal(self.before, self.df)

    def test_invoice_counts(self):
        il = self.rep["invoice_level"]
        self.assertEqual(il["1_invoices_after_excluding_cancelled"], 11)        # I1,2,3,5,6,7,8,9,10,11,12
        self.assertEqual(il["2_invoices_all_rows_valid_any_line_count"], 9)     # all but I5, I12
        self.assertEqual(il["invoices_with_some_but_not_all_rows_valid_excluded"], 2)
        self.assertEqual(il["all_rows_valid_but_only_one_line"], 1)
        self.assertEqual(il["3_S1_all_rows_valid_and_2plus_lines"], 8)
        self.assertEqual(il["S1_invoices_not_6_digit_pattern"], 1)
        self.assertEqual(self.rep["row_level"]["rows_missing_invoice_no"], 1)

    def test_unspecified_country_is_present(self):
        self.assertEqual(self.rep["row_level"]["rows_country_Unspecified_kept_as_present"], 2)
        self.assertEqual(self.rep["invoice_level"]["3_S1_all_rows_valid_and_2plus_lines"], 8)  # I6 kept

    def test_dates_and_repeats(self):
        self.assertEqual(self.rep["dates"]["4_non_cancelled_invoices_with_multiple_InvoiceDate"], 1)
        self.assertEqual(self.rep["repeated_rows"]["5_non_cancelled_invoices_with_repeated_exact_rows(all 8 columns)"], 1)

    def test_duplicate_contents_ignore_invoiceno_date_description(self):
        full = self.rep["duplicate_invoice_contents"]["full_signature"]
        self.assertEqual((full["duplicate_groups"], full["extra_invoices_if_one_kept_per_group"]), (1, 1))

    def test_scenarios(self):
        s = self.rep["scenarios"]
        self.assertEqual(s["A_S1_prompt07_steps_1_to_3_no_dedupe"], 8)
        self.assertEqual(s["B_A_minus_duplicate_content_invoices(full_sig, keep first)"], 7)
        # C removes I7 (pattern), I8 (two dates), I10 and I11 (3 decimals) -> I1, I2, I6, I9
        self.assertEqual(s["C_A_and_6digit_InvoiceNo_and_exact_2dp_prices_5digit_CustomerID_integer_Quantity_and_single_InvoiceDate"], 4)
        self.assertEqual(s["D_C_minus_duplicate_content_invoices(full_sig, keep first)"], 3)
        self.assertEqual(s["E_D_and_at_least_2_distinct_prices(T4_capable)"], 1)  # only I1 of {I1, I6, I9}

    def test_t4(self):
        t4 = self.rep["t4_feasibility"]["on_S1"]
        self.assertEqual(t4["invoices_with_2plus_distinct_prices_in_pence"], 6)   # I1,I2,I7,I8,I10,I11

    def test_t5(self):
        t5 = self.rep["t5_feasibility"]["on_S1"]
        self.assertEqual(t5["distinct_customers"], 7)
        self.assertEqual(t5["largest_customer_invoice_count"], 2)
        self.assertEqual(t5["min_partners_different_customer"], 6)
        self.assertEqual(t5["invoices_with_no_other_invoice_of_different_customer"], 0)

    def test_precision_counts(self):
        p = self.rep["price_precision"]["rows_of_S1_invoices"]
        self.assertEqual(p["rows_more_than_2_decimals"], 2)
        self.assertEqual(p["rows_exact_tie_at_half_penny"], 1)
        self.assertEqual(p["rows_positive_price_but_zero_pence"], 1)
        self.assertGreaterEqual(p["rows_2dp_where_int_of_price_x100_is_wrong"], 2)  # the two 2.55 rows
        self.assertEqual(self.rep["price_precision"]["S1_invoice_effects"]["S1_invoices_with_any_zero_pence_line"], 1)

    def test_json_safe(self):
        json.dumps(self.rep, default=str)


if __name__ == "__main__":
    unittest.main()
