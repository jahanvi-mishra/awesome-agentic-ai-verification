"""Tests for M1-M11 and the R1-R9 CSV outputs. Expected values below were worked out by hand."""

import csv
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import synth  # noqa: E402
from test_experiment import raw_frame  # noqa: E402

import score_results  # noqa: E402
from g1 import experiment, metrics, protocol  # noqa: E402

SEEDS = {"split": 1, "faults": 2, "missed_case_review": 3, "bootstrap": 4}
PROJECT = Path(__file__).resolve().parents[1]


def hand_built():
    """8 cases. Harmful: T1(inv1), T1(inv2), T4(inv3), T4(inv9, reserve). Benign: T5(inv4). Crash: T3(inv5)."""
    manifest, logs, labels = [], [], []

    def case(cid, inv, ft, label, b0, f, i, source=None):
        row = {"case_id": cid, "invoice_no": inv, "fault_type": ft, "status": "clean" if ft == "CLEAN" else "inject", "skip_reason": None}
        if source:
            row["source"] = source
        manifest.append(row)
        labels.append({"case_id": cid, "fault_type": ft, "label": label})
        for cond, (out, cp, rule) in zip(("B0", "F", "I"), (b0, f, i)):
            logs.append({"case_id": cid, "condition": cond, "outcome": out, "halt_checkpoint": cp, "halt_rule": rule,
                         "halt_detail": f"{rule} detail" if rule else None,
                         "rule_applications": {"B0": 0, "F": 6, "I": 10}[cond]})
    C, H = ("COMMITTED", None, None), "HALTED"
    case("1-CLEAN", "1", "CLEAN", "reference_match", C, C, C)
    case("1-T1", "1", "T1", "harmful", C, C, (H, "CP1", "R1.1"))
    case("2-CLEAN", "2", "CLEAN", "reference_match", C, C, (H, "CP1", "R1.4"))        # false alarm under I
    case("2-T1", "2", "T1", "harmful", C, (H, "FINAL", "RF.2"), (H, "CP1", "R1.1"))
    case("3-T4", "3", "T4", "harmful", C, C, C)                                       # missed by both
    case("4-T5", "4", "T5", "benign", C, C, (H, "CP3", "R3.3"))
    case("5-T3", "5", "T3", "crash", ("CRASHED", None, None), ("CRASHED", None, None), ("CRASHED", None, None))
    case("9-T4", "9", "T4", "harmful", C, C, (H, "CP2", "R2.1"), source="t4_reserve")
    manifest.append({"case_id": "6-T4", "invoice_no": "6", "fault_type": "T4", "status": "skipped", "skip_reason": "all unit prices equal"})
    return manifest, logs, labels


def read_csv(path):
    with open(path, encoding="utf-8", newline="") as fh:
        return list(csv.DictReader(fh))


def by(rows, **kw):
    return next(r for r in rows if all(r[k] == v for k, v in kw.items()))


class TestStatistics(unittest.TestCase):
    def test_wilson_known_values(self):
        lo, hi = metrics.wilson(50, 100)
        self.assertAlmostEqual(lo, 0.4038, places=3)
        self.assertAlmostEqual(hi, 0.5962, places=3)
        lo, hi = metrics.wilson(0, 10)
        self.assertEqual(lo, 0.0)
        self.assertAlmostEqual(hi, 0.2775, places=3)
        self.assertEqual(metrics.wilson(0, 0), (None, None))

    def test_rate(self):
        self.assertEqual(metrics.rate(1, 4), 0.25)
        self.assertIsNone(metrics.rate(0, 0))


class TestHandBuiltMetrics(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        m, l, lab = hand_built()
        cls.T = metrics.compute(m, l, lab, SEEDS, None, resamples=300)
        cls.S = cls.T["metrics_summary"]

    def val(self, metric, scope):
        r = by(self.S, metric=metric, scope=scope)
        return r["numerator"], r["denominator"], r["value"]

    def test_m1_m1d_m2(self):
        self.assertEqual(self.val("M1", "F"), (3, 4, 0.75))
        self.assertEqual(self.val("M1", "I"), (1, 4, 0.25))
        self.assertEqual(by(self.S, metric="M1d")["value"], 50.0)
        self.assertEqual(self.val("M2", "F"), (1, 4, 0.25))
        self.assertEqual(self.val("M2", "I"), (3, 4, 0.75))
        for c in ("F", "I"):                                                  # M2 = 1 - M1 when nothing crashed among harmful cases
            self.assertAlmostEqual(self.val("M1", c)[2] + self.val("M2", c)[2], 1.0)

    def test_m3_recall_excludes_crashes_and_skipped(self):
        self.assertEqual(self.val("M3", "F"), (1, 5, 0.2))
        self.assertEqual(self.val("M3", "I"), (4, 5, 0.8))

    def test_m4_false_positives(self):
        self.assertEqual(self.val("M4", "F"), (0, 2, 0.0))
        self.assertEqual(self.val("M4", "I"), (1, 2, 0.5))

    def test_m5_cost(self):
        self.assertEqual(self.val("M5", "F"), (48, 8, 6.0))
        self.assertEqual(self.val("M5", "I"), (80, 8, 10.0))
        self.assertEqual(by(self.S, metric="M5", scope="I-F")["numerator"], 32)
        self.assertAlmostEqual(by(self.S, metric="M5", scope="I/F")["value"], 80 / 48)

    def test_m6_per_type(self):
        self.assertEqual(self.val("M6", "T1/F"), (1, 2, 0.5))
        self.assertEqual(self.val("M6", "T1/I"), (0, 2, 0.0))
        self.assertEqual(self.val("M6", "T4/F"), (2, 2, 1.0))
        self.assertEqual(self.val("M6", "T4/I"), (1, 2, 0.5))
        self.assertEqual(self.val("M6", "T5/F"), (0, 0, None))                # no harmful T5: no rate, no invented number

    def test_m7_m8_m9(self):
        self.assertEqual(self.val("M7", "all"), (2, 4, 0.5))
        self.assertEqual(self.val("M8", "all"), (1, 4, 0.25))
        self.assertEqual(self.val("M9", "all"), (0, 4, 0.0))

    def test_m10_attribution_and_m11(self):
        self.assertEqual([self.val("M10", f"I/{cp}")[0] for cp in metrics.CHECKPOINTS], [2, 1, 1, 0])
        self.assertEqual(self.val("M10", "I/CP1")[1], 4)
        self.assertEqual(self.val("M10", "F/FINAL"), (1, 1, 1.0))
        self.assertEqual(self.val("M11", "all"), (1, 5, 0.2))

    def test_tables(self):
        T = self.T
        r1 = {r["condition"]: r for r in T["R1_primary"]}
        self.assertEqual((r1["F"]["reached_commit_n"], r1["I"]["reached_commit_n"], r1["F"]["harmful_N"]), (3, 1, 4))
        t1, t4, t5, t3 = (by(T["R2_per_type"], type=t) for t in ("T1", "T4", "T5", "T3"))
        self.assertEqual((t1["harmful"], t1["F_reached_n"], t1["I_reached_n"], t1["caught_only_by_I"], t1["missed_by_both"]), (2, 1, 0, 1, 0))
        self.assertEqual((t4["injected"], t4["skipped"], t4["harmful"], t4["F_reached_n"], t4["I_reached_n"], t4["caught_only_by_I"], t4["missed_by_both"]), (2, 1, 2, 2, 1, 1, 1))
        self.assertEqual((t5["benign"], t5["harmful"]), (1, 0))
        self.assertEqual((t3["crashed"], t3["injected"]), (1, 1))
        self.assertEqual(by(T["R3_outcome_overlap"], row="F halted"), {"row": "F halted", "I_halted": 1, "I_committed": 0})
        self.assertEqual(by(T["R3_outcome_overlap"], row="F committed"), {"row": "F committed", "I_halted": 2, "I_committed": 1})
        self.assertEqual(by(T["R4_halting_attribution"], type="T1")["CP1"], 2)
        self.assertEqual(by(T["R4_halting_attribution"], type="T4")["CP2"], 1)
        self.assertEqual(by(T["R4_halting_attribution"], type="T5")["CP3"], 1)
        self.assertEqual(T["R5b_false_alarm_cases"], [{"case_id": "2-CLEAN", "condition": "I", "rule_id": "R1.4", "checkpoint": "CP1", "values": "R1.4 detail", "classification": ""}])
        self.assertEqual(by(T["R6_cost"], condition="B0")["total_rule_applications"], 0)
        self.assertEqual(by(T["R6_cost"], condition="I")["ratio_to_F"], 80 / 48)
        self.assertEqual([r["case_id"] for r in T["R7_missed_by_both_review"]], ["3-T4"])
        r8 = {r["item"]: r["count"] for r in T["R8_exclusions_anomalies"]}
        self.assertEqual(r8["T4 skipped"], 1)
        self.assertEqual(r8["T4 cases drawn from the T4-capable reserve"], 1)
        self.assertEqual((r8["crashed cases under F"], r8["M9 violations (harmful: halted by F, committed by I)"], r8["B0 runs that applied any rule"]), (1, 0, 0))

    def test_r9_without_and_with_predictions(self):
        r9 = {r["rule"]: r for r in self.T["R9_decision_rules"]}
        self.assertTrue(r9["RQ2"]["observed"].startswith("NOT EVALUATED"))
        self.assertEqual(r9["RQ2"]["met"], "")
        self.assertFalse(r9["RQ3"]["met"])                                   # FPR(I) = 50%
        m, l, lab = hand_built()
        T = metrics.compute(m, l, lab, SEEDS, {"T1": True, "T2": False, "T3": False, "T4": True, "T5": False}, resamples=50)
        rq2 = by(T["R9_decision_rules"], rule="RQ2")
        self.assertEqual((rq2["observed"], rq2["met"]), ("5 of 5 predictions correct", True))
        T = metrics.compute(m, l, lab, SEEDS, {"T1": False, "T2": True, "T3": True, "T4": False, "T5": True}, resamples=50)
        self.assertFalse(by(T["R9_decision_rules"], rule="RQ2")["met"])

    def test_bootstrap_is_deterministic_and_seed_dependent(self):
        m, l, lab = hand_built()
        a = metrics.compute(m, l, lab, SEEDS, None, resamples=300)["metrics_summary"]
        b = metrics.compute(m, l, lab, SEEDS, None, resamples=300)["metrics_summary"]
        self.assertEqual(a, b)
        other = metrics.compute(m, l, lab, {**SEEDS, "bootstrap": 99}, None, resamples=300)["metrics_summary"]
        self.assertEqual(by(a, metric="M1d")["value"], by(other, metric="M1d")["value"])   # point estimate never depends on the seed

    def test_bootstrap_interval_brackets_point_estimate_on_larger_data(self):
        """Clusters: each invoice has a harmful T1 reached under F only. M1(F)=1, M1(I)=0, so every resample gives 100 points."""
        manifest, logs, labels = [], [], []
        for k in range(30):
            cid = f"{k}-T1"
            manifest.append({"case_id": cid, "invoice_no": str(k), "fault_type": "T1", "status": "inject", "skip_reason": None})
            labels.append({"case_id": cid, "fault_type": "T1", "label": "harmful"})
            for cond, out in (("B0", "COMMITTED"), ("F", "COMMITTED"), ("I", "HALTED")):
                logs.append({"case_id": cid, "condition": cond, "outcome": out, "halt_checkpoint": "CP1" if out == "HALTED" else None,
                             "halt_rule": "R1.1" if out == "HALTED" else None, "halt_detail": None, "rule_applications": 1})
        d = by(metrics.compute(manifest, logs, labels, SEEDS, None, resamples=200)["metrics_summary"], metric="M1d")
        self.assertEqual((d["value"], d["ci_low"], d["ci_high"]), (100.0, 100.0, 100.0))

    def test_empty_inputs(self):
        T = metrics.compute([], [], [], SEEDS, None, resamples=10)
        self.assertEqual(by(T["metrics_summary"], metric="M1", scope="F")["value"], None)
        self.assertIsNone(by(T["metrics_summary"], metric="M1d")["value"])
        self.assertEqual(T["R7_missed_by_both_review"], [])

    def test_missing_run_log_is_an_error(self):
        m, l, lab = hand_built()
        with self.assertRaises(KeyError):
            metrics.compute(m, l[:-1], lab, SEEDS, None, resamples=10)

    def test_review_sample_is_capped_at_50_and_seeded(self):
        manifest, logs, labels = [], [], []
        for k in range(80):
            cid = f"{k}-T4"
            manifest.append({"case_id": cid, "invoice_no": str(k), "fault_type": "T4", "status": "inject", "skip_reason": None})
            labels.append({"case_id": cid, "fault_type": "T4", "label": "harmful"})
            for cond in ("B0", "F", "I"):
                logs.append({"case_id": cid, "condition": cond, "outcome": "COMMITTED", "halt_checkpoint": None, "halt_rule": None, "halt_detail": None, "rule_applications": 0})
        a = metrics.compute(manifest, logs, labels, SEEDS, None, resamples=10)["R7_missed_by_both_review"]
        b = metrics.compute(manifest, logs, labels, SEEDS, None, resamples=10)["R7_missed_by_both_review"]
        self.assertEqual((len(a), a), (50, b))


class TestEndToEndCsv(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.root = Path(self.tmp.name)
        shutil.copytree(PROJECT / "configs", self.root / "configs")
        self.proto = protocol.load_protocol(self.root)
        self.proto["sizes"] = {"calibration": 40, "pilot": 8, "evaluation": 20}
        self.proto["pool"] = {"expected_pool_invoices": None, "expected_t4_capable_invoices": None}
        invs = synth.make_invoices(100, seed=21, equal_price_every=3)
        experiment.prepare(raw_frame(invs), self.root, self.proto)
        experiment.run_subset(self.root, self.proto, "evaluation")

    def tearDown(self):
        self.tmp.cleanup()

    def test_scoring_writes_all_csvs_once_and_validity_holds(self):
        res = score_results.score(self.root, "evaluation", self.proto, resamples=200)
        expected = {"metrics_summary", "R1_primary", "R2_per_type", "R3_outcome_overlap", "R4_halting_attribution", "R4b_halting_by_rule",
                    "R5_clean_false_alarms", "R5b_false_alarm_cases", "R6_cost", "R7_missed_by_both_review",
                    "R8_exclusions_anomalies", "R9_decision_rules", "cases_joined"}
        self.assertEqual(set(res["files"]), {f"{n}.csv" for n in expected})
        out = self.root / "results" / "evaluation" / "metrics"
        summary = read_csv(out / "metrics_summary.csv")
        m9 = next(r for r in summary if r["metric"] == "M9")
        self.assertEqual(m9["numerator"], "0")                                # F never beats I
        for c in ("F", "I"):
            m1 = float(next(r for r in summary if r["metric"] == "M1" and r["scope"] == c)["value"])
            m2 = float(next(r for r in summary if r["metric"] == "M2" and r["scope"] == c)["value"])
            self.assertAlmostEqual(m1 + m2, 1.0, places=5)
        self.assertEqual({r["metric"] for r in summary}, {f"M{i}" for i in range(1, 12)} | {"M1d"})
        r2 = read_csv(out / "R2_per_type.csv")
        self.assertEqual([r["type"] for r in r2], ["T1", "T2", "T3", "T4", "T5"])
        self.assertEqual(int(next(r for r in r2 if r["type"] == "T4")["injected"]), 20)   # one T4 case per evaluation invoice
        with self.assertRaises(FileExistsError):
            score_results.score(self.root, "evaluation", self.proto, resamples=10)

    def test_scoring_refuses_a_tampered_manifest(self):
        path = self.root / "results" / "evaluation" / "manifest.json"
        path.chmod(0o644)
        rows = json.loads(path.read_text())
        rows[1]["faulty_value"] = "tampered"
        path.write_text(json.dumps(rows))
        with self.assertRaises(ValueError):
            score_results.score(self.root, "evaluation", self.proto, resamples=10)

    def test_scoring_is_reproducible(self):
        score_results.score(self.root, "evaluation", self.proto, resamples=200)
        first = (self.root / "results" / "evaluation" / "metrics" / "metrics_summary.csv").read_text()
        shutil.rmtree(self.root / "results" / "evaluation" / "metrics")
        score_results.score(self.root, "evaluation", self.proto, resamples=200)
        self.assertEqual(first, (self.root / "results" / "evaluation" / "metrics" / "metrics_summary.csv").read_text())


if __name__ == "__main__":
    unittest.main()
