"""Tests 1, 2, 9, 10: preprocessing/eligibility, deterministic splits, reproducibility, edge cases."""

import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import synth  # noqa: E402
from test_eligibility import frame  # noqa: E402

from g1 import data_prep, money, split  # noqa: E402


class TestMoney(unittest.TestCase):
    def test_exact_conversion_without_float_error(self):
        self.assertEqual(money.price_to_pence(2.55), 255)       # int(2.55*100) would give 254
        self.assertEqual(money.price_to_pence("3.39"), 339)
        self.assertEqual(money.price_to_pence(5.0), 500)

    def test_rejects_more_than_two_decimals(self):
        with self.assertRaises(ValueError):
            money.price_to_pence(0.125)

    def test_line_amount_integer_only(self):
        self.assertEqual(money.line_amount(6, 255), 1530)
        for bad in ((1.5, 100), (True, 100), ("2", 100)):
            with self.assertRaises(TypeError):
                money.line_amount(*bad)


class TestPool(unittest.TestCase):
    def setUp(self):
        self.df = frame()
        self.before = self.df.copy(deep=True)
        self.invoices, self.counts = data_prep.select_pool(self.df)

    def test_pool_matches_hand_count(self):
        # S1 has 8 invoices; pattern/type/date filters leave I1,I2,I6,I9; I2 duplicates I1 -> pool I1,I6,I9
        self.assertEqual([i.invoice_no for i in self.invoices], ["600001", "600006", "600009"])
        self.assertEqual(self.counts["S1_invoices"], 8)
        self.assertEqual(self.counts["after_pattern_type_date_filters"], 4)
        self.assertEqual(self.counts["duplicate_content_removed"], 1)
        self.assertEqual(self.counts["pool_invoices"], 3)
        self.assertEqual(self.counts["t4_capable_invoices"], 1)

    def test_content_and_repeated_rows_kept(self):
        by = {i.invoice_no: i for i in self.invoices}
        self.assertEqual([(l.stock_code, l.quantity, l.unit_price_pence) for l in by["600001"].lines], [("A", 2, 255), ("B", 1, 339)])
        self.assertEqual(by["600001"].customer_id, "12345")
        self.assertEqual(len(by["600009"].lines), 2)             # the repeated exact row is kept
        self.assertEqual(by["600006"].country, "Unspecified")     # 'Unspecified' is a valid country

    def test_raw_frame_not_modified(self):
        import pandas as pd
        pd.testing.assert_frame_equal(self.before, self.df)

    def test_csv_roundtrip_and_no_overwrite(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            path = Path(tmp) / "base.csv"
            h1 = data_prep.write_base_lines(self.invoices, path)
            self.assertEqual(data_prep.read_base_lines(path), self.invoices)
            self.assertEqual(data_prep.write_base_lines(self.invoices, path), h1)   # identical: fine
            with self.assertRaises(FileExistsError):
                data_prep.write_base_lines(self.invoices[:2], path)                  # different: refused

    def test_bad_csv_rejected(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            path = Path(tmp) / "bad.csv"
            path.write_text("a,b\n1,2\n")
            with self.assertRaises(ValueError):
                data_prep.read_base_lines(path)


SIZES = {"calibration": 30, "pilot": 5, "evaluation": 20}


class TestSplit(unittest.TestCase):
    def setUp(self):
        self.nos = [i.invoice_no for i in synth.make_invoices(100)]

    def test_deterministic_and_disjoint(self):
        a = split.split_invoices(self.nos, 20261030, SIZES)
        b = split.split_invoices(list(reversed(self.nos)), 20261030, SIZES)   # input order must not matter
        self.assertEqual(a, b)
        self.assertEqual(split.split_hash(a), split.split_hash(b))
        self.assertEqual({k: len(v) for k, v in a.items()}, SIZES)
        allids = a["calibration"] + a["pilot"] + a["evaluation"]
        self.assertEqual(len(allids), len(set(allids)))                       # disjoint

    def test_different_seed_differs(self):
        self.assertNotEqual(split.split_invoices(self.nos, 1, SIZES), split.split_invoices(self.nos, 2, SIZES))

    def test_too_small_pool_and_duplicates_rejected(self):
        with self.assertRaises(ValueError):
            split.split_invoices(self.nos[:10], 1, SIZES)
        with self.assertRaises(ValueError):
            split.split_invoices(self.nos + [self.nos[0]], 1, SIZES)


    def test_reserve_is_the_unassigned_remainder_in_permutation_order(self):
        sp = split.split_invoices(self.nos, 20261030, SIZES)
        res = split.reserve_after_split(self.nos, 20261030, SIZES)
        assigned = set(sp["calibration"] + sp["pilot"] + sp["evaluation"])
        self.assertEqual(len(res), len(self.nos) - 55)
        self.assertEqual(set(res) | assigned, set(self.nos))
        self.assertFalse(set(res) & assigned)
        self.assertEqual(res, split.reserve_after_split(list(reversed(self.nos)), 20261030, SIZES))   # input order irrelevant
        self.assertEqual(sp, split.split_invoices(self.nos, 20261030, SIZES))                          # split itself unchanged

    def test_constants_only_from_calibration(self):
        invs = synth.make_invoices(60)
        cal, rest = invs[:30], invs[30:]
        c1 = split.calibration_constants(cal)
        self.assertEqual(c1.q_max, max(l.quantity for i in cal for l in i.lines))
        self.assertEqual(c1.t_max_pence, max(split.invoice_total(i) for i in cal))
        self.assertEqual(c1.countries, frozenset(i.country for i in cal))
        self.assertIn(c1.l_pence, {split.invoice_total(i) for i in cal})       # 'higher' gives an observed total
        # changing the NON-calibration invoices must not change the constants
        self.assertEqual(c1, split.calibration_constants(cal))
        with self.assertRaises(ValueError):
            split.calibration_constants([])


if __name__ == "__main__":
    unittest.main()
