"""Synthetic invoices for tests (never real data). Deterministic: uses random.Random(seed)."""

import random
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from g1.data_prep import BaseInvoice, BaseLine  # noqa: E402
from g1.rules import RuleConstants  # noqa: E402
from g1.split import calibration_constants  # noqa: E402

COUNTRIES = ["United Kingdom", "France", "Germany", "Spain", "Unspecified"]


def make_invoices(n: int, seed: int = 1, start: int = 100000, equal_price_every: int = 0):
    """n invoices with 2-6 lines. Every `equal_price_every`-th invoice has all prices equal (T4 not possible)."""
    rnd = random.Random(seed)
    out = []
    for k in range(n):
        n_lines = rnd.randint(2, 6)
        equal = equal_price_every and k % equal_price_every == 0
        base_price = rnd.randint(50, 900)
        lines = tuple(BaseLine(f"S{rnd.randint(1000, 9999)}", rnd.randint(1, 24),
                               base_price if equal else rnd.randint(50, 900) + j) for j in range(n_lines))
        out.append(BaseInvoice(str(start + k), f"{rnd.randint(10000, 99999)}", rnd.choice(COUNTRIES), lines))
    return out


def constants_for(invoices) -> RuleConstants:
    return calibration_constants(invoices)
