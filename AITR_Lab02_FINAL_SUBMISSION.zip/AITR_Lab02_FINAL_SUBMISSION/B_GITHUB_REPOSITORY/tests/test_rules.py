"""Tests 4, 5: each checkpoint CP1-CP3 and the final validation, rule by rule (hand-built inputs)."""

import copy
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import synth  # noqa: E402

from g1 import pipeline, rules  # noqa: E402
from g1.rules import RuleConstants  # noqa: E402

C = RuleConstants(q_max=50, p_max_pence=1000, t_max_pence=100000, countries=frozenset({"France", "Germany"}), l_pence=5000)


def good():
    inv = synth.make_invoices(1, seed=3)[0]
    req = pipeline.s1_intake(inv)
    req["country"] = "France"
    amounts = pipeline.s2_transform(req)
    state = pipeline.s3_state_update(req, amounts)
    rec = pipeline.s4_commit_record(state, C.l_pence)
    return req, amounts, state, rec


class TestCP1(unittest.TestCase):
    def test_passes_clean(self):
        self.assertTrue(rules.cp1(good()[0], C).passed)

    def check(self, mutate, rule):
        req = good()[0]
        mutate(req)
        r = rules.cp1(req, C)
        self.assertFalse(r.passed)
        self.assertEqual(r.rule_id, rule)

    def test_r11_customer(self):
        self.check(lambda q: q.update(customer_id=None), "R1.1")
        self.check(lambda q: q.update(customer_id="1234"), "R1.1")
        self.check(lambda q: q.update(customer_id="UNKNOWN"), "R1.1")

    def test_r12_missing_line_field(self):
        self.check(lambda q: q["lines"][0].update(unit_price=None), "R1.2")

    def test_r13_types(self):
        self.check(lambda q: q["lines"][0].update(quantity="6 pcs"), "R1.3")
        self.check(lambda q: q["lines"][0].update(quantity=2.5), "R1.3")
        self.check(lambda q: q["lines"][0].update(unit_price="3"), "R1.3")

    def test_r14_ranges(self):
        self.check(lambda q: q["lines"][0].update(quantity=-1), "R1.4")
        self.check(lambda q: q["lines"][0].update(quantity=C.q_max + 1), "R1.4")
        self.check(lambda q: q["lines"][0].update(unit_price=0), "R1.4")
        self.check(lambda q: q["lines"][0].update(unit_price=C.p_max_pence + 1), "R1.4")

    def test_first_failure_stops_and_counts(self):
        req = good()[0]
        req["customer_id"] = None
        req["lines"][0]["quantity"] = -5      # second problem must not be reached
        r = rules.cp1(req, C)
        self.assertEqual((r.rule_id, r.applications), ("R1.1", 1))


class TestCP2CP3(unittest.TestCase):
    def test_cp2_pass_and_recompute_failure(self):
        req, amounts, _, _ = good()
        self.assertTrue(rules.cp2(req, amounts).passed)
        bad = list(amounts); bad[0] += 1
        r = rules.cp2(req, bad)
        self.assertEqual((r.passed, r.rule_id), (False, "R2.1"))

    def test_cp2_length_mismatch_and_unrecomputable(self):
        req, amounts, _, _ = good()
        self.assertEqual(rules.cp2(req, amounts[:-1]).rule_id, "R2.1")
        req["lines"][0]["quantity"] = "6 pcs"
        self.assertEqual(rules.cp2(req, amounts).rule_id, "R2.1")

    def test_cp2_negative_amount_rule(self):
        req = {"lines": [{"quantity": -2, "unit_price": 100}]}
        r = rules.cp2(req, [-200])               # recomputation agrees, so R2.1 passes; R2.2 must fail
        self.assertEqual(r.rule_id, "R2.2")

    def test_cp3_each_rule(self):
        req, amounts, state, _ = good()
        self.assertTrue(rules.cp3(req, amounts, state).passed)
        for key, val, rule in (("customer_id", "99999", "R3.1"), ("invoice_no", "X", "R3.1"), ("country", "Spain", "R3.1"),
                               ("n_lines", 99, "R3.2"), ("invoice_total", state["invoice_total"] + 1, "R3.3")):
            s = dict(state); s[key] = val
            r = rules.cp3(req, amounts, s)
            self.assertEqual((r.passed, r.rule_id), (False, rule), key)


class TestFinal(unittest.TestCase):
    def test_pass(self):
        self.assertTrue(rules.final_validation(good()[3], C).passed)

    def check(self, key, val, rule):
        rec = dict(good()[3]); rec[key] = val
        r = rules.final_validation(rec, C)
        self.assertEqual((r.passed, r.rule_id), (False, rule), (key, val))

    def test_each_rule(self):
        self.check("n_lines", "3", "RF.1")
        self.check("invoice_total", True, "RF.1")
        self.check("customer_id", "UNKNOWN", "RF.2")
        self.check("country", "Atlantis", "RF.3")
        self.check("invoice_total", 0, "RF.4")
        self.check("invoice_total", C.t_max_pence + 1, "RF.4")
        self.check("n_lines", 0, "RF.5")
        rec = dict(good()[3]); rec["decision"] = "HOLD" if rec["decision"] == "POST" else "POST"
        self.assertEqual(rules.final_validation(rec, C).rule_id, "RF.6")

    def test_missing_field(self):
        rec = dict(good()[3]); del rec["decision"]
        self.assertEqual(rules.final_validation(rec, C).rule_id, "RF.1")

    def test_final_cannot_see_lines(self):
        """The final gate accepts a record whose total is wrong but plausible (this is what makes T4 hard for F)."""
        rec = dict(good()[3]); rec["invoice_total"] = max(1, rec["invoice_total"] - 7)
        rec["decision"] = "POST" if rec["invoice_total"] <= C.l_pence else "HOLD"
        self.assertTrue(rules.final_validation(rec, C).passed)


if __name__ == "__main__":
    unittest.main()
