"""Tests 3, 6, 8, 10: fault types T1-T5, conditions B0/F/I, ledger isolation, crash handling."""

import sys
import unittest
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import synth  # noqa: E402

from g1 import faults, oracle, pipeline, rules, runner, seeding, split  # noqa: E402

INVS = synth.make_invoices(40, seed=5, equal_price_every=7)
CONST = rules.RuleConstants(q_max=24, p_max_pence=1000, t_max_pence=10**6,
                            countries=frozenset(synth.COUNTRIES), l_pence=6000)


def manifest(invs=INVS, seed=20261032):
    return faults.build_manifest(invs, CONST, seeding.make_rng(seed))


def run(inv, row, cond):
    return pipeline.run_pipeline(row["case_id"], inv, cond, CONST, faults.make_hook(row))


def rows_of(ftype, m=None):
    return [r for r in (m or manifest()) if r["fault_type"] == ftype]


BY_NO = {i.invoice_no: i for i in INVS}


class TestManifest(unittest.TestCase):
    def test_structure_and_counts(self):
        m = manifest()
        self.assertEqual(len(m), 40 * 6)
        self.assertEqual(sum(r["status"] == "clean" for r in m), 40)
        self.assertEqual([r["fault_type"] for r in m[:6]], ["CLEAN", "T1", "T2", "T3", "T4", "T5"])
        self.assertEqual(len({r["case_id"] for r in m}), len(m))

    def test_deterministic_and_input_order_independent(self):
        a, b = manifest(), faults.build_manifest(list(reversed(INVS)), CONST, seeding.make_rng(20261032))
        self.assertEqual(faults.manifest_hash(a), faults.manifest_hash(b))
        self.assertNotEqual(faults.manifest_hash(a), faults.manifest_hash(manifest(seed=1)))

    def test_skipping_does_not_shift_other_draws(self):
        """Fixed draws per type: removing the T4 possibility of one invoice must not change T1-T3 of later invoices."""
        a = {r["case_id"]: r for r in manifest()}
        equal = [i for i in INVS if len({l.unit_price_pence for l in i.lines}) == 1]
        self.assertTrue(equal)
        self.assertTrue(all(a[f"{i.invoice_no}-T4"]["status"] == "skipped" for i in equal))
        self.assertEqual(a[f"{equal[0].invoice_no}-T4"]["skip_reason"], "all unit prices equal")


class TestEachFaultUnderB0(unittest.TestCase):
    """B0 shows what each fault changes in the committed record (the oracle gives the reference)."""

    def labelled(self, ftype):
        out = []
        for r in rows_of(ftype):
            if r["status"] != "inject":
                continue
            inv = BY_NO[r["invoice_no"]]
            b0 = run(inv, r, "B0")
            ref = oracle.reference_record(inv, CONST.l_pence)
            out.append((r, b0, ref))
        return out

    def test_t1_missing_field_becomes_silent_default(self):
        for r, b0, ref in self.labelled("T1"):
            self.assertEqual(b0.outcome, "COMMITTED")
            if r["params"]["target"] == "customer_id":
                self.assertEqual(b0.commit_record["customer_id"], "UNKNOWN")
            else:
                self.assertLess(b0.commit_record["invoice_total"], ref["invoice_total"])   # missing price read as 0
            self.assertNotEqual(b0.commit_record, ref)

    def test_t2_malformed_quantity_read_as_zero(self):
        for r, b0, ref in self.labelled("T2"):
            self.assertTrue(r["faulty_value"].endswith(" pcs"))
            self.assertEqual(b0.outcome, "COMMITTED")
            self.assertLess(b0.commit_record["invoice_total"], ref["invoice_total"])

    def test_t3_negative_or_ten_times_max(self):
        seen = set()
        for r, b0, ref in self.labelled("T3"):
            seen.add(r["params"]["variant"])
            if r["params"]["variant"] == "negative":
                self.assertLess(r["faulty_value"], 0)
            else:
                self.assertEqual(r["faulty_value"], 10 * CONST.q_max)
            self.assertNotEqual(b0.commit_record["invoice_total"], ref["invoice_total"])
        self.assertEqual(seen, {"negative", "ten_times_q_max"})

    def test_t4_uses_another_lines_different_price(self):
        for r, b0, ref in self.labelled("T4"):
            inv = BY_NO[r["invoice_no"]]
            k, j = r["params"]["line_index"], r["params"]["other_line_index"]
            self.assertNotEqual(inv.lines[k].unit_price_pence, inv.lines[j].unit_price_pence)
            self.assertEqual(r["faulty_value"], inv.lines[k].quantity * inv.lines[j].unit_price_pence)
            self.assertNotEqual(b0.commit_record["invoice_total"], ref["invoice_total"])   # always changes the total

    def test_t5_copies_value_from_another_invoice(self):
        seen = set()
        for r, b0, ref in self.labelled("T5"):
            seen.add(r["params"]["target"])
            self.assertNotEqual(r["params"]["partner"], r["invoice_no"])
            self.assertNotEqual(r["faulty_value"], r["original_value"])
            self.assertEqual(b0.commit_record[r["params"]["target"]], r["faulty_value"])
        self.assertEqual(seen, {"invoice_total", "customer_id"})

    def test_t5_skipped_when_values_equal(self):
        twin = synth.make_invoices(2, seed=9)
        twin[1] = type(twin[0])("100001", twin[0].customer_id, twin[0].country, twin[0].lines)   # identical content
        rows = faults.build_manifest(twin, CONST, seeding.make_rng(1))
        t5 = [r for r in rows if r["fault_type"] == "T5"]
        self.assertTrue(all(r["status"] == "skipped" for r in t5))

    def test_injection_defect_detected(self):
        r = next(x for x in rows_of("T2") if x["status"] == "inject")
        bad = dict(r); bad["original_value"] = -999
        res = pipeline.run_pipeline(r["case_id"], BY_NO[r["invoice_no"]], "B0", CONST, faults.make_hook(bad))
        self.assertEqual(res.outcome, "CRASHED")
        self.assertIn("InjectionError", res.error)


class TestConditions(unittest.TestCase):
    def test_clean_cases_commit_everywhere_and_match_oracle(self):
        for inv in INVS:
            ref = oracle.reference_record(inv, CONST.l_pence)
            for cond in pipeline.CONDITIONS:
                res = pipeline.run_pipeline(f"{inv.invoice_no}-CLEAN", inv, cond, CONST)
                self.assertEqual(res.outcome, "COMMITTED", (inv.invoice_no, cond, res.halt_detail))
                self.assertEqual(res.commit_record, ref)

    def test_b0_never_halts_and_runs_no_rules(self):
        for r in manifest():
            if r["status"] == "skipped":
                continue
            res = run(BY_NO[r["invoice_no"]], r, "B0")
            self.assertEqual(res.outcome, "COMMITTED")
            self.assertEqual(res.applications, {})

    def test_f_runs_only_final_and_i_runs_all(self):
        r = next(x for x in rows_of("CLEAN"))
        inv = BY_NO[r["invoice_no"]]
        self.assertEqual(set(run(inv, r, "F").applications), {"FINAL"})
        self.assertEqual(set(run(inv, r, "I").applications), {"CP1", "CP2", "CP3", "FINAL"})

    def test_expected_catching_checkpoints(self):
        """T1/T2/T3 -> CP1; T4 -> CP2; T5 -> CP3 under I (same rule ids every time, derived by hand)."""
        expect = {"T1": "CP1", "T2": "CP1", "T3": "CP1", "T4": "CP2", "T5": "CP3"}
        for r in manifest():
            if r["status"] != "inject":
                continue
            res = run(BY_NO[r["invoice_no"]], r, "I")
            self.assertEqual((res.outcome, res.halt_checkpoint), ("HALTED", expect[r["fault_type"]]), r["case_id"])
            self.assertIsNone(res.commit_record)                     # nothing committed, nothing repaired

    def test_f_misses_faults_that_final_rules_cannot_see(self):
        """T4 (wrong amount, consistent total) passes the final gate whenever the total stays in range and the decision matches."""
        t4 = [r for r in rows_of("T4") if r["status"] == "inject"]
        committed = [run(BY_NO[r["invoice_no"]], r, "F") for r in t4]
        self.assertTrue(any(x.outcome == "COMMITTED" for x in committed))

    def test_final_validation_identical_in_f_and_i(self):
        """Whenever F halts at a record, I also halts (M9 validity): same record, same final rules."""
        for r in manifest():
            if r["status"] == "skipped":
                continue
            inv = BY_NO[r["invoice_no"]]
            f, i = run(inv, r, "F"), run(inv, r, "I")
            if f.outcome == "HALTED":
                self.assertEqual(i.outcome, "HALTED", r["case_id"])
            if f.outcome == "COMMITTED" and i.outcome == "COMMITTED":
                self.assertEqual(f.commit_record, i.commit_record)

    def test_halt_stops_later_stages(self):
        r = next(x for x in rows_of("T1") if x["params"]["target"] == "customer_id")
        res = run(BY_NO[r["invoice_no"]], r, "I")
        self.assertEqual(res.halt_rule, "R1.1")
        self.assertEqual(set(res.applications), {"CP1"})            # CP2, CP3 and FINAL never ran

    def test_unknown_condition_rejected(self):
        with self.assertRaises(ValueError):
            pipeline.run_pipeline("x", INVS[0], "F+", CONST)


class TestLedgerAndCrash(unittest.TestCase):
    def test_fresh_ledger_per_run(self):
        a = pipeline.Ledger(); a.append({"x": 1})
        self.assertEqual(len(pipeline.Ledger()), 0)
        recs = a.records; recs[0]["x"] = 99
        self.assertEqual(a.records[0]["x"], 1)                       # outside code cannot edit the ledger

    def test_runs_do_not_affect_each_other(self):
        inv = INVS[0]
        first = pipeline.run_pipeline("a", inv, "F", CONST)
        for other in INVS[1:6]:
            pipeline.run_pipeline("b", other, "F", CONST)
        again = pipeline.run_pipeline("a", inv, "F", CONST)
        self.assertEqual(first.to_log(), again.to_log())

    def test_crash_is_logged_not_repaired(self):
        def boom(stage, data):
            if stage == "S2":
                raise RuntimeError("boom")
            return data
        res = pipeline.run_pipeline("c", INVS[0], "I", CONST, boom)
        self.assertEqual((res.outcome, res.commit_record), ("CRASHED", None))
        self.assertIn("RuntimeError: boom", res.error)


class TestT4TopUp(unittest.TestCase):
    GOLDEN_A = "a10814a8cfab752d95d2f91eb2ed14e719ef982dacb7964beb22a3973e9e6fa7"   # recorded BEFORE the T4 change
    GOLDEN_B = "59b717074fe6f5bdf2e8b3130f39026f8ff730645134cf80755e1270acbd527c"

    def test_existing_manifests_are_byte_identical_to_before_the_change(self):
        a = faults.build_manifest(synth.make_invoices(40, seed=5, equal_price_every=7), CONST, seeding.make_rng(20261032))
        b = faults.build_manifest(synth.make_invoices(30, seed=11, equal_price_every=6), CONST, seeding.make_rng(20261031))
        self.assertEqual(faults.manifest_hash(a), self.GOLDEN_A)
        self.assertEqual(faults.manifest_hash(b), self.GOLDEN_B)

    def test_topup_takes_only_capable_invoices_in_order(self):
        reserve = synth.make_invoices(30, seed=77, start=500000, equal_price_every=2)
        rows = faults.build_t4_topup(reserve, 5, seeding.make_rng(3))
        self.assertEqual(len(rows), 5)
        capable_in_order = [i.invoice_no for i in reserve if len({l.unit_price_pence for l in i.lines}) >= 2][:5]
        self.assertEqual([r["invoice_no"] for r in rows], capable_in_order)
        for r in rows:
            self.assertEqual((r["fault_type"], r["status"], r["source"]), ("T4", "inject", "t4_reserve"))
            inv = next(i for i in reserve if i.invoice_no == r["invoice_no"])
            k, j = r["params"]["line_index"], r["params"]["other_line_index"]
            self.assertNotEqual(inv.lines[k].unit_price_pence, inv.lines[j].unit_price_pence)

    def test_topup_deterministic_and_zero_needed(self):
        reserve = synth.make_invoices(20, seed=78, start=600000)
        a = faults.build_t4_topup(reserve, 4, seeding.make_rng(9))
        b = faults.build_t4_topup(reserve, 4, seeding.make_rng(9))
        self.assertEqual(a, b)
        self.assertEqual(faults.build_t4_topup(reserve, 0, seeding.make_rng(9)), [])

    def test_topup_fails_loudly_when_reserve_too_small(self):
        reserve = synth.make_invoices(3, seed=79, start=700000, equal_price_every=1)    # none capable
        with self.assertRaises(ValueError):
            faults.build_t4_topup(reserve, 1, seeding.make_rng(1))

    def test_topup_rows_run_through_the_pipeline_like_other_t4_rows(self):
        reserve = synth.make_invoices(10, seed=80, start=800000)
        row = faults.build_t4_topup(reserve, 1, seeding.make_rng(2))[0]
        inv = next(i for i in reserve if i.invoice_no == row["invoice_no"])
        b0 = pipeline.run_pipeline(row["case_id"], inv, "B0", CONST, faults.make_hook(row))
        self.assertNotEqual(b0.commit_record["invoice_total"], oracle.reference_record(inv, CONST.l_pence)["invoice_total"])
        self.assertEqual(pipeline.run_pipeline(row["case_id"], inv, "I", CONST, faults.make_hook(row)).halt_checkpoint, "CP2")


if __name__ == "__main__":
    unittest.main()
