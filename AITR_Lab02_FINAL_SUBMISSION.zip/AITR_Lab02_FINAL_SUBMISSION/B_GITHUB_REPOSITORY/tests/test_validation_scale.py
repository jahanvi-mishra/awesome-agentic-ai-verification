"""Final validation at PRODUCTION SIZES on a synthetic pool (1,000 + 50 + 500 invoices, 2,600 in the pool).

Covers: T4 reserve top-up (500 T4 cases, capable invoices only, no reuse, deterministic order and seeds, other types unchanged),
independent recomputation of the metrics, M9 = 0, M1 + M2 = 1, bootstrap at invoice level, skipped and crashed cases,
and no overwriting of existing results. Synthetic data only: it says nothing about the real dataset.
"""

import copy
import hashlib
import json
import shutil
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import synth  # noqa: E402
from test_experiment import raw_frame  # noqa: E402

import score_results  # noqa: E402
from g1 import experiment, faults, metrics, protocol, runner, seeding, split  # noqa: E402

PROJECT = Path(__file__).resolve().parents[1]


def capable(inv):
    return len({l.unit_price_pence for l in inv.lines}) >= 2


class TestScale(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        cls.root = Path(cls.tmp.name)
        shutil.copytree(PROJECT / "configs", cls.root / "configs")
        cls.proto = protocol.load_protocol(cls.root)                       # the real protocol sizes: 1000 / 50 / 500
        cls.proto["pool"] = {"expected_pool_invoices": None, "expected_t4_capable_invoices": None}
        cls.invs = synth.make_invoices(2600, seed=31, equal_price_every=40)  # 2.5% have all prices equal
        cls.by = {i.invoice_no: i for i in cls.invs}
        experiment.prepare(raw_frame(cls.invs), cls.root, cls.proto)
        cls.sp = json.loads((cls.root / "results" / "splits.json").read_text())["subsets"]
        cls.summary = experiment.run_subset(cls.root, cls.proto, "evaluation")
        cls.manifest = json.loads((cls.root / "results" / "evaluation" / "manifest.json").read_text())
        cls.assigned = set().union(*map(set, cls.sp.values()))

    @classmethod
    def tearDownClass(cls):
        cls.tmp.cleanup()

    # ---------------------------------------------------------------- T4 reserve
    def test_sizes_are_the_protocol_sizes(self):
        self.assertEqual({k: len(v) for k, v in self.sp.items()}, {"calibration": 1000, "pilot": 50, "evaluation": 500})

    def test_exactly_500_t4_cases_all_on_capable_invoices(self):
        t4 = [r for r in self.manifest if r["fault_type"] == "T4" and r["status"] == "inject"]
        self.assertEqual(len(t4), 500)
        self.assertEqual(len({r["invoice_no"] for r in t4}), 500)
        self.assertTrue(all(capable(self.by[r["invoice_no"]]) for r in t4))
        self.assertEqual(self.summary["t4_cases_injected"], 500)

    def test_some_evaluation_invoices_were_not_capable_so_the_top_up_was_really_used(self):
        incapable = [n for n in self.sp["evaluation"] if not capable(self.by[n])]
        self.assertGreater(len(incapable), 0)
        self.assertEqual(self.summary["t4_cases_from_reserve"], len(incapable))
        skipped = [r for r in self.manifest if r["fault_type"] == "T4" and r["status"] == "skipped"]
        self.assertEqual(sorted(r["invoice_no"] for r in skipped), sorted(incapable))
        self.assertTrue(all(r["skip_reason"] == "all unit prices equal" for r in skipped))

    def test_no_reserve_invoice_comes_from_calibration_pilot_or_evaluation(self):
        reserve = [r["invoice_no"] for r in self.manifest if r.get("source") == "t4_reserve"]
        self.assertEqual(len(reserve), len(set(reserve)))
        self.assertFalse(set(reserve) & self.assigned)
        for name in ("calibration", "pilot", "evaluation"):
            self.assertFalse(set(reserve) & set(self.sp[name]), name)

    def test_reserve_order_is_the_deterministic_permutation_order(self):
        nos = [i.invoice_no for i in self.invs]
        order = split.reserve_after_split(nos, self.proto["seeds"]["split"], self.proto["sizes"])
        self.assertEqual(len(order), 2600 - 1550)
        expected = [n for n in order if capable(self.by[n])][: self.summary["t4_cases_from_reserve"]]
        self.assertEqual([r["invoice_no"] for r in self.manifest if r.get("source") == "t4_reserve"], expected)
        self.assertEqual(order, split.reserve_after_split(list(reversed(nos)), self.proto["seeds"]["split"], self.proto["sizes"]))

    def test_seed_behaviour(self):
        """Reserve invoices depend on the SPLIT seed only; the line choices depend on the FAULT seed only."""
        base_rows = [r for r in self.manifest if r.get("source") == "t4_reserve"]
        p2 = copy.deepcopy(self.proto); p2["seeds"]["faults"] += 1000
        rows2 = [r for r in experiment.build_subset_manifest(self.root, p2, "evaluation")[0] if r.get("source") == "t4_reserve"]
        self.assertEqual([r["invoice_no"] for r in rows2], [r["invoice_no"] for r in base_rows])      # same reserve invoices
        self.assertNotEqual([r["params"] for r in rows2], [r["params"] for r in base_rows])           # different fault draws
        again = [r for r in experiment.build_subset_manifest(self.root, self.proto, "evaluation")[0] if r.get("source") == "t4_reserve"]
        self.assertEqual(again, base_rows)                                                            # same seeds, same rows

    def test_t1_t2_t3_t5_are_unchanged_by_the_top_up(self):
        eval_invs = [self.by[n] for n in self.sp["evaluation"]]
        consts = experiment.RuleConstants.from_json(json.loads((self.root / "results" / "constants_calibration.json").read_text()))
        plain = faults.build_manifest(eval_invs, consts, seeding.make_rng(self.proto["seeds"]["faults"]))   # the pre-v0.5 builder
        keep = lambda rows: [r for r in rows if r["fault_type"] in ("CLEAN", "T1", "T2", "T3", "T5") or r["fault_type"] == "T4" and r.get("source") != "t4_reserve"]
        self.assertEqual(keep(self.manifest), plain)                       # every non-top-up row identical, T4 skips included
        self.assertEqual(faults.manifest_hash(keep(self.manifest)), faults.manifest_hash(plain))
        for ft in ("T1", "T2", "T3"):
            self.assertEqual(sum(r["fault_type"] == ft and r["status"] == "inject" for r in self.manifest), 500)

    def test_rerun_is_identical(self):
        self.assertTrue(experiment.verify_rerun(self.root, self.proto, "evaluation")["identical"])

    # ---------------------------------------------------------------- metrics against an independent recomputation
    def test_metrics_match_an_independent_recomputation(self):
        src = self.root / "results" / "evaluation"
        logs = [json.loads(l) for l in (src / "runs.jsonl").read_text().splitlines()]
        labels = {json.loads(l)["case_id"]: json.loads(l)["label"] for l in (src / "labels.jsonl").read_text().splitlines()}
        out = {(l["case_id"], l["condition"]): l for l in logs}
        faulty = [r for r in self.manifest if r["status"] == "inject"]
        clean = [r for r in self.manifest if r["status"] == "clean"]
        harmful = [r for r in faulty if labels[r["case_id"]] == "harmful"]
        scored = [r for r in faulty if labels[r["case_id"]] in ("harmful", "benign")]
        o = lambda r, c: out[(r["case_id"], c)]["outcome"]
        exp = {"M1F": sum(o(r, "F") == "COMMITTED" for r in harmful), "M1I": sum(o(r, "I") == "COMMITTED" for r in harmful),
               "M3F": sum(o(r, "F") == "HALTED" for r in scored), "M3I": sum(o(r, "I") == "HALTED" for r in scored),
               "M4F": sum(o(r, "F") == "HALTED" for r in clean), "M4I": sum(o(r, "I") == "HALTED" for r in clean),
               "M7": sum(o(r, "F") == "COMMITTED" and o(r, "I") == "HALTED" for r in harmful),
               "M8": sum(o(r, "F") == "COMMITTED" and o(r, "I") == "COMMITTED" for r in harmful),
               "M9": sum(o(r, "F") == "HALTED" and o(r, "I") == "COMMITTED" for r in harmful),
               "benign": sum(labels[r["case_id"]] == "benign" for r in faulty)}
        S = metrics.compute(self.manifest, logs, [{"case_id": k, "label": v, "fault_type": ""} for k, v in labels.items()], self.proto["seeds"], None, resamples=100)["metrics_summary"]
        get = lambda m, s: next(r for r in S if r["metric"] == m and r["scope"] == s)
        self.assertEqual((get("M1", "F")["numerator"], get("M1", "I")["numerator"], get("M1", "F")["denominator"]), (exp["M1F"], exp["M1I"], len(harmful)))
        self.assertEqual((get("M3", "F")["numerator"], get("M3", "I")["numerator"], get("M3", "F")["denominator"]), (exp["M3F"], exp["M3I"], len(scored)))
        self.assertEqual((get("M4", "F")["numerator"], get("M4", "I")["numerator"], get("M4", "I")["denominator"]), (exp["M4F"], exp["M4I"], len(clean)))
        self.assertEqual((get("M7", "all")["numerator"], get("M8", "all")["numerator"], get("M9", "all")["numerator"]), (exp["M7"], exp["M8"], exp["M9"]))
        self.assertEqual(get("M11", "all")["numerator"], exp["benign"])
        self.assertEqual(len(clean), 500)
        self.assertEqual(exp["M4F"] / len(clean), get("M4", "F")["value"])          # false-positive rate = halted clean / clean
        self.assertEqual(exp["M9"], 0)

    def test_m1_plus_m2_is_one_without_crashes_and_m9_is_zero(self):
        src = self.root / "results" / "evaluation"
        logs = [json.loads(l) for l in (src / "runs.jsonl").read_text().splitlines()]
        self.assertFalse([l for l in logs if l["outcome"] == "CRASHED"])
        lab = [json.loads(l) for l in (src / "labels.jsonl").read_text().splitlines()]
        S = metrics.compute(self.manifest, logs, lab, self.proto["seeds"], None, resamples=100)["metrics_summary"]
        for c in ("F", "I"):
            m1 = next(r for r in S if r["metric"] == "M1" and r["scope"] == c)["value"]
            m2 = next(r for r in S if r["metric"] == "M2" and r["scope"] == c)["value"]
            self.assertAlmostEqual(m1 + m2, 1.0)
        self.assertEqual(next(r for r in S if r["metric"] == "M9")["numerator"], 0)

    # ---------------------------------------------------------------- no overwriting
    def test_scoring_never_modifies_existing_results_and_never_overwrites(self):
        src = self.root / "results" / "evaluation"
        files = ["manifest.json", "manifest.sha256", "runs.jsonl", "labels.jsonl", "summary.json"]
        digest = lambda: {f: hashlib.sha256((src / f).read_bytes()).hexdigest() for f in files}
        before = digest()
        score_results.score(self.root, "evaluation", self.proto, resamples=50)
        self.assertEqual(before, digest())
        with self.assertRaises(FileExistsError):
            score_results.score(self.root, "evaluation", self.proto, resamples=50)
        with self.assertRaises(FileExistsError):
            experiment.run_subset(self.root, self.proto, "evaluation")
        self.assertEqual(before, digest())


class TestMetricEdgeValidation(unittest.TestCase):
    SEEDS = {"split": 1, "faults": 2, "missed_case_review": 3, "bootstrap": 4}

    @staticmethod
    def log(cid, cond, out, cp=None, rule=None, apps=0):
        return {"case_id": cid, "condition": cond, "outcome": out, "halt_checkpoint": cp, "halt_rule": rule, "halt_detail": None, "rule_applications": apps}

    def test_m9_is_zero_for_every_synthetic_dataset_and_seed(self):
        for seed in range(1, 9):
            invs = synth.make_invoices(40, seed=seed, equal_price_every=5)
            consts = split.calibration_constants(invs[:20])
            manifest = faults.build_manifest(invs[20:], consts, seeding.make_rng(seed))
            cases = runner.build_cases(invs[20:], manifest)
            logs = runner.run_cases(cases, consts)
            labels = runner.label_cases(cases, logs, consts)
            S = metrics.compute(manifest, logs, labels, self.SEEDS, None, resamples=30)["metrics_summary"]
            self.assertEqual(next(r for r in S if r["metric"] == "M9")["numerator"], 0, seed)

    def test_m1_plus_m2_below_one_when_a_harmful_case_crashes(self):
        manifest = [{"case_id": f"{k}-T1", "invoice_no": str(k), "fault_type": "T1", "status": "inject", "skip_reason": None} for k in range(4)]
        labels = [{"case_id": r["case_id"], "fault_type": "T1", "label": "harmful"} for r in manifest]
        logs = []
        for k, r in enumerate(manifest):
            logs += [self.log(r["case_id"], "B0", "COMMITTED"),
                     self.log(r["case_id"], "F", "CRASHED" if k == 0 else "COMMITTED"),
                     self.log(r["case_id"], "I", "HALTED", "CP1", "R1.1", 3)]
        S = metrics.compute(manifest, logs, labels, self.SEEDS, None, resamples=20)["metrics_summary"]
        g = lambda m, s: next(r for r in S if r["metric"] == m and r["scope"] == s)
        self.assertEqual((g("M1", "F")["numerator"], g("M2", "F")["numerator"], g("M1", "F")["denominator"]), (3, 0, 4))
        self.assertAlmostEqual(g("M1", "F")["value"] + g("M2", "F")["value"], 0.75)          # crashes are neither halted nor committed
        self.assertAlmostEqual(g("M1", "I")["value"] + g("M2", "I")["value"], 1.0)

    def test_false_positive_rate_uses_clean_cases_only(self):
        manifest, logs, labels = [], [], []
        for k in range(10):
            cid = f"{k}-CLEAN"
            manifest.append({"case_id": cid, "invoice_no": str(k), "fault_type": "CLEAN", "status": "clean", "skip_reason": None})
            labels.append({"case_id": cid, "fault_type": "CLEAN", "label": "reference_match"})
            logs += [self.log(cid, "B0", "COMMITTED"), self.log(cid, "F", "HALTED" if k == 0 else "COMMITTED", "FINAL", "RF.3"),
                     self.log(cid, "I", "HALTED" if k < 3 else "COMMITTED", "CP1", "R1.4")]
        T = metrics.compute(manifest, logs, labels, self.SEEDS, None, resamples=20)
        g = lambda s: next(r for r in T["metrics_summary"] if r["metric"] == "M4" and r["scope"] == s)
        self.assertEqual((g("F")["numerator"], g("F")["denominator"], g("F")["value"]), (1, 10, 0.1))
        self.assertEqual((g("I")["numerator"], g("I")["value"]), (3, 0.3))
        self.assertEqual(len(T["R5b_false_alarm_cases"]), 4)                                  # 1 under F + 3 under I
        self.assertEqual(next(r for r in T["R5_clean_false_alarms"] if r["condition"] == "I")["halted"], 3)

    def test_bootstrap_resamples_invoices_not_cases(self):
        """Invoice A has 10 harmful cases all reached under F; invoice B has 10 none reached. A case-level bootstrap
        would give a narrow interval around 0.5; an invoice-level bootstrap can only produce 0, 0.5 or 1."""
        manifest, logs, labels = [], [], []
        for inv, reached in (("A", True), ("B", False)):
            for j in range(10):
                cid = f"{inv}{j}-T1"
                manifest.append({"case_id": cid, "invoice_no": inv, "fault_type": "T1", "status": "inject", "skip_reason": None})
                labels.append({"case_id": cid, "fault_type": "T1", "label": "harmful"})
                logs += [self.log(cid, "B0", "COMMITTED"), self.log(cid, "F", "COMMITTED" if reached else "HALTED", None if reached else "FINAL", None if reached else "RF.2"),
                         self.log(cid, "I", "HALTED", "CP1", "R1.1")]
        m1 = next(r for r in metrics.compute(manifest, logs, labels, self.SEEDS, None, resamples=400)["metrics_summary"] if r["metric"] == "M1" and r["scope"] == "F")
        self.assertEqual((m1["value"], m1["ci_low"], m1["ci_high"]), (0.5, 0.0, 1.0))

    def test_skipped_cases_have_no_runs_and_are_counted_not_scored(self):
        manifest = [{"case_id": "1-T4", "invoice_no": "1", "fault_type": "T4", "status": "skipped", "skip_reason": "all unit prices equal"}]
        T = metrics.compute(manifest, [], [], self.SEEDS, None, resamples=10)
        self.assertEqual(T["cases_joined"], [])
        t4 = next(r for r in T["R2_per_type"] if r["type"] == "T4")
        self.assertEqual((t4["injected"], t4["skipped"], t4["harmful"]), (0, 1, 0))
        self.assertIn({"item": "T4 skipped", "count": 1, "description": "all unit prices equal"}, T["R8_exclusions_anomalies"])


if __name__ == "__main__":
    unittest.main()
