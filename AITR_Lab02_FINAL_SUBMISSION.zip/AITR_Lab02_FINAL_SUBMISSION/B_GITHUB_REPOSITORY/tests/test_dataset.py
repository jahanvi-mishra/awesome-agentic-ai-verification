"""Tests for g1.dataset_io and g1.audit on SMALL SYNTHETIC data (never the real dataset)."""

import json
import sys
import tempfile
import unittest
import zipfile
from datetime import datetime
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from g1 import audit, dataset_io  # noqa: E402


def synthetic_frame() -> pd.DataFrame:
    d = datetime(2010, 12, 1, 8, 26)
    rows = [
        ["536365", "85123A", "ITEM A", 6, d, 2.55, 17850.0, "United Kingdom"],
        ["536365", "71053", "ITEM B", 6, d, 3.39, 17850.0, "United Kingdom"],
        ["536366", "22633", "ITEM C", 6, d, 1.85, None, "United Kingdom"],      # missing customer
        ["C536379", "D", "Discount", -1, d, 27.5, 14527.0, "United Kingdom"],  # cancellation
        ["A563185", "B", "Adjust bad debt", 1, d, -11062.06, None, "united kingdom "],  # odd id, negative price, country variant
        ["536370", "22728", "ITEM D", 0, d, 3.75, 12583.0, "France"],          # zero quantity
        ["536370", "22728", "ITEM D", 0, d, 3.75, 12583.0, "France"],          # exact duplicate
    ]
    return pd.DataFrame(rows, columns=audit.EXPECTED_COLUMNS).astype(object)


class TestAudit(unittest.TestCase):
    def setUp(self):
        self.df = synthetic_frame()
        self.facts = audit.run_audit(self.df)

    def test_counts(self):
        self.assertEqual(self.facts["structure"]["rows"], 7)
        self.assertEqual(self.facts["duplicates"]["extra_copies_of_full_rows"], 1)
        self.assertEqual(self.facts["missing"]["CustomerID"]["missing"], 2)

    def test_invoice_patterns_and_cancellation(self):
        inv = self.facts["invoice_no"]
        self.assertEqual(inv["rows_pattern_C_plus_6_digits_cancellation"], 1)
        self.assertEqual(inv["rows_other_pattern"], 1)
        self.assertEqual(inv["other_pattern_examples"], ["A563185"])
        self.assertEqual(inv["cancelled_rows_with_negative_quantity"], 1)

    def test_numeric_flags(self):
        self.assertEqual(self.facts["quantity"]["zero"], 2)
        self.assertEqual(self.facts["quantity"]["negative"], 1)
        self.assertEqual(self.facts["unit_price"]["negative"], 1)

    def test_country_variant_detected(self):
        self.assertIn("united kingdom", self.facts["country"]["spelling_or_case_variants_of_same_name"])

    def test_audit_does_not_modify_frame(self):
        before = self.df.copy(deep=True)
        audit.run_audit(self.df)
        pd.testing.assert_frame_equal(before, self.df)

    def test_missing_required_column_rejected(self):
        with self.assertRaises(ValueError):
            audit.run_audit(self.df.drop(columns=["Country"]))

    def test_report_renders_and_is_json_safe(self):
        manifest = {"zip_members": [{"name": "x.xlsx", "size_bytes": 1, "crc32": "00000000"}]}
        meta = {"run_utc": "t", "scope": "FULL FILE", "sheet_names": ["s"], "sheet_read": "s", "integrity": {"ok": True}}
        text = audit.render_markdown(self.facts, manifest, meta)
        self.assertIn("Candidate invoice pool", text)
        json.dumps(self.facts)  # must not raise


class TestDatasetIO(unittest.TestCase):
    def test_url_whitelist(self):
        dataset_io.check_official_url(dataset_io.OFFICIAL_ZIP_URL)
        for bad in ("http://archive.ics.uci.edu/x.zip", "https://example.com/x.zip",
                    "https://archive.ics.uci.edu.evil.com/x.zip"):
            with self.assertRaises(dataset_io.DatasetError):
                dataset_io.check_official_url(bad)

    def test_register_verify_and_tamper_detection(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            tmp = Path(tmp)
            xlsx, zpath = tmp / "Online Retail.xlsx", tmp / "src.zip"
            synthetic_frame().to_excel(xlsx, index=False, engine="openpyxl")
            with zipfile.ZipFile(zpath, "w") as zf:
                zf.write(xlsx, "Online Retail.xlsx")
            raw = tmp / "raw"
            m = dataset_io.register_manual_zip(zpath, raw)
            self.assertEqual(m["xlsx_filename"], "Online Retail.xlsx")
            self.assertEqual(len(m["xlsx_sha256"]), 64)
            self.assertEqual(dataset_io.verify_manifest(raw)["xlsx_sha256"], m["xlsx_sha256"])
            # registering again must not overwrite anything
            self.assertEqual(dataset_io.register_manual_zip(zpath, raw)["zip_sha256"], m["zip_sha256"])
            # tamper: make writable, change a byte, expect a mismatch error
            target = raw / m["xlsx_filename"]
            target.chmod(0o644)
            with open(target, "ab") as fh:
                fh.write(b"x")
            with self.assertRaises(dataset_io.DatasetError):
                dataset_io.verify_manifest(raw)

    def test_non_zip_rejected(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            bad = Path(tmp) / "bad.zip"
            bad.write_text("<html>error page</html>")
            with self.assertRaises(dataset_io.DatasetError):
                dataset_io.register_manual_zip(bad, Path(tmp) / "raw")


if __name__ == "__main__":
    unittest.main()
