"""Tests 7, 9, 10 and logging: oracle independence, labelling, reproducibility, structured logs, protocol config."""

import ast
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import synth  # noqa: E402

from g1 import faults, oracle, pipeline, protocol, rules, runner, seeding  # noqa: E402

SRC = Path(__file__).resolve().parents[1] / "src" / "g1"
INVS = synth.make_invoices(30, seed=11, equal_price_every=6)
CONST = rules.RuleConstants(24, 1000, 10**6, frozenset(synth.COUNTRIES), 6000)


def imports_of(module: str) -> set:
    tree = ast.parse((SRC / f"{module}.py").read_text(encoding="utf-8"))
    found = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            found |= {a.name for a in node.names}
        elif isinstance(node, ast.ImportFrom):
            found.add(node.module)
            found |= {f"{node.module}.{a.name}" for a in node.names}
    return found


class TestIndependence(unittest.TestCase):
    def test_pipeline_and_rules_never_import_oracle_faults_or_runner(self):
        forbidden = ("g1.oracle", "g1.faults", "g1.runner", "g1.split", "g1.data_prep.select_pool")
        for mod in ("pipeline", "rules"):
            names = imports_of(mod)
            for bad in forbidden:
                self.assertFalse(any(n == bad or n.startswith(bad + ".") for n in names), f"{mod} imports {bad}")
            self.assertFalse(any("oracle" in n or "faults" in n for n in names), mod)

    def test_oracle_imports_no_pipeline_code(self):
        names = imports_of("oracle")
        self.assertFalse(any(n.startswith(("g1.pipeline", "g1.rules", "g1.faults", "g1.money")) for n in names))

    def test_rule_functions_take_no_manifest_or_label_arguments(self):
        import inspect
        for fn in (rules.cp1, rules.cp2, rules.cp3, rules.final_validation):
            params = set(inspect.signature(fn).parameters)
            self.assertFalse(params & {"manifest", "row", "fault", "label", "b0", "oracle", "reference"}, fn.__name__)

    def test_oracle_matches_decimal_hand_calculation(self):
        inv = INVS[0]
        total = sum(l.quantity * l.unit_price_pence for l in inv.lines)
        ref = oracle.reference_record(inv, 6000)
        self.assertEqual(ref["invoice_total"], total)
        self.assertEqual(ref["decision"], "POST" if total <= 6000 else "HOLD")

    def test_label_rules(self):
        ref = {"a": 1}
        self.assertEqual(oracle.label_fault("COMMITTED", {"a": 1}, ref), "benign")
        self.assertEqual(oracle.label_fault("COMMITTED", {"a": 2}, ref), "harmful")
        self.assertEqual(oracle.label_fault("CRASHED", None, ref), "crash")
        self.assertEqual(oracle.label_fault("HALTED", None, ref), "implementation_defect")


class TestRunnerAndReproducibility(unittest.TestCase):
    def setUp(self):
        self.manifest = faults.build_manifest(INVS, CONST, seeding.make_rng(20261031))
        self.cases = runner.build_cases(INVS, self.manifest)

    def test_same_cases_same_order_for_all_conditions(self):
        logs = runner.run_cases(self.cases, CONST)
        for k, case in enumerate(self.cases):
            chunk = logs[3 * k:3 * k + 3]
            self.assertEqual([c["case_id"] for c in chunk], [case.case_id] * 3)
            self.assertEqual([c["condition"] for c in chunk], ["B0", "F", "I"])

    def test_two_complete_runs_are_identical(self):
        h1 = runner.logs_hash(runner.run_cases(self.cases, CONST))
        again = faults.build_manifest(INVS, CONST, seeding.make_rng(20261031))
        h2 = runner.logs_hash(runner.run_cases(runner.build_cases(INVS, again), CONST))
        self.assertEqual(h1, h2)
        self.assertEqual(faults.manifest_hash(self.manifest), faults.manifest_hash(again))

    def test_run_logs_contain_no_fault_information(self):
        logs = runner.run_cases(self.cases[:12], CONST)
        text = json.dumps(logs)
        for word in ("fault_type", "faulty_value", "original_value", "harmful", "benign", "skip_reason"):
            self.assertNotIn(word, text)

    def test_jsonl_is_write_once_and_valid(self):
        logs = runner.run_cases(self.cases[:6], CONST)
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            path = Path(tmp) / "sub" / "runs.jsonl"
            digest = runner.write_jsonl(path, logs)
            self.assertEqual(digest, runner.logs_hash(logs))
            self.assertEqual([json.loads(l) for l in path.read_text().splitlines()], json.loads(json.dumps(logs, sort_keys=True)))
            with self.assertRaises(FileExistsError):
                runner.write_jsonl(path, logs)

    def test_labels_and_overall_sanity(self):
        logs = runner.run_cases(self.cases, CONST)
        labels = runner.label_cases(self.cases, logs, CONST)
        self.assertEqual(len(labels), len(self.cases))
        clean = [l for l in labels if l["fault_type"] == "CLEAN"]
        self.assertTrue(all(l["label"] == "reference_match" for l in clean))
        self.assertTrue(all(l["label"] in ("harmful", "benign") for l in labels if l["fault_type"] != "CLEAN"))
        self.assertTrue(any(l["label"] == "harmful" for l in labels))

    def test_m9_validity_on_synthetic_set(self):
        """No harmful case may be halted by F but committed by I."""
        logs = runner.run_cases(self.cases, CONST)
        by = {(l["case_id"], l["condition"]): l["outcome"] for l in logs}
        for c in self.cases:
            self.assertFalse(by[(c.case_id, "F")] == "HALTED" and by[(c.case_id, "I")] == "COMMITTED", c.case_id)

    def test_skipped_cases_are_not_run_but_stay_in_manifest(self):
        skipped = [r for r in self.manifest if r["status"] == "skipped"]
        self.assertTrue(skipped)
        run_ids = {c.case_id for c in self.cases}
        self.assertTrue(all(r["case_id"] not in run_ids for r in skipped))


class TestProtocolAndEdges(unittest.TestCase):
    def test_protocol_loads_and_seeds_reuse_existing_config(self):
        root = Path(__file__).resolve().parents[1]
        p = protocol.load_protocol(root)
        self.assertEqual(p["master_seed"], 20261029)
        self.assertEqual(p["seeds"], {"split": 20261030, "faults": 20261031, "missed_case_review": 20261032, "bootstrap": 20261033})
        self.assertEqual((p["sizes"]["calibration"], p["sizes"]["pilot"], p["sizes"]["evaluation"]), (1000, 50, 500))
        self.assertEqual(p["pool"]["expected_pool_invoices"], 17023)
        self.assertEqual(p["conditions"], ["B0", "F", "I"])

    def test_missing_protocol_file(self):
        with tempfile.TemporaryDirectory(ignore_cleanup_errors=True) as tmp:
            with self.assertRaises(FileNotFoundError):
                protocol.load_protocol(Path(tmp))

    def test_single_invoice_manifest_skips_t5(self):
        rows = faults.build_manifest(INVS[:1], CONST, seeding.make_rng(1))
        self.assertEqual([r["status"] for r in rows if r["fault_type"] == "T5"], ["skipped"])

    def test_empty_invoice_list(self):
        self.assertEqual(faults.build_manifest([], CONST, seeding.make_rng(1)), [])
        self.assertEqual(runner.run_cases([], CONST), [])

    def test_constants_json_roundtrip(self):
        self.assertEqual(rules.RuleConstants.from_json(CONST.to_json()), CONST)

    def test_garbage_inputs_do_not_crash_rules(self):
        """Rules must return a result, never raise, on odd input types."""
        for req in ({}, {"customer_id": "12345"}, {"customer_id": "12345", "lines": "x"}, {"customer_id": "12345", "lines": [{}]}):
            rules.cp1(req, CONST)
        self.assertFalse(rules.cp1({}, CONST).passed)                                     # no customer_id
        self.assertFalse(rules.cp1({"customer_id": "12345", "lines": [{}]}, CONST).passed)  # line lacks fields
        self.assertFalse(rules.final_validation({}, CONST).passed)
        rules.cp3({}, [], {})
        rules.cp2({}, [])

    def test_zero_line_request_passes_cp1_but_final_gate_rejects_it(self):
        """Spec: R1.2 is 'every line has...' (vacuous for 0 lines); the >= 1 line rule is RF.5 at the final gate."""
        self.assertTrue(rules.cp1({"customer_id": "12345", "lines": []}, CONST).passed)
        rec = {"invoice_no": "1", "customer_id": "12345", "country": "France", "n_lines": 0, "invoice_total": 0, "decision": "POST"}
        self.assertFalse(rules.final_validation(rec, CONST).passed)


if __name__ == "__main__":
    unittest.main()
