"""Integration test: synthetic raw table -> pool -> split -> constants -> pilot run -> single-run guard."""

import json
import shutil
import sys
import tempfile
import unittest
from datetime import datetime
from pathlib import Path

import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parent))
import synth  # noqa: E402

from g1 import data_prep, experiment, protocol  # noqa: E402

PROJECT = Path(__file__).resolve().parents[1]


def raw_frame(invoices):
    rows = []
    for inv in invoices:
        for l in inv.lines:
            rows.append([inv.invoice_no, l.stock_code, "desc", l.quantity, datetime(2010, 12, 1, 8, 26),
                         l.unit_price_pence / 100, float(inv.customer_id), inv.country])
    return pd.DataFrame(rows, columns=["InvoiceNo", "StockCode", "Description", "Quantity", "InvoiceDate",
                                       "UnitPrice", "CustomerID", "Country"]).astype(object)


class TestExperiment(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory(ignore_cleanup_errors=True)
        self.root = Path(self.tmp.name)
        shutil.copytree(PROJECT / "configs", self.root / "configs")
        self.proto = protocol.load_protocol(self.root)
        self.proto["sizes"] = {"calibration": 40, "pilot": 8, "evaluation": 20}     # small sizes for the test
        self.proto["pool"] = {"expected_pool_invoices": None, "expected_t4_capable_invoices": None}
        self.invs = synth.make_invoices(100, seed=21)
        self.df = raw_frame(self.invs)
        self.before = self.df.copy(deep=True)

    def tearDown(self):
        self.tmp.cleanup()

    def test_pool_roundtrip(self):
        pool, counts = data_prep.select_pool(self.df)
        self.assertEqual(pool, sorted(self.invs, key=lambda i: i.invoice_no))
        self.assertEqual(counts["pool_invoices"], 100)

    def test_prepare_then_pilot_then_guard(self):
        out = experiment.prepare(self.df, self.root, self.proto)
        pd.testing.assert_frame_equal(self.before, self.df)                          # raw table untouched
        sp = json.loads((self.root / "results" / "splits.json").read_text())
        subs = sp["subsets"]
        self.assertEqual({k: len(v) for k, v in subs.items()}, self.proto["sizes"])
        self.assertEqual(len(set(subs["calibration"]) & set(subs["evaluation"])), 0)
        # constants come from the calibration invoices only
        cal = [i for i in self.invs if i.invoice_no in set(subs["calibration"])]
        self.assertEqual(out["constants"]["q_max"], max(l.quantity for i in cal for l in i.lines))

        summary = experiment.run_subset(self.root, self.proto, "pilot")
        self.assertEqual(summary["invoices"], 8)
        self.assertEqual(summary["outcome_counts_by_condition"].get("B0_HALTED", 0), 0)
        self.assertEqual(summary["outcome_counts_by_condition"].get("F_CRASHED", 0), 0)
        pilot = self.root / "results" / "pilot"
        manifest_hash = (pilot / "manifest.sha256").read_text().strip()
        self.assertEqual(manifest_hash, summary["manifest_sha256"])
        with self.assertRaises(FileExistsError):                                       # single-run guard
            experiment.run_subset(self.root, self.proto, "pilot")

    def test_prepare_is_repeatable_and_deterministic(self):
        a = experiment.prepare(self.df, self.root, self.proto)
        b = experiment.prepare(self.df, self.root, self.proto)                          # identical content: allowed
        self.assertEqual((a["split_sha256"], a["base_lines_sha256"]), (b["split_sha256"], b["base_lines_sha256"]))

    def test_count_mismatch_stops_without_writing(self):
        self.proto["pool"] = {"expected_pool_invoices": 17023, "expected_t4_capable_invoices": None}
        with self.assertRaises(experiment.PoolCountMismatch):
            experiment.prepare(self.df, self.root, self.proto)
        self.assertFalse((self.root / "data" / "interim" / "base_lines.csv").exists())

    def test_bad_subset_name(self):
        with self.assertRaises(ValueError):
            experiment.run_subset(self.root, self.proto, "calibration")

    def test_split_uses_whole_pool_and_t4_only_from_capable_invoices(self):
        """No restriction of the pool or of other fault types; T4 only from T4-capable invoices, topped up from the reserve."""
        invs = synth.make_invoices(100, seed=21, equal_price_every=3)          # about a third have all prices equal
        capable = {i.invoice_no for i in invs if len({l.unit_price_pence for l in i.lines}) >= 2}
        self.assertLess(len(capable), 100)
        experiment.prepare(raw_frame(invs), self.root, self.proto)
        subs = json.loads((self.root / "results" / "splits.json").read_text())["subsets"]
        used = set().union(*map(set, subs.values()))
        self.assertTrue(used - capable, "split must include invoices that are NOT T4-capable")
        summary = experiment.run_subset(self.root, self.proto, "evaluation")
        manifest = json.loads((self.root / "results" / "evaluation" / "manifest.json").read_text())
        n_eval = len(subs["evaluation"])
        incapable_in_eval = [n for n in subs["evaluation"] if n not in capable]
        self.assertTrue(incapable_in_eval)
        # other fault types: one row per evaluation invoice, none restricted
        for ft in ("T1", "T2", "T3"):
            self.assertEqual({r["invoice_no"] for r in manifest if r["fault_type"] == ft and r["status"] == "inject"}, set(subs["evaluation"]))
        main_t4 = {r["invoice_no"]: r for r in manifest if r["fault_type"] == "T4" and r.get("source") != "t4_reserve"}
        self.assertEqual(set(main_t4), set(subs["evaluation"]))
        for n, r in main_t4.items():
            self.assertEqual(r["status"], "inject" if n in capable else "skipped")
        # top-up: capable invoices outside every subset, exactly the shortfall, so T4 reaches one case per evaluation invoice
        reserve_rows = [r for r in manifest if r.get("source") == "t4_reserve"]
        self.assertEqual(len(reserve_rows), len(incapable_in_eval))
        for r in reserve_rows:
            self.assertIn(r["invoice_no"], capable)
            self.assertNotIn(r["invoice_no"], used)
            self.assertEqual(r["status"], "inject")
        all_t4_inject = [r for r in manifest if r["fault_type"] == "T4" and r["status"] == "inject"]
        self.assertEqual(len(all_t4_inject), n_eval)
        self.assertTrue(all(r["invoice_no"] in capable for r in all_t4_inject))
        self.assertEqual(summary["t4_cases_injected"], n_eval)
        self.assertEqual(summary["t4_cases_from_reserve"], len(incapable_in_eval))
        self.assertTrue(experiment.verify_rerun(self.root, self.proto, "evaluation")["identical"])

    def test_pilot_manifest_is_unchanged_by_the_t4_fix(self):
        """Pilot path: no top-up, same rows as the plain manifest builder (existing pilot results stay valid)."""
        invs = synth.make_invoices(100, seed=21, equal_price_every=3)
        experiment.prepare(raw_frame(invs), self.root, self.proto)
        experiment.run_subset(self.root, self.proto, "pilot")
        from g1 import faults, seeding
        subs = json.loads((self.root / "results" / "splits.json").read_text())["subsets"]
        by = {i.invoice_no: i for i in invs}
        consts = experiment.RuleConstants.from_json(json.loads((self.root / "results" / "constants_calibration.json").read_text()))
        plain = faults.build_manifest([by[n] for n in subs["pilot"]], consts, seeding.make_rng(self.proto["seeds"]["faults"]))
        saved = (self.root / "results" / "pilot" / "manifest.sha256").read_text().strip()
        self.assertEqual(faults.manifest_hash(plain), saved)
        self.assertFalse(any(r.get("source") for r in json.loads((self.root / "results" / "pilot" / "manifest.json").read_text())))

    def test_only_capable_only_policy_is_allowed(self):
        self.assertEqual(protocol.T4_POLICIES, ("capable_only",))
        self.assertEqual(self.proto["t4_policy"], "capable_only")

    def test_undersized_pool_still_rejected_in_production_path(self):
        small = synth.make_invoices(50, seed=3)                                # needs 68 -> must fail loudly
        with self.assertRaises(ValueError):
            experiment.prepare(raw_frame(small), self.root, self.proto)

    def test_verify_rerun_detects_identical_and_tampered_logs(self):
        experiment.prepare(self.df, self.root, self.proto)
        experiment.run_subset(self.root, self.proto, "pilot")
        self.assertTrue(experiment.verify_rerun(self.root, self.proto, "pilot")["identical"])
        runs = self.root / "results" / "pilot" / "runs.jsonl"
        runs.chmod(0o644)
        runs.write_text(runs.read_text().replace("COMMITTED", "HALTED", 1))
        self.assertFalse(experiment.verify_rerun(self.root, self.proto, "pilot")["runs_identical"])


if __name__ == "__main__":
    unittest.main()
