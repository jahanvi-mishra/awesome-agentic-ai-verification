# Baseline validation report (B0 reference) — Revision 5

> **Assembly note (2026-11-10).** The text below is the Revision 5 validation report, **unchanged**. During final repository assembly only the following were re-checked, in the assembly sandbox:
> - Check 6: `python -m unittest discover -s tests` on a copy of the v0.6 code again printed `Ran 153 tests ... OK` (synthetic data only).
> - Checks 1-5: `scripts/verify_stored_results.py` (a new read-only script) recomputed the manifest hash, the runs hash, the label counts, the F/I commit counts, the clean false alarms and the rule-application totals from `results/stored_evaluation/`; all agreed. This shows the stored files agree with each other. It does **not** establish who produced them, when, or with which code version.
> - **Update (decisions file recovered):** `PROMPT07_FINAL_DECISIONS.txt` is now in the repository root (sha256 `abbe9037...931542`). Check 10 and the evidence cell of the table still say the file is the source of the counts; that is now **verified as stated in the file** (items 1 and 11 give 17,023 and 16,679). Check 10 remains UNKNOWN as an *independent derivation from the raw data*. The table below was not edited.
> - Check 7: the audit script and `eval_audit/audit_checks.csv` named below were **not** among the files supplied for assembly and are not in this repository (NOT VERIFIED here).
> - **Final-package resolution of the missing-file references (13 Nov 2026).** The Revision 5 report cites `audit_evaluation.py`, `eval_audit/audit_checks.csv` and `change_summary_rev5.md`. A search of every file supplied to this project (the v0.6 code package, the evaluation bundle, the Revision 5 package and the later uploads) found none of them; the evaluation bundle holds only `runs.jsonl`, `labels.jsonl`, `manifest.json`, `summary.json` and `manifest.sha256`. They are therefore reported as **not available** and nothing was recreated. The 57-check result is the author's report of a script that cannot be inspected. The checks that *can* be inspected here are: `scripts/verify_stored_results.py` (19 PASS lines: stored-file integrity and counts), `scripts/check_paper_vs_csv.py` (61 checks of the paper's numbers against `results/stored_evaluation/metrics/*.csv`, 0 failures), `scripts/h3_replay_check.py` (3,256 manifest-parameter replay matches) and the 153 unit tests (synthetic data, sandbox only). All of these test consistency of stored files, not a fresh experiment or an independent reproduction.
> - Checks 8, 10, 11, 12 and 13 stay UNKNOWN / as recorded: the Drive backup ZIP (dataset, source manifest, environment logs) named in the assembly brief was not in the workspace. The only environment log present is the pasted console output `results/logs/colab_env_check_console_2026-10-31.txt`.

**Study:** Designing Verification Checkpoints to Mitigate Silent Errors in Agentic AI Pipelines
**Status labels** (assignment brief, Section 6): VERIFIED = checked from the original source or an actual execution; INFERRED = plausible, needs testing; UNKNOWN = missing evidence.

## 1. What "baseline" means here

**No published baseline method is reproduced in this study.** The brief asks students to "reproduce or validate a trusted baseline"; for this study the nearest equivalent is **B0**, the pipeline run with all checks disabled. B0 is a *measurement reference*, not a published method and not a competing approach: it defines which injected faults are harmful (B0 commit record differs from the reference record). The comparators are F (final validation only) and I (CP1-CP3 plus the identical final validation).

Consequences for what may be claimed:

- Allowed: "B0 was checked for internal consistency against a separately implemented reference computation, on the author's own pipeline."
- Not allowed: "the baseline was reproduced", "validated against a published result", or "independently validated". Whether this equivalent-design justification is acceptable under the assignment is for the instructor to decide (the brief allows "an equivalent rigorous design when not [feasible]").

## 2. Validation checks

| # | Check | Result | Status | Evidence |
|---|---|---|---|---|
| 1 | On the 500 clean evaluation cases, the B0 commit record equals the reference record in every field | 500 of 500 labelled `reference_match`; 0 mismatches | VERIFIED (labels file in the evaluation bundle) | `evaluation/labels.jsonl`, `summary.json` (`label_counts`: reference_match 500) |
| 2 | Every injected fault changes the B0 commit record (so "harmful" is non-trivial) | 2,500 of 2,500 injected cases labelled `harmful`; 0 benign, 0 crashes | VERIFIED (same files) | `summary.json` (`label_counts`: harmful 2,500) |
| 3 | B0 applies no rule | 0 rule applications in all 3,000 B0 runs; B0 committed all 3,000 | VERIFIED | `R6_cost.csv`; `summary.json` (`B0_COMMITTED` 3,000) |
| 4 | Manifest hash matches the saved record | `faults.manifest_hash(manifest.json)` equals `manifest.sha256` (`ce58e5613cca…`), recomputed in this session | VERIFIED (shows the files match the record; does **not** show the manifest was fixed before results were viewed) | `evaluation/manifest.json`, `manifest.sha256` Re-checked 11 Nov 2026: also equals the recorded value in `docs/RECORDED_DATASET_HASHES.md`; the stored manifest parameters match a replay of seed 20261031 (3,256 checks, 0 mismatches) - consistency only, H3 still unconfirmed (`docs/H3_EVIDENCE_REPORT.md`). |
| 5 | Run-file hash matches the summary | SHA-256 of `runs.jsonl` equals `runs_sha256` in `summary.json` (5380db45…) | VERIFIED | `summary.json`. Also equals the recorded runs hash (11 Nov 2026). |
| 6 | Unit and integration tests pass | 153 tests, OK, re-run in this session's sandbox on the v0.6 package (synthetic data only) | VERIFIED for the sandbox; NOT run by the author or on the real dataset in Colab by me | `tests/` |
| 7 | Recomputation of all primary tables from case-level files | 57 consistency checks, none failing (audit script written for this study) | VERIFIED as a recomputation; **not an independent audit** | `eval_audit/audit_checks.csv`, `audit_evaluation.py` (**these two files are NOT in this repository, so the 57-check claim cannot be inspected here**; `scripts/verify_stored_results.py`, which is included, re-checks the stored files and passes) |
| 8 | Determinism: a second execution gives identical outputs | The code provides `verify-rerun`; whether it was run on the evaluation is not recorded | UNKNOWN | author's Colab log (not available) |
| 9 | Rules cannot read the fault manifest, reference module or B0 | Stated by design in the code structure and tests (rules receive stage data and constants only) | INFERRED from code design; a targeted read of `rules.py`/`pipeline.py` by the author is recommended | `src/g1/rules.py`, `pipeline.py` |
| 10 | Eligibility counts (17,023 invoices; 16,679 T4-capable) | Taken from the author's decisions file; enforced by a count check in code | UNKNOWN as an independent derivation (report not available) | `PROMPT07_FINAL_DECISIONS.txt`; eligibility report UNKNOWN |
| 11 | Calibration constants (L, Q_max, P_max, T_max, country set) | Q_max and T_max cross-checked from outputs; L bracketed by clean totals; P_max, country set and exact L from the project brief | PARTLY VERIFIED; constants file UNKNOWN | see manuscript Section 5.2 |
| 12 | Pilot run and its use | Pilot was for debugging only by protocol; results not available | UNKNOWN | — |
| 13 | Environment | One Colab CPU check on 2026-10-31 18:29 UTC: 13 PASS, 1 WARN (Drive persistence), 0 FAIL; Python 3.13.18; numpy 2.1.3, pandas 2.2.3, matplotlib 3.10.0, openpyxl 3.1.5, pytest 8.4.2 | VERIFIED for that runtime and day (user-supplied console output, as recorded in `ENVIRONMENT_VERIFICATION_LOG.md`) | `docs/ENVIRONMENT_VERIFICATION_LOG.md` |

## 3. Limits of this validation

1. **Common-mode risk.** The pipeline, reference module, rules, tests and audit script were all written by the same author with the same AI assistance. Agreement (checks 1, 7) shows that the modules are consistent with each other, not that they are correct with respect to an external truth. A shared misreading of the invoice logic (for example, of how a line amount should be computed) would pass every check.
2. **The reference module is not independent.** It is separately implemented code (exact-decimal recomputation), written in the same project. The manuscript calls it a "reference module" and says so.
3. **Synthetic tests only.** The 153 tests use synthetic data; the real-data behaviour rests on the evaluation outputs (checks 1-5).
4. **No published comparison.** There is no reported number to compare with, so none of the usual "discrepancy with reported results" analysis applies.

## 4. Additional checks that would strengthen the validation (not done)

- Author reads `oracle.py` against the invoice rules and signs off the arithmetic (about 30 lines of logic).
- Run `verify-rerun evaluation` in Colab and paste the output (expected: identical).
- A second person reruns `prepare`, `evaluate`, `score_results` from the README **[TEST REQUIRED]**.
- Hand-check a small random sample of clean and faulty cases (for example 10 each) against the raw invoice rows.
- Supply the eligibility report and `constants_calibration.json` so checks 10 and 11 can move from UNKNOWN to VERIFIED.

## 5. Items needing correction

None found in the evaluation outputs in this review. The wording corrections made in Revision 5 (no "independent oracle", "independent audit", "frozen" or "pre-specified" where the evidence does not support them) are listed in `change_summary_rev5.md` (**not included in this repository**; see `paper/change_log_rev5_2_1.md` for the revision log that is included).
