# START HERE

1. **Paper:** `A_RESEARCH_PAPER/manuscript_rev5_2_1.pdf`
2. **Code:** `B_GITHUB_REPOSITORY/`
3. **Actual stored evidence:** `C_EXPERIMENTAL_EVIDENCE/stored_evaluation/`
4. **Research decisions and provenance:** `D_RESEARCH_PROVENANCE/`
5. **Demo and viva:** `E_DEMO_AND_VIVA/DEMO_SCRIPT_5MIN.md` and `E_DEMO_AND_VIVA/VIVA_SHEET.md`

For code execution, read `B_GITHUB_REPOSITORY/START_HERE.md` first. It documents the project entry point, tested commands and untested workflow steps.

**Do not claim a fresh reproduction of the full real-data experiment.** The included evidence register lists original records that were not present in the supplied archive.
