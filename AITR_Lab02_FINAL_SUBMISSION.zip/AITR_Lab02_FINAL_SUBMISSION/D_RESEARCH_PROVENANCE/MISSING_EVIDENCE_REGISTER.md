# Missing / unavailable evidence register

This register is included to make the submission transparent. The missing original records cannot be recreated from the supplied ZIP without inventing evidence.

## Not present in the supplied project archive

1. **Original full Colab experiment execution log** for the complete `prepare` / `pilot` / `evaluate` / scoring workflow.
2. **Original pilot output and pilot inspection record**.
3. **Original calibration constants file/report** (for example, a source file recording all calibrated values and their derivation).
4. **Original protocol-freeze / pre-evaluation approval record** establishing that the protocol was frozen before evaluation.
5. **Original raw dataset source manifest and dataset audit report** (`SOURCE_MANIFEST.json` and generated audit output).
6. **Original Drive backup ZIP** referenced in project notes.
7. **The previously referenced audit script and audit CSV** (`audit_evaluation.py`, `eval_audit/audit_checks.csv`) and the earlier change summary file.
8. **Independent reproduction of the full real-data experiment**. The available stored outputs have consistency checks, but these do not constitute a fresh independent rerun.

## What is included instead (actual available evidence)

- Stored evaluation bundle: runs, labels, manifest, summary, manifest hash and metric CSVs.
- Stored result figures and checksum file.
- Available Colab environment-check console log dated 2026-10-31.
- Available read-only stored-result verification script and reports.
- Available paper-to-CSV consistency checker and recorded result map.
- 153 synthetic-data unit tests (reported as run in the assembly sandbox; not a full real-data reproduction).
- H3 replay consistency report and output.

## Important interpretation

Do not describe missing records as recovered, generated, or verified. Do not present stored-output consistency checks as proof that the original full experiment was independently reproduced. The final paper and the stored result files are preserved unchanged.
