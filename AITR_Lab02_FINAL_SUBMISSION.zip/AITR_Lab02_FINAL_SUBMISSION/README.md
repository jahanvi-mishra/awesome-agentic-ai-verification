# AITR Lab 02 – Final Submission

**Project:** Designing Verification Checkpoints to Mitigate Silent Errors in Agentic AI Pipelines  
**Author:** Jahanvi Mishra, IIIT Allahabad

This package is organised into the five submission deliverable groups.

## Folder guide

- `A_RESEARCH_PAPER/` – final paper PDF, source, bibliography, figures and supplementary material. The supplied paper files are copied unchanged.
- `B_GITHUB_REPOSITORY/` – complete original project repository, including source code, scripts, tests, notebooks, configuration, README and requirements.
- `C_EXPERIMENTAL_EVIDENCE/` – actual stored evaluation outputs, metrics, figures, checksums and available validation/environment records.
- `D_RESEARCH_PROVENANCE/` – research decisions, AI assistance disclosure, baseline validation, protocol and implementation records, traceability documents, and a missing-evidence register.
- `E_DEMO_AND_VIVA/` – five-minute demo guide, viva sheet and start guide.

## Start

1. Read `E_DEMO_AND_VIVA/START_HERE.md`.
2. For the code and exact run instructions, open `B_GITHUB_REPOSITORY/README.md` and `B_GITHUB_REPOSITORY/START_HERE.md`.
3. The project identifies `scripts/run_experiment.py` as its experiment entry point. Follow its documented subcommands and stop conditions; do not assume a full experiment has been rerun.
4. See `D_RESEARCH_PROVENANCE/MISSING_EVIDENCE_REGISTER.md` for unavailable original records.

## Evidence status

The stored evaluation outputs are included. Their internal consistency has been checked using the included scripts and reports. The full original real-data experiment has **not** been independently reproduced from the raw dataset in this package. Missing source records are explicitly listed; none have been fabricated.

The original project files and final paper assets are preserved. The A–E folders are an organisational copy for submission; the complete original repository remains under `B_GITHUB_REPOSITORY/`.
