"""Checkpoint-responsibilities figure of the manuscript (Figure 2). Conceptual: drawn only from the documented design
(src/g1/rules.py, pipeline.py); no result is plotted. Derived from the Revision 5 conceptual-figure script, redrawn with
larger text and the wording 'reference module'. Usage: python make_checkpoint_figure.py [output_dir]"""
import sys, textwrap
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})
OUT = (sys.argv[1] if len(sys.argv) > 1 else "figures") + "/"
wrap = lambda t, n: "\n".join(textwrap.fill(p, n) for p in t.split("\n"))

def box(ax, x, y, w, h, text, fc="white", fs=9, bold=False):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0,rounding_size=0.06", fc=fc, ec="black", lw=1.0))
    ax.text(x + w / 2, y + h / 2, text, ha="center", va="center", fontsize=fs, fontweight="bold" if bold else "normal", linespacing=1.25)

def arrow(ax, p, q):
    ax.add_patch(FancyArrowPatch(p, q, arrowstyle="-|>", mutation_scale=10, lw=1.0, color="black"))

cols = [
    ("CP1", "after S1", "the request\n(S1 output)", "R1.1-R1.4\nfields present,\ntypes valid,\nvalues in range"),
    ("CP2", "after S2", "line amounts and\noriginal request", "R2.1-R2.2\namounts recomputed\nfrom quantity and\nunit price"),
    ("CP3", "after S3", "state, amounts and\noriginal request", "R3.1-R3.3\nidentifiers, line count,\ntotal agree with\nrequest and amounts"),
    ("Final", "in S4", "commit record only\n(not the request)", "RF.1-RF.6\nschema, CustomerID,\ncountry, total range,\nline count, decision"),
]
fig, ax = plt.subplots(figsize=(7.2, 3.9))
ax.set_xlim(0, 10); ax.set_ylim(0, 5.6); ax.axis("off")
w, gap, x0 = 2.3, 0.2, 0.1
for i, (n, where, obs, chk) in enumerate(cols):
    x = x0 + i * (w + gap)
    fc = "#e6e6e6" if n == "Final" else "white"
    box(ax, x, 4.35, w, 0.8, f"{n}\n{where}", fc=fc, fs=10, bold=True)
    box(ax, x, 2.85, w, 1.0, "Observes:\n" + obs, fs=7.8)
    box(ax, x, 0.75, w, 1.7, "Checks:\n" + chk, fc=fc, fs=7.8)
    arrow(ax, (x + w / 2, 4.35), (x + w / 2, 3.85))
    arrow(ax, (x + w / 2, 2.85), (x + w / 2, 2.45))
ax.text(5.0, 5.45, "Information available to each check in condition I (the final validation also runs in condition F)", ha="center", fontsize=9, fontweight="bold")
ax.text(5.0, 0.25, "Rules see only the data available at their own point plus the calibration constants; they cannot access the fault manifest,\nthe reference module or B0. A run halts at the first failed rule. No repair, retry or rollback.",
        ha="center", fontsize=8, va="center", linespacing=1.3)
fig.savefig(OUT + "fig_checkpoint_responsibilities.png", dpi=300, bbox_inches="tight", facecolor="white")
print("ok")
