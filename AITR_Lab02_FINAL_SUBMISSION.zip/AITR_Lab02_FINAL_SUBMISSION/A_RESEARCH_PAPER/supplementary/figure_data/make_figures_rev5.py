#!/usr/bin/env python3
"""Regenerate the five evaluation figures from the saved metric CSVs (read-only on inputs).
Usage: python make_figures.py <evaluation_dir>/metrics <out_dir>
Every plotted number is read from a CSV and written to figure_source_values.csv. Nothing is computed that is not
a direct read, except percentages (count/denominator) and the per-condition false-alarm percentage labels."""
import sys
from pathlib import Path
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

M, OUT = Path(sys.argv[1]), Path(sys.argv[2]); OUT.mkdir(parents=True, exist_ok=True)
CF, CI_ = "#0072B2", "#D55E00"                      # colour-blind-safe blue / vermillion
plt.rcParams.update({"font.size": 11, "axes.spines.top": False, "axes.spines.right": False, "savefig.dpi": 300, "figure.dpi": 120})
R1, R2, R4, R5, R6 = (pd.read_csv(M / f) for f in ("R1_primary.csv", "R2_per_type.csv", "R4_halting_attribution.csv", "R5_clean_false_alarms.csv", "R6_cost.csv"))
MS = pd.read_csv(M / "metrics_summary.csv"); src = []
def rec(fig, label, value, source): src.append(dict(figure=fig, item=label, value=value, source=source))
def lab(ax, x, y, text, **k): ax.annotate(text, (x, y), ha="center", va="bottom", xytext=(0, 3), textcoords="offset points", **k)

# Fig 1: primary result, with 95% invoice-level bootstrap CI and counts
fig, ax = plt.subplots(figsize=(7, 4.6))
for i, (c, col) in enumerate((("F", CF), ("I", CI_))):
    r = R1[R1.condition == c].iloc[0]; v = r.M1_rate * 100
    ax.bar(i, v, color=col, width=0.55)
    ax.errorbar(i, v, yerr=[[v - r.ci_low * 100], [r.ci_high * 100 - v]], color="black", capsize=5, lw=1.2)
    lab(ax, i, r.ci_high * 100 + 1.5, f"{int(r.reached_commit_n):,}/{int(r.harmful_N):,} = {v:.2f}%", fontsize=10)
    rec("fig1", f"{c} reached commit", f"{int(r.reached_commit_n)}/{int(r.harmful_N)}; CI {r.ci_low:.6f}-{r.ci_high:.6f}", "R1_primary.csv")
d = R1.iloc[2]; rec("fig1", "F minus I (points)", f"{d.M1_rate}; CI {d.ci_low}-{d.ci_high}", "R1_primary.csv")
ax.set_xticks([0, 1], ["Final-only (F)", "Intermediate + final (I)"]); ax.set_ylim(0, 100); ax.set_ylabel("Reached commit (% of harmful cases)", labelpad=8)
ax.set_title("Harmful cases reaching commit", fontsize=11, pad=10)
ax.set_xlim(-0.6, 1.6)
ax.text(0.5, -0.2, f"2,500 harmful cases: 2,490 from the 500 evaluation invoices,\n10 T4 cases from reserve invoices. Error bars: 95% invoice-level percentile bootstrap.\nF minus I = {d.M1_rate:.2f} points (95% CI {d.ci_low:.2f} to {d.ci_high:.2f}). I: 0 of 2,500 reached commit.", transform=ax.transAxes, ha="center", va="top", fontsize=8)
fig.tight_layout(); fig.savefig(OUT / "fig1_primary_result_v2.png", bbox_inches="tight"); plt.close(fig)

# Fig 2: per fault type, Wilson 95% CI from metrics_summary M6
fig, ax = plt.subplots(figsize=(8, 4.6)); w = 0.38
for j, (c, col, nm) in enumerate((("F", CF, "Final-only (F)"), ("I", CI_, "Intermediate + final (I)"))):
    for i, t in enumerate(R2["type"]):
        m = MS[(MS.metric == "M6") & (MS.scope == f"{t}/{c}")].iloc[0]; v = m.value * 100; x = i + (j - 0.5) * w
        ax.bar(x, v, w, color=col, label=nm if i == 0 else None)
        ax.errorbar(x, v, yerr=[[v - m.ci_low * 100], [m.ci_high * 100 - v]], color="black", capsize=3, lw=1)
        lab(ax, x, m.ci_high * 100 + 1, f"{int(m.numerator)}/{int(m.denominator)}", fontsize=8); rec("fig2", f"{t}/{c}", f"{int(m.numerator)}/{int(m.denominator)}; Wilson {m.ci_low:.6f}-{m.ci_high:.6f}", "metrics_summary.csv (M6)")
ax.set_xticks(range(5), R2["type"]); ax.set_ylim(0, 112); ax.set_ylabel("Harmful cases reaching commit (%)")
ax.set_xlabel("Fault type (500 injected harmful cases each)"); ax.set_title("Harmful cases reaching commit, by fault type", fontsize=11, pad=28); ax.legend(frameon=False, loc="lower center", bbox_to_anchor=(0.5, 1.0), ncol=2)
ax.text(0.5, -0.24, "Error bars: Wilson 95% intervals (cases treated as independent within a type). Zero counts for I are labelled 0/500.", transform=ax.transAxes, ha="center", fontsize=8)
fig.tight_layout(); fig.savefig(OUT / "fig2_fault_types_v2.png", bbox_inches="tight"); plt.close(fig)

# Fig 3: where I halted the harmful cases, by fault type (R4), stacked by first failing checkpoint
fig, ax = plt.subplots(figsize=(7, 4.4)); bottom = [0] * len(R4); cols = {"CP1": "#0072B2", "CP2": "#E69F00", "CP3": "#009E73", "FINAL": "#999999"}
for cp in ("CP1", "CP2", "CP3", "FINAL"):
    ax.bar(R4["type"], R4[cp], bottom=bottom, color=cols[cp], label=cp)
    for i, (v, b) in enumerate(zip(R4[cp], bottom)):
        if v: ax.text(i, b + v / 2, f"{v}", ha="center", va="center", color="white", fontsize=9, fontweight="bold")
    bottom = [b + v for b, v in zip(bottom, R4[cp])]; rec("fig3", cp, R4[cp].tolist(), "R4_halting_attribution.csv")
ax.set_ylim(0, 640); ax.set_ylabel("Harmful cases halted under I (count)"); ax.set_xlabel("Fault type"); ax.legend(title="First failing checkpoint", frameon=False, ncol=4, loc="upper center")
ax.set_title("Condition I: checkpoint that halted each harmful case (FINAL: 0 of 2,500)", fontsize=11)
fig.tight_layout(); fig.savefig(OUT / "fig3_checkpoint_attribution_v2.png", bbox_inches="tight"); plt.close(fig)

# Fig 4: rule-application cost, mean per run over all 3,000 runs
fig, ax = plt.subplots(figsize=(6, 4.2)); r6 = R6.set_index("condition")
for i, (c, col) in enumerate((("F", CF), ("I", CI_))):
    v = r6.loc[c, "mean_per_run"]; ax.bar(i, v, color=col, width=0.55); lab(ax, i, v, f"{v:.2f}\n({int(r6.loc[c, 'total_rule_applications']):,} / 3,000 runs)"); rec("fig4", c, f"{v}; total {int(r6.loc[c, 'total_rule_applications'])}", "R6_cost.csv")
ax.set_xticks([0, 1], ["Final-only (F)", "Intermediate + final (I)"]); ax.set_ylim(0, 90); ax.set_ylabel("Mean rule applications per run")
ax.set_title(f"Rule-application cost (I/F = {r6.loc['I', 'ratio_to_F']:.2f}x)", fontsize=11)
ax.text(0.5, -0.2, "Mean over all 3,000 runs (500 clean + 2,500 faulty). A rule application is one rule evaluation;\nthis is not measured runtime. Runs stop at the first failed rule, so halted runs apply fewer rules.", transform=ax.transAxes, ha="center", va="top", fontsize=8)
fig.tight_layout(); fig.savefig(OUT / "fig4_overhead_v2.png", bbox_inches="tight"); plt.close(fig)

# Fig 5: clean false alarms with Wilson CI
fig, ax = plt.subplots(figsize=(6, 4.2))
for i, (c, col) in enumerate((("F", CF), ("I", CI_))):
    r = R5[R5.condition == c].iloc[0]; v = r.M4_rate * 100
    ax.bar(i, v, color=col, width=0.55); ax.errorbar(i, v, yerr=[[v - r.ci_low * 100], [r.ci_high * 100 - v]], color="black", capsize=5, lw=1.2)
    lab(ax, i, r.ci_high * 100 + 0.1, f"{int(r.halted)}/{int(r.clean_cases)} = {v:.1f}%"); rec("fig5", c, f"{int(r.halted)}/{int(r.clean_cases)}; Wilson {r.ci_low:.6f}-{r.ci_high:.6f}", "R5_clean_false_alarms.csv")
ax.set_xticks([0, 1], ["Final-only (F)", "Intermediate + final (I)"]); ax.set_ylim(0, 5); ax.set_ylabel("Clean cases halted (%)")
ax.set_title("False alarms on 500 clean cases", fontsize=11)
ax.text(0.5, -0.2, "Same 10 clean cases in both conditions, all halted at the final validation\n(8 country not in allowed set, 2 invoice_total above T_max). Error bars: Wilson 95%.", transform=ax.transAxes, ha="center", va="top", fontsize=8)
fig.tight_layout(); fig.savefig(OUT / "fig5_false_alarms_v2.png", bbox_inches="tight"); plt.close(fig)
pd.DataFrame(src).to_csv(OUT / "figure_source_values.csv", index=False); print("wrote", sorted(p.name for p in OUT.iterdir()))
