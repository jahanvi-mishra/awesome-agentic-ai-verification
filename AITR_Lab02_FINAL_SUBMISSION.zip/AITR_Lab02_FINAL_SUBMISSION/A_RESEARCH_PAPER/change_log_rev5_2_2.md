# Revision 5.2.2 change log (12 November 2026)

Claims, length and structure only. No result, number, denominator, table value, figure data, seed or constant was changed. Details: `docs/CHANGE_REPORT_FINAL.md`.

1. Section 9 (Reproducibility): historical Colab claim made author-reported; stored results distinguished from currently available consistency evidence; no fresh run, no second-person re-run.
2. Section 10 (AI disclosure): "the approved decisions file" replaced by the recovered protocol text plus an unsigned retrospective decision record; AI did not run Colab.
3. Sections 5.1, 5.5, 8 (item 13), 11: status notes (raw hashes not re-checked, audit script not in the project files, draw order unconfirmed, results not independently reproduced).
4. Length: body exactly 10 pages excluding references (13 in total). Final package: fuller Related Work, per-type Figure 3, false-alarm detail and run-level classification values restored to the main paper; a conceptual Figure 2 (checkpoint responsibilities, no results) added; abstract states that results are stored, not independently reproduced. The supplement now holds only methodology detail and extended discussion.
5. Rebuilt with `build_acm52_1.py` (main) and `build_supplement_text.py` (supplement); acmsmall class, fonts and margins unchanged.
