-- Lua filter: captions from preceding "**Table N.**" / following "**Figure N.**" paragraphs; tables as p{} tabulars
local function tex(blocks)
  local s = pandoc.write(pandoc.Pandoc(blocks), 'latex'):gsub('%s+$', ''):gsub('\n', ' ')
  return s
end
local function plain(inl) return pandoc.utils.stringify(inl) end
local function caption_text(para)
  -- drop the leading "**Table N.**" strong and following space
  local inl = para.content
  local rest = {}
  for i = 2, #inl do rest[#rest+1] = inl[i] end
  if rest[1] and rest[1].t == 'Space' then table.remove(rest, 1) end
  return pandoc.write(pandoc.Pandoc({pandoc.Plain(rest)}), 'latex'):gsub('%s+$', ''):gsub('\n', ' ')
end
local function is_cap(b, word)
  return b.t == 'Para' and b.content[1] and b.content[1].t == 'Strong' and plain(b.content[1]):match('^' .. word .. ' %d+')
end
local function table_tex(tbl, cap)
  local ncol = #tbl.colspecs
  local rows = {}
  local head = tbl.head.rows
  local maxlen = {}
  for i = 1, ncol do maxlen[i] = 4 end
  local function addrow(r, bold)
    local cells = {}
    for i, c in ipairs(r.cells) do
      local t = plain(c.contents)
      if #t > maxlen[i] then maxlen[i] = #t end
      local s = tex(c.contents)
      if bold and s ~= '' then s = '\\textbf{' .. s .. '}' end
      cells[#cells+1] = s
    end
    rows[#rows+1] = table.concat(cells, ' & ') .. ' \\\\'
  end
  local hr = {}
  for _, r in ipairs(head) do addrow(r, true); hr[#hr+1] = #rows end
  local nh = #rows
  for _, body in ipairs(tbl.bodies) do for _, r in ipairs(body.body) do addrow(r, false) end end
  local wsum = 0
  local w = {}
  for i = 1, ncol do w[i] = math.max(15, math.min(maxlen[i], 50)); wsum = wsum + w[i] end
  local spec = {}
  for i = 1, ncol do spec[#spec+1] = string.format('>{\\raggedright\\arraybackslash}p{\\dimexpr(\\columnwidth-%d\\tabcolsep)*%d/1000\\relax}', 2*ncol, math.floor(985 * w[i] / wsum)) end
  local out = {'\\begin{table}[htbp]', '\\centering\\small', '\\caption{' .. cap .. '}', '\\begin{tabular}{' .. table.concat(spec) .. '}', '\\toprule'}
  for i, r in ipairs(rows) do
    out[#out+1] = r
    if i == nh then out[#out+1] = '\\midrule' end
  end
  out[#out+1] = '\\bottomrule'; out[#out+1] = '\\end{tabular}'; out[#out+1] = '\\end{table}'
  return pandoc.RawBlock('latex', table.concat(out, '\n'))
end
local function image_of(b)
  if b.t == 'Figure' then
    local pl = b.content[1]
    if pl and pl.content and pl.content[1] and pl.content[1].t == 'Image' then return pl.content[1] end
  elseif b.t == 'Para' and #b.content == 1 and b.content[1].t == 'Image' then return b.content[1] end
  return nil
end
function Pandoc(doc)
  local out = {}
  local bl = doc.blocks
  local i = 1
  while i <= #bl do
    local b = bl[i]
    local nxt = bl[i+1]
    if is_cap(b, 'Table') and nxt and nxt.t == 'Table' then
      out[#out+1] = table_tex(nxt, caption_text(b)); i = i + 2
    elseif image_of(b) and nxt and is_cap(nxt, 'Figure') then
      local img = image_of(b)
      local wd = '0.92'
      local f = img.src
      if f:match('fig2_reach_commit') then wd = '0.64' end
      if f:match('fig_checkpoint') then wd = '0.68' end
      if f:match('fig1_pipeline') then wd = '0.9' end
      local cap = caption_text(nxt)
      local descs = {
        fig1_pipeline = 'Diagram of the four pipeline stages S1 to S4, the points where faults T1 to T5 are injected, and which checks run in conditions B0, F and I.',
        fig_checkpoint = 'Four columns CP1, CP2, CP3 and Final, each showing what the check observes and which rules it applies.',
        fig2_reach_commit = 'Grouped bar chart of the share of harmful cases reaching commit for each fault type T1 to T5 under F and I.'
      }
      local desc = ''
      for k, v in pairs(descs) do if f:match(k) then desc = v end end
      local s = '\\begin{figure}[htbp]\n\\centering\\includegraphics[width=' .. wd .. '\\columnwidth]{' .. f .. '}\n\\caption{' .. cap .. '}\n\\Description{' .. desc .. '}\n\\end{figure}'
      out[#out+1] = pandoc.RawBlock('latex', s); i = i + 2
    else
      out[#out+1] = b; i = i + 1
    end
  end
  return pandoc.Pandoc(out, doc.meta)
end
