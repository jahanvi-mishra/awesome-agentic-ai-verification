# Revision 5.2.1 change log (figure corrections only)

## Changes
1. **Figure 2 restored (Rev 5.1 Figure 4, reach-commit rate by fault type).** The existing PNG is used byte-for-byte (verified with `cmp` against the Rev 5.1 file). It sits at the end of Section 6.2 with a caption and an in-text reference ("Figure 2 plots the per-type rates"). Two sentences were added: one states the pattern (F about half for T1 and T3, about 98% for T2, T4, T5; I zero for all), the other ties the lower rates to the two types that include a variant visible in the commit record alone, using counts already in that paragraph. No table row was repeated.
2. **Figure 1 kept and made more readable.** Displayed at full text width (was 92%). The two footnote lines were cropped off the bottom of the PNG (rows 1130 and below, a blank band; the remaining 1,780 by 1,130 pixels are identical to the original, checked pixel by pixel) and moved verbatim into the caption. The diagram itself is unchanged. Note: the in-figure italic note about silent defaults stays in the diagram.
3. **Supplementary figures.** `supplementary_figures.pdf` (2 pages) holds Figure S1 (old Figure 3, primary result) and Figure S2 (old Figure 6, rule-application cost), plus source CSVs and the plotting script. They are not cited in the main text.
4. **Not inserted in the main paper:** old Figures 2, 5 and 7, as instructed. Their files are in `archive_unused_figures/`.
5. **Filenames and numbering.** Main figures are numbered in order of appearance (Figure 1, Figure 2); supplementary figures are S1 and S2; no filename starts with a number that conflicts with the manuscript numbering. Alt text keys were updated.
6. **Caption corrections.** The draft note ("layout revised in Revision 5") is gone with the old Figure 3 caption; the supplementary S1 caption is clean.
7. **Terminology corrections not applied, because the figures are not retained:** "oracle" (old Figure 2) and `invoice_total` (old Figure 7 note) remain in the archived PNGs. Correcting them needs the plotting or drawing script to be rerun, which would be a recreation of the figure; do that only if you decide to include either figure.

## Not changed
Experimental data, methodology, constants, seeds, tables (table lines compared: identical), references (37; citation set identical), limitations, wording elsewhere. Every number in Rev 5.2 is still present.

## Checks performed
- Figure references: the text refers to Figure 1 and Figure 2 only; both exist and both captions appear in the PDF in that order (page 5 and page 9). No dangling references; no undefined-reference warnings.
- Numbering and captions: Fig. 1, Fig. 2 in the main PDF; Fig. S1, Fig. S2 in the supplement.
- Plotted values: the Figure 2 labels (249, 490, 257, 488, 488 of 500 for F; 0/500 for I) and the S1 and S2 labels (1,972/2,500, 0/2,500, 5.46, 71.41) match the CSVs and the main tables. I read the printed labels; I did not regenerate or measure bars.
- UNKNOWN: whether the saved CSVs are identical to the original Colab outputs (only the bundle copies are available).

## Page count
Total 14 pages. Main text about 11.6 pages (was about 11.1 in Rev 5.2): the restored figure and the larger Figure 1 cost about 0.5 page. References about 2.1 pages. The 6-10 page target is still not met.

## Prompt 15.3 corrections (final wording)
- Section 1: "decision rules recorded in the protocol text before the evaluation (the date is not recorded)" became "decision rules recorded in the available protocol text (their freeze date is not recorded)".
- Section 8, limitation 1: "so M9 = 0 and equal false-alarm rates follow largely by construction" became: "and I's checks are nested with F's, so M9 = 0 (no harmful case caught only by F) follows by construction. The equal false-alarm rates do not follow by construction: they were observed here because CP1-CP3 raised no false alarms on the clean cases, so the same ten clean cases were halted at the shared final validation in both conditions."
- Final build: 14 pages total; main text about 11.7 pages; references about 2.1 pages. Supplement: 2 pages, Figures S1 and S2.
