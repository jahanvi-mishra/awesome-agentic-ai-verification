# Designing Verification Checkpoints to Mitigate Silent Errors in Agentic AI Pipelines

**Jahanvi Mishra**
Indian Institute of Information Technology Allahabad (IIIT Allahabad), Prayagraj, India
Guide: Prof. Sonali Agarwal


## Abstract

In a multi-stage automated pipeline, an early stage can emit a wrong value that every later stage accepts, so the wrong result is committed without any error being raised. We report a controlled fault-injection study of one remedy, deterministic verification checkpoints placed between stages. A deterministic four-stage Python pipeline turns UCI Online Retail invoices into entries in a simulated ledger, and five fault types are injected, one per case. On 500 held-out invoices plus 10 reserve invoices (2,500 harmful and 500 clean cases) we compare a checks-disabled reference (B0), final-output validation only (F), and three intermediate checkpoints plus the identical final validation (I). Under F, 1,972 of 2,500 harmful cases (78.88%) reached commit; under I, none (0 of 2,500), a difference of 78.88 percentage points (95% invoice-level bootstrap interval 77.24 to 80.39). Both conditions halted the same 10 of 500 clean cases (2.0%); I applied 13.07 times as many rules per run. These are stored evaluation results from an earlier run; they have not been independently reproduced. The checkpoints were written for the injected fault types, so the result shows coverage of this taxonomy in a simulation, not general detection ability. Position, information and rule count are confounded; the study has no ablation, no wall-clock measurement, no LLM agent and no reproduction of a published baseline.

**Keywords:** silent errors; verification checkpoints; fault injection; deterministic validation; error containment; multi-stage pipelines


## 1. Introduction

In a multi-stage pipeline a stage can return a wrong value without signalling failure; no later stage has a reason to question it, and the error can reach a final action. We call such an undetected incorrect value a *silent error*. The term comes from hardware silent data corruption [@dixit2021; @hochschild2021], and LLM-agent failure taxonomies include task verification [@cemri2025]. We do not study such agents; we study the mechanism where every step is deterministic and every fault is known, so what reaches the final action can be counted.

Validating only the final output is limited by what the last stage can see: a line amount computed with the wrong unit price gives a total that is too small but still positive and below the upper limit, so every rule on the commit record is satisfied, whereas a check after S2 can recompute each amount from the request. We ask how many injected harmful faults reach a simulated ledger commit under final-only and under intermediate-plus-final validation, at what cost in rule applications and false alarms, and for which fault types. The contribution is a narrow measurement for one pipeline and five fault types, with decision rules recorded in the available protocol text (their freeze date is not recorded); it is not a novel method (Section 2). It does not evaluate LLM agents, production systems or the author's earlier five-layer framework.

## 2. Related Work

A single researcher searched the web on 3 and 4 November 2026 without a written protocol, so the review is focused, not systematic; most sources were read at abstract level and several 2026 preprints are not peer reviewed.

Agent frameworks interleave reasoning, actions [@yao2023react] and tool use [@schick2023toolformer; @wu2023autogen] and are evaluated on task outcomes [@liu2024agentbench; @jimenez2024swebench; @yao2025taubench; @mohammadi2025survey; @yehudai2026survey]. τ-bench is closest to our setting: success is judged by comparing the final database state with an annotated goal state [@yao2025taubench]. As far as the abstracts show, these works score outcomes and do not vary where verification is placed inside a run.

Other work studies failures and injected faults. Cemri et al. analyse more than 1,600 traces from seven multi-agent frameworks and report a failure taxonomy that includes task verification, without isolating any particular check [@cemri2025]. ToolEmu emulates tool execution with a language model [@ruan2024toolemu]; AgentChaosBench injects ten fault types and asks whether they can be located from traces [@zhang2026chaos]; AgentProp-Bench replaces a tool parameter with a schema-valid but wrong value, measures propagation to a wrong answer and tests a runtime interceptor against a control [@gurram2026agentprop]; verified tool calls add postcondition checks, evaluated in a simulator with injected failures that include recording an invoice [@mansoor2026verified]; and GuardianAgentBench reports an execution-time guardrail that recovers some agent failures while rarely flagging correct behaviour [@naik2026guardian]. The last four are preprints; this paper claims novelty for neither fault injection nor runtime checks. Automated red teaming [@perez2022redteam] could supply unanticipated fault types (Section 11).

Process supervision gives feedback on intermediate reasoning steps [@uesato2022process; @lightman2023verify], building on chain-of-thought prompting [@wei2022cot]; self-consistency compares sampled reasoning paths [@wang2023sc]. Language models also serve as judges [@zheng2023judge], factuality checkers [@manakul2023selfcheck; @min2023factscore], retrieval evaluators [@es2024ragas] and verifier writers [@yin2026verifierbench]. These checks are learned or generated, mostly on text; ours are fixed rules over structured records, so this literature is context, not comparator. The closer background is classical: runtime verification [@leucker2009rv], fault injection [@hsueh1997fi], chaos engineering [@basiri2016chaos], data-validation tooling [@schelter2018dq] and the end-to-end argument [@saltzer1984e2e], which holds that a function that can be implemented completely only with the help of the endpoints cannot be provided by lower layers alone. Our setting is an analogue, not a test of it: the final validation plays the endpoint check and the checkpoints are earlier checks whose benefit and cost we measure.

This paper builds on an earlier conceptual manuscript by the author [@mishra_unpub] (unpublished, non-independent), which supplies terminology only, proposes a five-layer framework and reports no experiment; the present experiment does not evaluate that framework. None of the descriptions we read reports a controlled comparison of final-only with intermediate-plus-final validation under identical final rules, a checks-disabled harm reference and cost counted in rule applications, but **we do not claim that such a comparison is absent from the literature, and the literature examined does not establish a research gap.**

## 3. Problem Statement and Research Questions

A four-stage pipeline transforms a request into a committed record. A fault is *harmful* if the record committed with all checks disabled (B0) differs in any field from a separately computed reference record (Section 5.4); it either reaches the ledger commit (*reach-commit*) or is *contained* (the run halts before commit).

**Primary research question.** Does adding intermediate deterministic checkpoints to a four-stage Python pipeline reduce the harmful injected faults that reach a simulated ledger commit, compared with final-only validation?

This is the wording of project protocol v0.1; the Prompt 07 v0.2 text and any record of when the protocol was fixed were not available. Table 1 gives the decision rules as written in v0.1 and implemented in analysis table R9.

**Table 1.** Research questions and decision rules (protocol v0.1 wording).

| ID | Question | Decision rule |
|---|---|---|
| RQ1 | Does I reduce harmful faults reaching commit relative to F? | F minus I reach-commit difference at least 10 percentage points and 95% interval excludes 0 |
| RQ2 | Which fault types escape final-only validation? | At least 4 of 5 dated per-type predictions correct ("escapes F": at least 10% of that type's harmful cases reach commit) |
| RQ3 | What does I cost? | Acceptable if false-positive rate at most 2% and at most F's plus 2 points; cost reported with no threshold |

**RQ2 was not evaluated:** it needs a dated predictions file written before the evaluation, and none was found; per-type rates in Section 6.2 are descriptive.

## 4. Verification Framework

### 4.1 Pipeline and conditions

The implementation is deterministic Python with no language model. Figure 1 shows the stages, the fault entry points and the conditions. S1 parses an invoice into a request (customer ID, country, lines with stock code, quantity, unit price); S2 computes each line amount as quantity times unit price in integer pence; S3 computes the line count and the invoice total; S4 builds the commit record, decides POST if the total is at most L and otherwise HOLD, runs the final validation if enabled, and appends to a simulated ledger. A missing or unreadable value is read downstream as a silent default (0 for numbers, "UNKNOWN" for text), so a fault travels onward instead of crashing the run. Nothing is repaired, retried or rolled back; each run has a fresh ledger.

![Figure 1](figures/fig1_pipeline_and_conditions.png)

**Figure 1.** Experimental pipeline. (a) Stages S1-S4 and the points where faults T1-T5 are injected. (b) Conditions: B0 applies no rule, F only the final validation, I applies CP1-CP3 after S1-S3 and then the identical final validation. CP1, CP2 and CP3 check the S1, S2 and S3 outputs; the final validation sees only the commit record. A run halts at the first failed rule, and halted runs do not reach the ledger. The diagram shows the implemented experiment only (no planner, language model, tool call or recovery).

**B0** (checks disabled) is a measurement reference that decides whether an injected fault changes the committed record, not a competing method; no published method is used as a baseline.

### 4.2 Checkpoints and rules

Checks run in order and the run halts at the first failed rule, which is attributed to a checkpoint and rule. Only CP2 and CP3 compare a later value with an earlier one; the final validation checks that the commit record is well formed and plausible by itself. Rules see only the data available at their own point plus the calibration constants, never the fault manifest, reference module or B0. One *rule application* is one rule applied to one line or record; it is the cost measure, not runtime.

**Table 2.** Checkpoints and rules.

| Check | Applied to | Rules |
|---|---|---|
| CP1 | S1 output | R1.1 CustomerID present, five digits; R1.2 each line has stock code, quantity, unit price; R1.3 quantity integer, price numeric; R1.4 quantity in 1 to Q_max, price in (0, P_max] |
| CP2 | S2 output | R2.1 amount equals quantity times price recomputed exactly in integer pence; R2.2 amounts non-negative numbers |
| CP3 | S3 output | R3.1 invoice number, CustomerID, country equal the request's; R3.2 line count equals request lines; R3.3 total equals sum of line amounts |
| Final | Commit record only | RF.1 required fields and types; RF.2 CustomerID five digits; RF.3 country in allowed set; RF.4 total in (0, T_max]; RF.5 at least one line; RF.6 decision consistent with total and L |

![Figure 2](figures/fig_checkpoint_responsibilities.png)

**Figure 2.** What each check can observe in condition I. CP2 and CP3 see the original request as well as the stage output, so they can compare a computed value with its inputs; the final validation, which also runs in F, sees only the commit record. The diagram summarises Table 2 and the implemented rules; it shows no result.

## 5. Experimental Methodology

### 5.1 Dataset and eligibility

We use the UCI *Online Retail* dataset (ID 352) [@chen2015retail] (CC BY 4.0; 541,909 rows, 8 columns; retrieval date not recorded). Its raw-file SHA-256 hashes are in the author's notes and the project files, not re-checked against a fresh download.

The eligibility protocol (Scenario D) yields 17,023 invoices, of which 16,679 have at least two distinct unit prices and can host a T4 fault. Both figures come from the author's decisions record (`PROMPT07_FINAL_DECISIONS.txt`) and a pool-count check in the preparation code, and are not re-derived. An eligible invoice has a six-digit number, all rows valid (five-digit CustomerID, integer quantity, price exact to two decimals, no zero-pence line), one InvoiceDate and a unique full signature (duplicates collapsed). The implemented selection also requires at least two lines, a condition absent from the decisions record (Supplement S1). Money is in integer pence.

### 5.2 Split and calibration

A single seeded permutation of the sorted invoice numbers was divided into 1,000 calibration, 50 pilot and 500 evaluation invoices, with the remainder held as reserve. The master seed is 20261029, with derived seeds split 20261030, faults 20261031, missed-case review 20261032 and bootstrap 20261033; the seed file marks the master seed *provisional* and no approval record is available. The pilot (debugging only) is not reported.

Calibration constants come from the calibration invoices only: Q_max, P_max and T_max are the largest quantity, unit price and invoice total observed there, the allowed-country set is every country observed there, and L is their 90th percentile total (method "higher"). The values used are L = £812.16 (81,216 pence), Q_max = 2,400, P_max = 394,932 pence and T_max = 1,195,610 pence. The evaluation outputs are consistent with Q_max, T_max and L (Supplement S1); the calibration-constants file itself was not available.

### 5.3 Fault taxonomy and case composition

For every evaluation invoice a clean case was created, with one case each for T1, T2, T3 and T5 and a T4 case where the invoice allowed it. Faults come from a manifest built once, deterministically, before any condition runs; pipeline and checkpoints never see it. Each type enters at a stage boundary (Table 3) and draws a fixed number of random values per invoice from one seeded generator.

**Table 3.** Fault taxonomy.

| Type | Injected | Description (variants) |
|---|---|---|
| T1 | after S1 | CustomerID removed (about half the cases), or one line's unit price removed |
| T2 | after S1 | one quantity replaced by its digits followed by " pcs" |
| T3 | after S1 | one quantity made negative, or set to 10 × Q_max |
| T4 | after S2 | one line amount computed with the unit price of another line with a different price |
| T5 | after S3 | invoice total, or CustomerID, replaced by that of another invoice |

T4 needs two distinct unit prices. Ten of the 500 evaluation invoices were not T4-capable; their T4 attempts were logged as skipped and replaced by T4 cases on 10 T4-capable reserve invoices, so each type has 500 injected cases; these 10 have no clean counterpart. The 3,000 runnable cases are 500 clean cases, 2,000 T1/T2/T3/T5 cases (500 each), 490 T4 cases on evaluation invoices and 10 on reserve invoices. The 2,500 harmful cases belong to 510 distinct invoices, the bootstrap clusters; each case runs under B0, F and I (9,000 condition-runs).

### 5.4 Labelling harm and validation of B0

A reference module, implemented separately from the pipeline (same author, with AI assistance; not independent), recomputes the correct commit record from the original invoice in exact-decimal code. A faulty case is *harmful* if its B0 commit record differs from the reference in any field, and *benign* if identical. In the evaluation all 2,500 injected cases were harmful, all 500 clean B0 records matched the reference, and there were no crashes or benign cases. This is the validation of B0 here: an internal check, not a reproduction of a published baseline, and it would not reveal a misreading of invoice logic shared by both modules (Section 8, item 11).

### 5.5 Evaluation procedure, metrics, intervals and integrity checks

Each case was run under B0, F and I with a fresh ledger; how often the evaluation was executed and any freeze date are not recorded. Metrics M1-M11 include the reach-commit rate among harmful cases (M1; M1d is the F minus I difference), containment (M2), the clean false-positive rate (M4), rule applications (M5), per-type rates (M6) and halting attribution (M10).

Intervals are 95%. Single proportions (M4, M6) use Wilson intervals [@wilson1927]; pooled rates and differences use an invoice-level percentile bootstrap [@efron1979] with 2,000 resamples (seed 20261033) over the 510 invoices, with the same resample for F and I. For zero-event outcomes we also report the upper endpoint of the exact 95% Clopper-Pearson interval [@clopper1934], 1 − 0.025^(1/n), a post-hoc calculation distinct from the bootstrap. No hypothesis test was performed. The manifest and run files match a saved SHA-256 record (`manifest.sha256`), which shows consistency, not that they were fixed before results were viewed. An audit script by the same author recomputed all primary tables in 57 consistency checks, none failing; this is a recomputation, not an independent audit, and neither the script nor its output is in the project files.

## 6. Results

All numbers come from the stored evaluation outputs and their recomputation: 3,000 runnable cases (2,500 harmful, 500 clean), 9,000 condition-runs, no crashes (so M1 + M2 = 1).

### 6.1 Primary result

**Table 4.** Primary result.

| Cond. | Harmful cases reaching commit | Rate | 95% interval (bootstrap) | Contained |
|---|---|---|---|---|
| F | 1,972 / 2,500 | 78.88% | 77.24% to 80.39% | 528 (21.12%) |
| I | 0 / 2,500 | 0.00% | [0, 0] (degenerate) | 2,500 (100%) |

The F minus I difference is **78.88 percentage points** (95% interval 77.24 to 80.39). No harmful case was caught only by F (M9 = 0) and none was missed by both (M8 = 0). The bootstrap interval for I is degenerate (no resample contains an event) and carries no information. Post hoc, the exact 95% Clopper-Pearson upper endpoint for zero events is **0.15%** for n = 2,500 cases (optimistic: an invoice's cases are not independent) and **0.72%** for n = 510 invoices (assuming independent invoices). Neither is a bootstrap result or shows that the true rate is zero.

### 6.2 Results by fault type and halting checkpoint

**Table 5.** Results by fault type (500 injected cases each) and first halting checkpoint under I.

| Type | F reached commit | Wilson 95% (F) | I reached commit | First halt (I) | First failing rules (I) |
|---|---|---|---|---|---|
| T1 | 249 (49.8%) | 45.4% to 54.2% | 0 | CP1 (500) | R1.1 (244), R1.2 (256) |
| T2 | 490 (98.0%) | 96.4% to 98.9% | 0 | CP1 (500) | R1.3 (500) |
| T3 | 257 (51.4%) | 47.0% to 55.8% | 0 | CP1 (500) | R1.4 (500) |
| T4 | 488 (97.6%) | 95.9% to 98.6% | 0 | CP2 (500) | R2.1 (500) |
| T5 | 488 (97.6%) | 95.9% to 98.6% | 0 | CP3 (500) | R3.1 (263), R3.3 (237) |

F lets through about half of the T1 and T3 cases but about 98% of the T2, T4 and T5 cases; for I each type has 0/500 (Wilson upper bound 0.76%). Each type was first halted at its own checkpoint; a run stops at its first failure, so the counts do not show whether a later checkpoint would also have caught the case. Under F, all 244 missing-CustomerID cases were halted (RF.2) but 249 of 256 missing-unit-price cases reached commit; F halted 227 of 246 large-quantity T3 cases (mostly RF.4) but not 238 of 254 negative-quantity cases; its halts for T2, T4 and T5 (10, 12, 12) come from RF.3 and RF.4. The lower rates for T1 and T3 belong to the two types with a variant the final validation can recognise from the commit record alone. Figure 3 plots these values.

![Figure 3](figures/fig2_reach_commit_by_fault_type.png)

**Figure 3.** Share of harmful cases reaching commit for each fault type under F and I (500 injected cases per type), with counts and Wilson 95% intervals (cases treated as independent within a type). I is 0/500 for every type. The plotted values are those of Table 5.

### 6.3 Rule-application cost and false alarms

Rule applications over 3,000 runs per condition were 0 for B0, 16,390 for F (mean 5.46 per run; ratio 1.00) and 214,231 for I (mean 71.41; ratio to F 13.07), of which CP1 156,564, CP2 52,221, CP3 2,474 and final 2,972. The extra 197,841 applications were spent on clean runs (59,410, where every check completes) and harmful runs (138,431, where I stops at the first failure). Halted runs apply fewer rules: under I 61.19 on average against 123.74 for committed (all clean) runs; under F 3.01 against 6.00. Dividing the extra applications by the 1,972 additional harmful cases contained gives about 100 per case (derived; about 30% is spent on clean runs). **These are counts of rule applications, not runtime; no wall-clock measurement was made.**

Ten of 500 clean cases (2.0%; Wilson 95% interval 1.09% to 3.64%) were halted under both F and I: the same ten, all at the final validation after CP1-CP3 passed, each with a B0 record equal to the reference. Eight were halted by RF.3 (country not in the allowed set: Japan, Switzerland twice, Channel Islands, Malta, Denmark twice, USA) and two by RF.4 (totals of 1,915,066 and 1,564,377 pence, above T_max); CP1-CP3 raised none. These are clean invoices from countries absent from calibration or with totals above the calibration maximum. The two RF.4 invoices passed RF.3 first, so their countries (Netherlands, Australia) are in the allowed set.

*Run-level classification values* (supplementary): with harmful as positive and halted as predicted positive, TP 528, FN 1,972, FP 10, TN 490 for F and TP 2,500, FN 0, FP 10, TN 490 for I. Recall (21.12%, 100%) and specificity (98.0%, 98.0%) equal M3 and 1 - M4; precision (98.14%, 99.60%), accuracy (33.93%, 99.67%) and F1 (34.76%, 99.80%) depend on the fixed 5:1 class ratio and are not headline measures.

**Summary.** RQ1: rule met (difference 78.88 points; interval 77.24 to 80.39). RQ3: met, with the I estimate exactly on the 2% limit. RQ2: not evaluated.

## 7. Discussion

**Why final-only validation misses most faults.** The final validation reads only the commit record. For T2, T4, a missing unit price and most T5 cases, the record differed from the reference only in a total that stayed positive and below the limit, or in a CustomerID that was still five digits, so no final rule was violated. That this is *why* F misses them is inferred, not tested.

**What the checkpoints add.** F's own catches were limited to a missing CustomerID and quantities large enough to exceed T_max. CP2 and CP3 compare a stage's output with the original request, which the final validation never receives, and contained every injected fault that record-only rules could not see. The 100% containment reflects checkpoints written for the injected taxonomy (Section 8, item 1).

**What the comparison cannot attribute.** The difference cannot be assigned to placement alone: I differs from F in position, information and rule count (about 13 times as many applications). The sensitivity condition F+ proposed in protocol v0.1 (a final gate recomputing the total from the original lines) was not run.

**Cost and false alarms.** I's cost grows with line count (per-line rules in CP1 and CP2); real costs were not measured. The false alarms come from the shared final validation and are inferred to be a calibration limitation (not confirmed against the missing calibration-constants file).

## 8. Threats to Validity and Limitations

1. **Taxonomy alignment and shared final validation.** CP1-CP3 were written for T1-T5; no unseen fault type was tested. I's checks are nested with F's, so M9 = 0 follows by construction; the equal false-alarm rates were observed.
2. **Confounding; no ablation; F+ not run.** Position, information and rule count are confounded; checkpoint necessity was not tested.
3. **No wall-clock or resource measurement.** Rule applications differ in real cost.
4. **RQ2 not evaluated.** The dated predictions file was not found.
5. **Calibration-derived false alarms.** The country set and total limit come from 1,000 invoices.
6. **Deterministic simulation.** No language model, nondeterminism, recovery, multi-fault interaction or real error process; this is not an LLM-agent evaluation, and [@mishra_unpub] is not implemented.
7. **Single run, seed and dataset.** Variation across fault draws or splits is not measured beyond bootstrap resampling; one retailer; no production test.
8. **Harm definition.** Of 2,490 harmful cases with a clean counterpart, 302 changed the POST/HOLD decision (T1 2, T2 9, T3 234, T4 17, T5 40); the other 2,188 had an incorrect total or CustomerID with the same decision. Claims concern incorrect records, not wrong postings.
9. **Reserve T4 cases.** Ten single-case clusters with no clean counterpart; nine reached commit under F.
10. **Intervals.** Per-type and false-alarm intervals treat cases as independent; the bootstrap handles invoice clustering (design effect about 1.16). No p-value was computed.
11. **Common-mode risk.** Pipeline, rules, reference module and tests share an author and AI assistance; their agreement shows consistency, not correctness against an external truth.
12. **No published baseline reproduced.** B0 validation is internal (Section 5.4).
13. **Incomplete records.** Pilot results, the calibration-constants file, eligibility report, raw-data manifest and retrieval date, seed approval, any freeze record, the original Colab logs and the number of evaluation executions were not available. The fault draw order is consistent with the stored files but not confirmed (Section 9).
14. **Literature.** Focused, not systematic, mostly abstract-level, with non-peer-reviewed preprints.

## 9. Reproducibility and Availability

The code is a Python package (`g1`) with configuration files (`configs/protocol_v1_0.json`, `configs/seeds.json`), scripts for dataset audit, preparation, pilot, evaluation, determinism re-run and scoring, 153 unit tests on synthetic data (passing in the sandbox used to prepare this paper, not in Colab) and `requirements.txt` (minimum versions only). The dataset comes from the UCI repository [@chen2015retail] and is not redistributed.

*Historical execution claim.* The author reports that the evaluation outputs reported here were produced by running the documented sequence (`prepare`, `evaluate --confirm-freeze`, `verify-rerun evaluation`, `score_results.py evaluation`) in a Google Colab session. No log of that run, pilot output or calibration-constants file is available, so the execution is not independently documented and the results are reported as *stored evaluation results*.

*Evidence currently available.* Read-only checks on the stored files found that the manifest and run-file hashes equal the saved record and the values recorded by the author, that the stored files are mutually consistent, and that 3,256 draw-dependent manifest parameters match a replay of the documented fault seed (20261031) and draw order. These are consistency checks, not a reproduction: T4 line choices, the 10 reserve draws, pilot seed usage and code provenance are unchecked, no fresh pilot or evaluation has been run, and no second person has re-run the results. Regeneration from the raw data with hash comparison would be the reproduction step.

## 10. AI Assistance Disclosure

An AI assistant (Claude, Anthropic) was used under the author's direction for planning the study, generating and debugging the pipeline, test and scoring code, recomputing the evaluation outputs, drafting figures and manuscript text, and summarising literature at abstract level. The assistant did not execute the Colab runs described above. The author directed the work and is responsible for the content; her project decisions are recorded in the recovered protocol text (`PROMPT07_FINAL_DECISIONS.txt`) and in a retrospective Author Decision Record (interpretations A to H), a draft until she signs it; no freeze record or historical approval date is available. The AI activity log kept with the project files is a draft awaiting her review.

## 11. Conclusion and Future Work

In this deterministic four-stage invoice-processing simulation, adding three intermediate checkpoints to final-only validation reduced the injected harmful faults reaching commit from 1,972 of 2,500 to none, at 13.07 times the rule applications per run and an unchanged 2% clean false-alarm rate (difference 78.88 percentage points; 95% invoice-level bootstrap interval 77.24 to 80.39). The gap was concentrated in fault types that leave the commit record internally plausible. This holds for the implemented pipeline, the five injected fault types and the recorded rules, as stored results not yet independently reproduced. It does not establish general detection ability, the contribution of placement as such, runtime cost, the five-layer framework, or any property of LLM agents or production systems.

Future work (none done here): regeneration from raw data with hash comparison; ablations separating position, information and rule count (including F+); multi-fault types and other datasets; measured cost; a systematic review; an LLM-agent pipeline; pre-registered RQ2 predictions.

## References

@@REFERENCES@@
